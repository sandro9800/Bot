function fmtTime(s) {
  s = Math.ceil(s);
  if (s >= 86400) { const d = Math.floor(s / 86400); const h = Math.floor((s % 86400) / 3600); return h > 0 ? `${d}d ${h}h` : `${d}d`; }
  if (s >= 3600) { const h = Math.floor(s / 3600); const m = Math.floor((s % 3600) / 60); return m > 0 ? `${h}h ${m}m` : `${h}h`; }
  if (s >= 60) { const m = Math.floor(s / 60); return m + "m " + (s % 60) + "s"; }
  return s + "s";
}

function parseInterval(str) {
  const match = str.match(/^(\d+)(s|m|h|d)$/i);
  if (!match) return null;
  const n = parseInt(match[1]);
  const unit = match[2].toLowerCase();
  if (unit === "s") return n * 1000;
  if (unit === "m") return n * 60 * 1000;
  if (unit === "h") return n * 3600 * 1000;
  if (unit === "d") return n * 86400 * 1000;
  return null;
}

function fmtInterval(ms) {
  const s = ms / 1000;
  if (s >= 86400) return (s / 86400) + "d";
  if (s >= 3600) return (s / 3600) + "h";
  if (s >= 60) return (s / 60) + "m";
  return s + "s";
}

function normaliseEmoji(str) {
  const custom = str.match(/<a?:.+?:(\d+)>/);
  if (custom) return custom[1];
  return str;
}

module.exports = { fmtTime, parseInterval, fmtInterval, normaliseEmoji };
