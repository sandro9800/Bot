const { ALLOWED_USERS } = require("../config");
const { getSetting } = require("../database/db");

const allowedSet = new Set(ALLOWED_USERS);

function isOwner(userId) {
  return allowedSet.has(userId);
}

function getStaffRank(userId, guildId) {
  const staff = getSetting(guildId, "staff") || {};
  return staff[userId]?.rank || null;
}

function isStaff(userId, guildId) {
  return isOwner(userId) || !!getStaffRank(userId, guildId);
}

function hasRank(userId, guildId, ...ranks) {
  if (isOwner(userId)) return true;
  const rank = getStaffRank(userId, guildId);
  return ranks.includes(rank);
}

function isAdmin(member) {
  const { PermissionFlagsBits } = require("discord.js");
  return member.permissions.has(PermissionFlagsBits.Administrator) || isOwner(member.id);
}

function isMod(member) {
  const { PermissionFlagsBits } = require("discord.js");
  return member.permissions.has(PermissionFlagsBits.ModerateMembers) ||
    member.permissions.has(PermissionFlagsBits.ManageMessages) ||
    member.permissions.has(PermissionFlagsBits.Administrator) ||
    isOwner(member.id) ||
    hasRank(member.id, member.guild.id, "admin", "helper");
}

module.exports = { isOwner, isStaff, hasRank, isAdmin, isMod, getStaffRank };
