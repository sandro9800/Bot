const fs = require("fs");
const path = require("path");

async function loadPlugins(client) {
  const pluginDir = path.join(__dirname, "../plugins");
  const files = fs.readdirSync(pluginDir).filter(f => f.endsWith(".js"));
  for (const file of files) {
    try {
      const plugin = require(path.join(pluginDir, file));
      if (plugin.enabled === false) continue;
      client.plugins.set(plugin.name, plugin);
      if (plugin.init) await plugin.init(client);
      console.log(`🔌 Plugin loaded: ${plugin.name}`);
    } catch (err) {
      console.error(`Failed to load plugin ${file}:`, err.message);
    }
  }
}

async function reloadPlugin(client, name) {
  const pluginDir = path.join(__dirname, "../plugins");
  const file = path.join(pluginDir, `${name}.js`);
  if (!fs.existsSync(file)) return false;
  delete require.cache[require.resolve(file)];
  const plugin = require(file);
  client.plugins.set(plugin.name, plugin);
  if (plugin.init) await plugin.init(client);
  return true;
}

module.exports = { loadPlugins, reloadPlugin };
