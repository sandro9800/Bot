const fs = require("fs");
const path = require("path");

async function loadEvents(client) {
  const evDir = path.join(__dirname, "../events");
  const files = fs.readdirSync(evDir).filter(f => f.endsWith(".js"));
  let count = 0;
  for (const file of files) {
    const exported = require(path.join(evDir, file));
    const events = Array.isArray(exported) ? exported : [exported];
    for (const event of events) {
      if (!event.name) continue;
      if (event.once) {
        client.once(event.name, (...args) => event.execute(client, ...args));
      } else {
        client.on(event.name, (...args) => event.execute(client, ...args));
      }
      count++;
    }
  }
  console.log(`✅ Loaded ${count} events`);
}

module.exports = { loadEvents };
