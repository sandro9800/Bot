const { REST, Routes, SlashCommandBuilder } = require("discord.js");

const slashDefs = [
  new SlashCommandBuilder().setName("help").setDescription("View available commands"),
  new SlashCommandBuilder().setName("leaderboard").setDescription("View XP leaderboard"),
  new SlashCommandBuilder().setName("profile").setDescription("View your profile"),
  new SlashCommandBuilder().setName("ticket").setDescription("Open a support ticket"),
  new SlashCommandBuilder().setName("daily").setDescription("Claim your daily reward"),
  new SlashCommandBuilder().setName("feedback").setDescription("Leave feedback for a closed ticket"),
  new SlashCommandBuilder().setName("snipe").setDescription("Show last deleted message"),
  new SlashCommandBuilder().setName("poll")
    .setDescription("Create a poll")
    .addStringOption(o => o.setName("question").setDescription("Poll question").setRequired(true))
    .addStringOption(o => o.setName("options").setDescription("Options separated by | e.g. Yes|No").setRequired(true)),
  new SlashCommandBuilder().setName("timer")
    .setDescription("Manage timers")
    .addSubcommand(s => s.setName("start").setDescription("Start a timer")
      .addStringOption(o => o.setName("name").setDescription("Timer name").setRequired(true))
      .addStringOption(o => o.setName("duration").setDescription("e.g. 1h30m").setRequired(true)))
    .addSubcommand(s => s.setName("list").setDescription("List active timers"))
    .addSubcommand(s => s.setName("stop").setDescription("Stop a timer")
      .addStringOption(o => o.setName("name").setDescription("Timer name").setRequired(true))),
  new SlashCommandBuilder().setName("gen")
    .setDescription("Generator commands")
    .addSubcommand(s => s.setName("rank").setDescription("Check XP rank")
      .addUserOption(o => o.setName("user").setDescription("User").setRequired(false)))
    .addSubcommand(s => s.setName("afk").setDescription("Set AFK")
      .addStringOption(o => o.setName("reason").setDescription("Reason").setRequired(false))
      .addStringOption(o => o.setName("duration").setDescription("e.g. 1h").setRequired(false)))
    .addSubcommand(s => s.setName("report").setDescription("Report a user")
      .addUserOption(o => o.setName("user").setDescription("User").setRequired(true))
      .addStringOption(o => o.setName("reason").setDescription("Reason").setRequired(true)))
    .addSubcommand(s => s.setName("stock").setDescription("View stock count"))
    .addSubcommand(s => s.setName("panel").setDescription("Deploy generator panel")
      .addChannelOption(o => o.setName("channel").setDescription("Channel").setRequired(false)))
    .addSubcommand(s => s.setName("addstock").setDescription("Add stock (owner)"))
    .addSubcommand(s => s.setName("clearstock").setDescription("Clear stock (owner)"))
    .addSubcommand(s => s.setName("send").setDescription("Send stock to user")
      .addUserOption(o => o.setName("user").setDescription("User").setRequired(true))
      .addIntegerOption(o => o.setName("amount").setDescription("Amount").setRequired(false)))
    .addSubcommand(s => s.setName("giveaway").setDescription("Manage giveaways")
      .addStringOption(o => o.setName("action").setDescription("create/end/reroll/list").setRequired(true)))
    .addSubcommand(s => s.setName("warnings").setDescription("View user warnings")
      .addUserOption(o => o.setName("user").setDescription("User").setRequired(true)))
    .addSubcommand(s => s.setName("warn").setDescription("Warn a user")
      .addUserOption(o => o.setName("user").setDescription("User").setRequired(true))
      .addStringOption(o => o.setName("reason").setDescription("Reason").setRequired(false)))
    .addSubcommand(s => s.setName("analytics").setDescription("View analytics (owner)"))
    .addSubcommand(s => s.setName("reload").setDescription("Reload commands (owner)")
      .addStringOption(o => o.setName("target").setDescription("commands/plugins/all").setRequired(false)))
    .addSubcommand(s => s.setName("staff").setDescription("Manage staff")
      .addStringOption(o => o.setName("action").setDescription("list/add/remove/promote/demote").setRequired(true))
      .addUserOption(o => o.setName("user").setDescription("User").setRequired(false))
      .addStringOption(o => o.setName("rank").setDescription("Rank").setRequired(false))),
  new SlashCommandBuilder().setName("ban")
    .setDescription("Ban a member")
    .addUserOption(o => o.setName("user").setDescription("User").setRequired(true))
    .addStringOption(o => o.setName("reason").setDescription("Reason").setRequired(false)),
  new SlashCommandBuilder().setName("kick")
    .setDescription("Kick a member")
    .addUserOption(o => o.setName("user").setDescription("User").setRequired(true))
    .addStringOption(o => o.setName("reason").setDescription("Reason").setRequired(false)),
  new SlashCommandBuilder().setName("timeout")
    .setDescription("Timeout a member")
    .addUserOption(o => o.setName("user").setDescription("User").setRequired(true))
    .addStringOption(o => o.setName("duration").setDescription("e.g. 10m 1h").setRequired(true))
    .addStringOption(o => o.setName("reason").setDescription("Reason").setRequired(false)),
  new SlashCommandBuilder().setName("warn")
    .setDescription("Warn a member")
    .addUserOption(o => o.setName("user").setDescription("User").setRequired(true))
    .addStringOption(o => o.setName("reason").setDescription("Reason").setRequired(false)),
  new SlashCommandBuilder().setName("unban")
    .setDescription("Unban a user")
    .addStringOption(o => o.setName("userid").setDescription("User ID").setRequired(true)),
  new SlashCommandBuilder().setName("mute")
    .setDescription("Mute a member")
    .addUserOption(o => o.setName("user").setDescription("User").setRequired(true))
    .addStringOption(o => o.setName("reason").setDescription("Reason").setRequired(false)),
  new SlashCommandBuilder().setName("unmute")
    .setDescription("Unmute a member")
    .addUserOption(o => o.setName("user").setDescription("User").setRequired(true)),
  new SlashCommandBuilder().setName("purge")
    .setDescription("Delete messages")
    .addIntegerOption(o => o.setName("amount").setDescription("Count").setRequired(true)),
  new SlashCommandBuilder().setName("history")
    .setDescription("View mod history")
    .addUserOption(o => o.setName("user").setDescription("User").setRequired(true)),
  new SlashCommandBuilder().setName("role")
    .setDescription("Add/remove role from user")
    .addUserOption(o => o.setName("user").setDescription("User").setRequired(true))
    .addRoleOption(o => o.setName("role").setDescription("Role").setRequired(true))
    .addStringOption(o => o.setName("action").setDescription("add or remove").setRequired(false)),
];

async function registerSlashCommands() {
  if (!process.env.TOKEN || !process.env.CLIENT_ID || !process.env.GUILD_ID) {
    console.error("❌ Missing TOKEN, CLIENT_ID, or GUILD_ID — slash commands not registered");
    return;
  }
  try {
    const rest = new REST({ version: "10" }).setToken(process.env.TOKEN);
    await rest.put(
      Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
      { body: slashDefs.map(c => c.toJSON()) }
    );
    console.log(`✅ Registered ${slashDefs.length} slash commands (guild, instant)`);
  } catch (err) {
    console.error("❌ Slash command registration failed:", err.message);
  }
}

module.exports = { registerSlashCommands };
