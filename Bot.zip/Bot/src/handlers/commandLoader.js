const fs = require("fs");
const path = require("path");

async function loadCommands(client) {
  const cmdDir = path.join(__dirname, "../commands");
  const categories = fs.readdirSync(cmdDir);
  let count = 0;
  for (const cat of categories) {
    const catPath = path.join(cmdDir, cat);
    if (!fs.statSync(catPath).isDirectory()) continue;
    const files = fs.readdirSync(catPath).filter(f => f.endsWith(".js"));
    for (const file of files) {
      const filePath = path.join(catPath, file);
      const exported = require(filePath);
      const cmds = Array.isArray(exported) ? exported : [exported];
      for (const cmd of cmds) {
        if (cmd.name) {
          client.commands.set(cmd.name, cmd);
          count++;
        }
      }
    }
  }
  console.log(`✅ Loaded ${count} commands`);
}

module.exports = { loadCommands };
