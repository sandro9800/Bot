const { readJson, writeJson } = require("../database/store");

function getLevelRewards(guildId) {
  const db = readJson("level_rewards");
  return db[guildId] || {};
}

function addLevelReward(guildId, level, roleId) {
  const db = readJson("level_rewards");
  if (!db[guildId]) db[guildId] = {};
  db[guildId][level] = roleId;
  writeJson("level_rewards", db);
}

function removeLevelReward(guildId, level) {
  const db = readJson("level_rewards");
  if (!db[guildId]?.[level]) return false;
  delete db[guildId][level];
  writeJson("level_rewards", db);
  return true;
}

async function checkLevelRewards(guild, member, level) {
  const rewards = getLevelRewards(guild.id);
  const roleId = rewards[level];
  if (!roleId) return;
  try {
    const role = await guild.roles.fetch(roleId);
    if (role) await member.roles.add(role);
  } catch (_) {}
}

module.exports = { getLevelRewards, addLevelReward, removeLevelReward, checkLevelRewards };
