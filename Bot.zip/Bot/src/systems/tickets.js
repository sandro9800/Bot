const { EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder, ChannelType, PermissionFlagsBits, AttachmentBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require("discord.js");
const { COLORS } = require("../config");
const { readJson, writeJson } = require("../database/store");
const { addFeedback } = require("./ticketFeedback");

function getTicketConfig(guildId) {
  const db = readJson("tickets");
  if (!db.configs) db.configs = {};
  if (!db.configs[guildId]) db.configs[guildId] = { counter: 0 };
  return db.configs[guildId];
}

function saveTicketConfig(guildId, config) {
  const db = readJson("tickets");
  if (!db.configs) db.configs = {};
  db.configs[guildId] = config;
  writeJson("tickets", db);
}

function getTicketData(guildId, channelId) {
  const db = readJson("tickets");
  return db.open?.[guildId]?.[channelId] || null;
}

function saveTicketData(guildId, channelId, data) {
  const db = readJson("tickets");
  if (!db.open) db.open = {};
  if (!db.open[guildId]) db.open[guildId] = {};
  db.open[guildId][channelId] = data;
  writeJson("tickets", db);
}

function deleteTicketData(guildId, channelId) {
  const db = readJson("tickets");
  if (db.open?.[guildId]) delete db.open[guildId][channelId];
  writeJson("tickets", db);
}

function buildTicketPanelEmbed(guild) {
  return new EmbedBuilder()
    .setColor(COLORS.BOT)
    .setTitle(`🎫 ${guild.name} — Support Tickets`)
    .setDescription("Select a ticket type below to open a support ticket.\nA staff member will assist you shortly.")
    .addFields(
      { name: "🛠️ Support", value: "General support questions", inline: true },
      { name: "💸 Purchase", value: "Purchase assistance", inline: true },
      { name: "🚨 Report", value: "Report a user or issue", inline: true },
    ).setTimestamp();
}

function buildTicketPanelRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("ticket_support").setLabel("🛠️ Support").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("ticket_purchase").setLabel("💸 Purchase").setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId("ticket_report").setLabel("🚨 Report").setStyle(ButtonStyle.Danger),
  );
}

async function createTicket(interaction, type) {
  const guildId = interaction.guild.id;
  const ticketCfg = getTicketConfig(guildId);
  ticketCfg.counter = (ticketCfg.counter || 0) + 1;
  saveTicketConfig(guildId, ticketCfg);
  const ticketName = `${type}-${ticketCfg.counter.toString().padStart(4, "0")}`;
  const permOverwrites = [
    { id: interaction.guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
    { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
  ];
  if (ticketCfg.supportRole) {
    permOverwrites.push({ id: ticketCfg.supportRole, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] });
  }
  const ch = await interaction.guild.channels.create({
    name: ticketName, type: ChannelType.GuildText,
    parent: ticketCfg.categoryId || undefined,
    permissionOverwrites: permOverwrites,
  });
  saveTicketData(guildId, ch.id, { userId: interaction.user.id, userTag: interaction.user.tag, type, createdAt: Date.now(), claimed: false, claimedBy: null, ticketName });
  const embed = new EmbedBuilder().setColor(COLORS.BOT).setTitle(`🎫 ${type.charAt(0).toUpperCase() + type.slice(1)} Ticket`).setDescription(`Welcome ${interaction.user}!\n\nPlease describe your issue and a staff member will assist you.\n\n**Type:** ${type}\n**Ticket:** ${ticketName}`).setTimestamp();
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("ticket_close_btn").setLabel("🔒 Close Ticket").setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId("ticket_claim_btn").setLabel("✋ Claim").setStyle(ButtonStyle.Primary),
  );
  await ch.send({ content: `${interaction.user}${ticketCfg.supportRole ? ` <@&${ticketCfg.supportRole}>` : ""}`, embeds: [embed], components: [row], allowedMentions: { users: [interaction.user.id], roles: ticketCfg.supportRole ? [ticketCfg.supportRole] : [] } });
  if (ticketCfg.logChannel) {
    try {
      const logCh = await interaction.guild.channels.fetch(ticketCfg.logChannel);
      await logCh.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("🎫 Ticket Created").addFields({ name: "User", value: interaction.user.tag, inline: true }, { name: "Type", value: type, inline: true }, { name: "Channel", value: `${ch}`, inline: true }).setTimestamp()] });
    } catch (_) {}
  }
  return ch;
}

async function closeTicket(interaction, ticket) {
  const messages = await interaction.channel.messages.fetch({ limit: 100 });
  const transcript = messages.reverse().map(m => `[${new Date(m.createdTimestamp).toISOString()}] ${m.author.tag}: ${m.content}`).join("\n");
  const ticketCfg = getTicketConfig(interaction.guild.id);
  if (ticketCfg.logChannel) {
    try {
      const logCh = await interaction.guild.channels.fetch(ticketCfg.logChannel);
      const file = new AttachmentBuilder(Buffer.from(transcript, "utf-8"), { name: `transcript-${interaction.channel.name}.txt` });
      await logCh.send({ embeds: [new EmbedBuilder().setColor(COLORS.ERROR).setTitle("🔒 Ticket Closed").addFields({ name: "Ticket", value: interaction.channel.name, inline: true }, { name: "Closed by", value: interaction.user.tag, inline: true }, { name: "User", value: ticket.userTag, inline: true }).setTimestamp()], files: [file] });
    } catch (_) {}
  }
  // Send feedback request to ticket opener
  try {
    const opener = await interaction.guild.members.fetch(ticket.userId);
    const feedbackEmbed = new EmbedBuilder().setColor(COLORS.BOT).setTitle("⭐ Ticket Feedback").setDescription(`Your ticket **${ticket.ticketName || interaction.channel.name}** has been closed.\n\nPlease rate your experience by clicking a button below.`).setTimestamp();
    const feedbackRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`feedback_1_${interaction.channel.id}`).setLabel("⭐ 1").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId(`feedback_2_${interaction.channel.id}`).setLabel("⭐ 2").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId(`feedback_3_${interaction.channel.id}`).setLabel("⭐ 3").setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId(`feedback_4_${interaction.channel.id}`).setLabel("⭐ 4").setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId(`feedback_5_${interaction.channel.id}`).setLabel("⭐ 5").setStyle(ButtonStyle.Success),
    );
    await opener.send({ embeds: [feedbackEmbed], components: [feedbackRow] });
  } catch (_) {}
  deleteTicketData(interaction.guild.id, interaction.channel.id);
  setTimeout(async () => { try { await interaction.channel.delete(); } catch (_) {} }, 5000);
}

module.exports = { getTicketConfig, saveTicketConfig, getTicketData, saveTicketData, deleteTicketData, buildTicketPanelEmbed, buildTicketPanelRow, createTicket, closeTicket };
