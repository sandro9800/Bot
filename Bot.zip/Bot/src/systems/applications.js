const { readJson, writeJson } = require("../database/store");

function getAppConfig(guildId) {
  const db = readJson("applications");
  if (!db.configs) db.configs = {};
  if (!db.configs[guildId]) db.configs[guildId] = { enabled: false, logChannel: null, questions: ["Why do you want to join the staff team?", "How old are you?", "How many hours per week can you be active?", "Do you have any previous experience?", "Tell us something about yourself."] };
  return db.configs[guildId];
}

function saveAppConfig(guildId, config) {
  const db = readJson("applications");
  if (!db.configs) db.configs = {};
  db.configs[guildId] = config;
  writeJson("applications", db);
}

function getApplications(guildId) {
  const db = readJson("applications");
  return db.apps?.[guildId] || [];
}

function addApplication(guildId, app) {
  const db = readJson("applications");
  if (!db.apps) db.apps = {};
  if (!db.apps[guildId]) db.apps[guildId] = [];
  const id = `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  const entry = { id, ...app, status: "pending", timestamp: Date.now() };
  db.apps[guildId].unshift(entry);
  writeJson("applications", db);
  return entry;
}

function updateApplicationStatus(guildId, appId, status, reviewerId) {
  const db = readJson("applications");
  const apps = db.apps?.[guildId] || [];
  const app = apps.find(a => a.id === appId);
  if (!app) return null;
  app.status = status;
  app.reviewerId = reviewerId;
  app.reviewedAt = Date.now();
  writeJson("applications", db);
  return app;
}

module.exports = { getAppConfig, saveAppConfig, getApplications, addApplication, updateApplicationStatus };
