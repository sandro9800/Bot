const { readJson, writeJson } = require("../database/store");

function isBlacklisted(userId) {
  const db = readJson("blacklist");
  return !!(db.users || []).find(u => u.id === userId);
}

function addBlacklist(userId, reason, addedBy) {
  const db = readJson("blacklist");
  if (!db.users) db.users = [];
  if (isBlacklisted(userId)) return false;
  db.users.push({ id: userId, reason, addedBy, addedAt: Date.now() });
  writeJson("blacklist", db);
  return true;
}

function removeBlacklist(userId) {
  const db = readJson("blacklist");
  if (!db.users) return false;
  const before = db.users.length;
  db.users = db.users.filter(u => u.id !== userId);
  writeJson("blacklist", db);
  return db.users.length < before;
}

function getBlacklist() {
  const db = readJson("blacklist");
  return db.users || [];
}

module.exports = { isBlacklisted, addBlacklist, removeBlacklist, getBlacklist };
