const { getDB } = require("../database/db");

function saveSnipe(guildId, channelId, content, authorId) {
  const db = getDB();
  db.prepare(`
    INSERT INTO snipe (guild_id, channel_id, content, author_id) 
    VALUES (?, ?, ?, ?)
  `).run(guildId, channelId, content, authorId);
}

function getSnipe(guildId, channelId) {
  const db = getDB();
  return db.prepare("SELECT * FROM snipe WHERE guild_id = ? AND channel_id = ? ORDER BY deleted_at DESC LIMIT 1").get(guildId, channelId);
}

module.exports = { saveSnipe, getSnipe };
