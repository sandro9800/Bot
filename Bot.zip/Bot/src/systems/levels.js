const { getDB } = require("../database/db");
const xpCooldowns = new Map();

function getXPForLevel(level) { return 5 * (level ** 2) + 50 * level + 100; }

function getUserLevel(guildId, userId) {
  const db = getDB();
  let row = db.prepare("SELECT * FROM levels WHERE guild_id=? AND user_id=?").get(guildId, userId);
  if (!row) {
    db.prepare("INSERT OR IGNORE INTO levels (guild_id,user_id,xp,level) VALUES (?,?,0,0)").run(guildId, userId);
    row = { guild_id: guildId, user_id: userId, xp: 0, level: 0 };
  }
  return row;
}

function addXP(guildId, userId, amount) {
  const db = getDB();
  db.prepare("INSERT OR IGNORE INTO levels (guild_id,user_id,xp,level) VALUES (?,?,0,0)").run(guildId, userId);
  let { xp, level } = db.prepare("SELECT xp,level FROM levels WHERE guild_id=? AND user_id=?").get(guildId, userId);
  xp += amount;
  let leveledUp = false;
  while (xp >= getXPForLevel(level)) { xp -= getXPForLevel(level); level++; leveledUp = true; }
  db.prepare("UPDATE levels SET xp=?,level=?,last_xp=? WHERE guild_id=? AND user_id=?")
    .run(xp, level, Date.now(), guildId, userId);
  return { leveledUp, level, xp };
}

function addVoiceXP(guildId, userId, amount) { return addXP(guildId, userId, amount); }

function getLeaderboard(guildId, limit = 10) {
  return getDB().prepare("SELECT user_id as userId,xp,level FROM levels WHERE guild_id=? ORDER BY level DESC,xp DESC LIMIT ?").all(guildId, limit);
}

function tryAwardXP(guildId, userId) {
  const now = Date.now(), key = `${guildId}:${userId}`;
  if (now - (xpCooldowns.get(key) || 0) < 60000) return null;
  xpCooldowns.set(key, now);
  return addXP(guildId, userId, Math.floor(Math.random() * 10) + 15);
}

module.exports = { getXPForLevel, getUserLevel, addXP, addVoiceXP, getLeaderboard, tryAwardXP };
