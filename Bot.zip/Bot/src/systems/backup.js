const fs = require("fs");
const path = require("path");
const { EmbedBuilder, AttachmentBuilder } = require("discord.js");
const { COLORS } = require("../config");

const BACKUP_DIR = path.join(process.cwd(), "backups");

function createBackup() {
  if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });
  const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
  const backupPath = path.join(BACKUP_DIR, `backup-${timestamp}`);
  fs.mkdirSync(backupPath);

  const filesToBackup = ["storage.json", "clients.json", "stock.txt", "DB.txt"];
  const dbDir = path.join(process.cwd(), "database");

  for (const file of filesToBackup) {
    const src = path.join(process.cwd(), file);
    if (fs.existsSync(src)) fs.copyFileSync(src, path.join(backupPath, file));
  }

  if (fs.existsSync(dbDir)) {
    const dbBackup = path.join(backupPath, "database");
    fs.mkdirSync(dbBackup);
    for (const file of fs.readdirSync(dbDir)) {
      fs.copyFileSync(path.join(dbDir, file), path.join(dbBackup, file));
    }
  }

  return backupPath;
}

function listBackups() {
  if (!fs.existsSync(BACKUP_DIR)) return [];
  return fs.readdirSync(BACKUP_DIR).filter(f => f.startsWith("backup-")).sort().reverse();
}

function restoreBackup(backupName) {
  const backupPath = path.join(BACKUP_DIR, backupName);
  if (!fs.existsSync(backupPath)) return false;

  const filesToRestore = ["storage.json", "clients.json", "stock.txt", "DB.txt"];
  for (const file of filesToRestore) {
    const src = path.join(backupPath, file);
    if (fs.existsSync(src)) fs.copyFileSync(src, path.join(process.cwd(), file));
  }

  const dbBackup = path.join(backupPath, "database");
  const dbDir = path.join(process.cwd(), "database");
  if (fs.existsSync(dbBackup)) {
    if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir);
    for (const file of fs.readdirSync(dbBackup)) {
      fs.copyFileSync(path.join(dbBackup, file), path.join(dbDir, file));
    }
  }
  return true;
}

module.exports = { createBackup, listBackups, restoreBackup };
