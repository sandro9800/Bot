const { readJson, writeJson } = require("../database/store");

function getPremiumConfig(guildId) {
  const db = readJson("premium");
  if (!db[guildId]) db[guildId] = { roles: {}, users: {} };
  return db[guildId];
}

function addPremiumUser(guildId, userId, roleId, expiresAt) {
  const db = readJson("premium");
  if (!db[guildId]) db[guildId] = { roles: {}, users: {} };
  db[guildId].users[userId] = { roleId, expiresAt, addedAt: Date.now() };
  writeJson("premium", db);
}

function removePremiumUser(guildId, userId) {
  const db = readJson("premium");
  if (!db[guildId]?.users[userId]) return false;
  delete db[guildId].users[userId];
  writeJson("premium", db);
  return true;
}

function getPremiumUsers(guildId) {
  const db = readJson("premium");
  return db[guildId]?.users || {};
}

function isPremium(guildId, userId) {
  const users = getPremiumUsers(guildId);
  const user = users[userId];
  if (!user) return false;
  if (user.expiresAt && Date.now() > user.expiresAt) return false;
  return true;
}

async function checkExpiredPremium(client) {
  const db = readJson("premium");
  const now = Date.now();
  for (const [guildId, data] of Object.entries(db)) {
    for (const [userId, info] of Object.entries(data.users || {})) {
      if (info.expiresAt && now > info.expiresAt) {
        try {
          const guild = await client.guilds.fetch(guildId);
          const member = await guild.members.fetch(userId);
          if (info.roleId) await member.roles.remove(info.roleId);
        } catch (_) {}
        delete db[guildId].users[userId];
      }
    }
  }
  writeJson("premium", db);
}

module.exports = { getPremiumConfig, addPremiumUser, removePremiumUser, getPremiumUsers, isPremium, checkExpiredPremium };
