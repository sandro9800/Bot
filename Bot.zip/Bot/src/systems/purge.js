const { getStorage, saveStorage } = require("../database/store");
const { fmtInterval } = require("../utils/format");

const purgeIntervals = {};

async function purgeChannel(channel) {
  try {
    const fetched = await channel.messages.fetch({ limit: 100 });
    const deletable = fetched.filter(m => Date.now() - m.createdTimestamp < 14 * 86400000);
    if (deletable.size > 1) await channel.bulkDelete(deletable, true);
    else if (deletable.size === 1) await deletable.first().delete();
  } catch (err) {
    console.error(`Auto-purge error in #${channel.name}:`, err.message);
  }
}

function startPurge(channel, intervalMs) {
  if (purgeIntervals[channel.id]) clearInterval(purgeIntervals[channel.id]);
  purgeIntervals[channel.id] = setInterval(() => purgeChannel(channel), intervalMs);
  const data = getStorage();
  if (!data.purges) data.purges = {};
  data.purges[channel.id] = { channelId: channel.id, intervalMs };
  saveStorage(data);
}

function stopPurge(channelId) {
  if (purgeIntervals[channelId]) { clearInterval(purgeIntervals[channelId]); delete purgeIntervals[channelId]; }
  const data = getStorage();
  if (data.purges) delete data.purges[channelId];
  saveStorage(data);
}

async function restorePurges(client) {
  const data = getStorage();
  if (data.purges) {
    for (const [channelId, entry] of Object.entries(data.purges)) {
      try {
        const ch = await client.channels.fetch(channelId);
        purgeIntervals[channelId] = setInterval(() => purgeChannel(ch), entry.intervalMs);
        console.log(`🔄 Restored auto-purge for #${ch.name} every ${fmtInterval(entry.intervalMs)}`);
      } catch (_) { delete data.purges[channelId]; saveStorage(data); }
    }
  }
}

module.exports = { purgeChannel, startPurge, stopPurge, restorePurges };
