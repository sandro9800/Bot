const { readJson, writeJson } = require("../database/store");

function getReports(guildId) {
  const db = readJson("reports");
  return db[guildId] || [];
}

function addReport(guildId, report) {
  const db = readJson("reports");
  if (!db[guildId]) db[guildId] = [];
  const id = `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  const entry = { id, ...report, status: "pending", timestamp: Date.now() };
  db[guildId].unshift(entry);
  writeJson("reports", db);
  return entry;
}

function updateReportStatus(guildId, reportId, status, reviewerId) {
  const db = readJson("reports");
  const reports = db[guildId] || [];
  const report = reports.find(r => r.id === reportId);
  if (!report) return null;
  report.status = status;
  report.reviewerId = reviewerId;
  report.reviewedAt = Date.now();
  writeJson("reports", db);
  return report;
}

module.exports = { getReports, addReport, updateReportStatus };
