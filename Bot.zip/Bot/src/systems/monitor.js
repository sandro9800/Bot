const os = require("os");

function getUptime() {
  const s = Math.floor(process.uptime());
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return `${d}d ${h}h ${m}m ${sec}s`;
}

function getMemoryUsage() {
  const used = process.memoryUsage();
  return {
    heapUsed: (used.heapUsed / 1024 / 1024).toFixed(2) + " MB",
    heapTotal: (used.heapTotal / 1024 / 1024).toFixed(2) + " MB",
    rss: (used.rss / 1024 / 1024).toFixed(2) + " MB",
  };
}

function getCpuLoad() {
  const load = os.loadavg();
  return {
    "1m": load[0].toFixed(2),
    "5m": load[1].toFixed(2),
    "15m": load[2].toFixed(2),
  };
}

function getSystemInfo() {
  return {
    platform: os.platform(),
    arch: os.arch(),
    nodeVersion: process.version,
    uptime: getUptime(),
    memory: getMemoryUsage(),
    cpu: getCpuLoad(),
    cpuCores: os.cpus().length,
    hostname: os.hostname(),
  };
}

module.exports = { getUptime, getMemoryUsage, getCpuLoad, getSystemInfo };
