const { getDB } = require("../database/db");

function getAutomodConfig(guildId) {
  const db = getDB();
  const row = db.prepare("SELECT * FROM automod_config WHERE guild_id = ?").get(guildId);
  if (!row) return { enabled: false, anti_link: false, anti_spam: false, anti_mention: false, anti_caps: false, anti_emoji: false, heat_threshold: 5, punishment: "warn" };
  return {
    enabled: !!row.enabled,
    anti_link: !!row.anti_link,
    anti_spam: !!row.anti_spam,
    anti_mention: !!row.anti_mention,
    anti_caps: !!row.anti_caps,
    anti_emoji: !!row.anti_emoji,
    heat_threshold: row.heat_threshold || 5,
    punishment: row.punishment || "warn"
  };
}

function setAutomodConfig(guildId, config) {
  const db = getDB();
  const { enabled = false, anti_link = false, anti_spam = false, anti_mention = false, anti_caps = false, anti_emoji = false, heat_threshold = 5, punishment = "warn" } = config;
  db.prepare(`
    INSERT INTO automod_config (guild_id, enabled, anti_link, anti_spam, anti_mention, anti_caps, anti_emoji, heat_threshold, punishment)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(guild_id) DO UPDATE SET
      enabled = excluded.enabled,
      anti_link = excluded.anti_link,
      anti_spam = excluded.anti_spam,
      anti_mention = excluded.anti_mention,
      anti_caps = excluded.anti_caps,
      anti_emoji = excluded.anti_emoji,
      heat_threshold = excluded.heat_threshold,
      punishment = excluded.punishment
  `).run(guildId, enabled ? 1 : 0, anti_link ? 1 : 0, anti_spam ? 1 : 0, anti_mention ? 1 : 0, anti_caps ? 1 : 0, anti_emoji ? 1 : 0, heat_threshold, punishment);
}

module.exports = { getAutomodConfig, setAutomodConfig };
