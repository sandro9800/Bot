const { EmbedBuilder } = require("discord.js");
const { readJson, writeJson, getConfig } = require("../database/store");
const { COLORS } = require("../config");

function getWarnings(userId, guildId) {
  const db = readJson("logs");
  return db.warnings?.[guildId]?.[userId] || [];
}

function addWarning(userId, moderatorId, reason, guildId) {
  const db = readJson("logs");
  if (!db.warnings) db.warnings = {};
  if (!db.warnings[guildId]) db.warnings[guildId] = {};
  if (!db.warnings[guildId][userId]) db.warnings[guildId][userId] = [];
  db.warnings[guildId][userId].push({ moderatorId, reason, timestamp: Date.now() });
  writeJson("logs", db);
  return db.warnings[guildId][userId].length;
}

function clearWarnings(userId, guildId) {
  const db = readJson("logs");
  if (db.warnings?.[guildId]) db.warnings[guildId][userId] = [];
  writeJson("logs", db);
}

async function sendModLog(guild, embed) {
  const config = getConfig(guild.id);
  const channelId = config.modLogChannel;
  if (!channelId) return;
  try { const ch = await guild.channels.fetch(channelId); if (ch) await ch.send({ embeds: [embed] }); } catch (_) {}
}

async function sendLog(guild, type, embed) {
  const config = getConfig(guild.id);
  const channelId = config.logChannel || config.modLogChannel;
  if (!channelId) return;
  try { const ch = await guild.channels.fetch(channelId); if (ch) await ch.send({ embeds: [embed] }); } catch (_) {}
}

function getGuildConfig(guildId) {
  return getConfig(guildId);
}

module.exports = { getWarnings, addWarning, clearWarnings, sendModLog, sendLog, getGuildConfig };
