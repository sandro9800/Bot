const { getDB } = require("../database/db");

function createTimer(guildId, name, durationMs, message, createdBy) {
  const db = getDB();
  const endTime = Date.now() + durationMs;
  const result = db.prepare(`
    INSERT INTO timers (guild_id, name, end_time, message, paused, created_by)
    VALUES (?, ?, ?, ?, 0, ?)
  `).run(guildId, name, endTime, message, createdBy);
  return result.lastInsertRowid;
}

function getTimer(guildId, name) {
  const db = getDB();
  return db.prepare("SELECT * FROM timers WHERE guild_id = ? AND name = ? AND ended IS NULL").get(guildId, name); // ended not in schema but can add later
}

function pauseTimer(guildId, name) {
  const db = getDB();
  db.prepare("UPDATE timers SET paused = 1 WHERE guild_id = ? AND name = ?").run(guildId, name);
}

function resumeTimer(guildId, name) {
  const db = getDB();
  db.prepare("UPDATE timers SET paused = 0 WHERE guild_id = ? AND name = ?").run(guildId, name);
}

function endTimer(guildId, name) {
  const db = getDB();
  db.prepare("UPDATE timers SET ended = 1 WHERE guild_id = ? AND name = ?").run(guildId, name); // Add ended column if needed
}

function getActiveTimers(guildId) {
  const db = getDB();
  return db.prepare("SELECT * FROM timers WHERE guild_id = ? AND (ended IS NULL OR ended = 0)").all(guildId);
}

function cleanupExpiredTimers() {
  // Can be called periodically
  const db = getDB();
  db.prepare("DELETE FROM timers WHERE end_time < ? AND (ended IS NULL OR ended = 0)").run(Date.now());
}

module.exports = {
  createTimer,
  getTimer,
  pauseTimer,
  resumeTimer,
  endTimer,
  getActiveTimers,
  cleanupExpiredTimers
};
