const { getStorage, saveStorage } = require("../database/store");

const afkUsers = new Map();

function setAfk(guildId, userId, reason, expiresAt = null) {
  const key = `${guildId}-${userId}`;
  const data = { reason, timestamp: Date.now(), expiresAt, mentions: 0 };
  afkUsers.set(key, data);
  const s = getStorage();
  if (!s.afk) s.afk = {};
  s.afk[key] = data;
  saveStorage(s);
}

function removeAfk(guildId, userId) {
  const key = `${guildId}-${userId}`;
  const data = afkUsers.get(key);
  afkUsers.delete(key);
  const s = getStorage();
  if (s.afk) delete s.afk[key];
  saveStorage(s);
  return data;
}

function getAfk(guildId, userId) {
  const key = `${guildId}-${userId}`;
  return afkUsers.get(key) || null;
}

function restoreAfk() {
  const s = getStorage();
  if (s.afk) {
    for (const [key, val] of Object.entries(s.afk)) afkUsers.set(key, val);
  }
}

module.exports = { afkUsers, setAfk, removeAfk, getAfk, restoreAfk };
