const { getDB } = require("../database/db");

function getJoin2CreateSettings(guildId) {
  const db = getDB();
  const row = db.prepare("SELECT * FROM join2create_settings WHERE guild_id = ?").get(guildId);
  if (!row) return null;
  return {
    enabled: !!row.enabled,
    create_channel_id: row.create_channel_id,
    category_id: row.category_id,
    default_name: row.default_name || "{user}'s Channel",
    default_limit: row.default_limit || 0,
    default_bitrate: row.default_bitrate || 64000
  };
}

function setJoin2CreateSettings(guildId, settings) {
  const db = getDB();
  const { enabled = false, create_channel_id, category_id, default_name, default_limit = 0, default_bitrate = 64000 } = settings;
  db.prepare(`
    INSERT INTO join2create_settings (guild_id, enabled, create_channel_id, category_id, default_name, default_limit, default_bitrate)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(guild_id) DO UPDATE SET
      enabled = excluded.enabled,
      create_channel_id = excluded.create_channel_id,
      category_id = excluded.category_id,
      default_name = excluded.default_name,
      default_limit = excluded.default_limit,
      default_bitrate = excluded.default_bitrate
  `).run(guildId, enabled ? 1 : 0, create_channel_id, category_id, default_name, default_limit, default_bitrate);
}

function addTempChannel(channelId, guildId, ownerId) {
  const db = getDB();
  db.prepare(`
    INSERT OR REPLACE INTO temp_voice_channels (channel_id, guild_id, owner_id) VALUES (?, ?, ?)
  `).run(channelId, guildId, ownerId);
}

function removeTempChannel(channelId) {
  const db = getDB();
  db.prepare("DELETE FROM temp_voice_channels WHERE channel_id = ?").run(channelId);
}

function getTempChannelOwner(channelId) {
  const db = getDB();
  const row = db.prepare("SELECT owner_id FROM temp_voice_channels WHERE channel_id = ?").get(channelId);
  return row ? row.owner_id : null;
}

function getUserTempChannel(guildId, userId) {
  const db = getDB();
  const row = db.prepare("SELECT channel_id FROM temp_voice_channels WHERE guild_id = ? AND owner_id = ?").get(guildId, userId);
  return row ? row.channel_id : null;
}

module.exports = {
  getJoin2CreateSettings,
  setJoin2CreateSettings,
  addTempChannel,
  removeTempChannel,
  getTempChannelOwner,
  getUserTempChannel
};
