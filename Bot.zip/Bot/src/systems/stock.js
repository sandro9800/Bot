const fs = require("fs");
const path = require("path");
const { COLORS, LOW_STOCK_THRESHOLD, STOCK_FILE, MASTER_DB_FILE } = require("../config");
const { EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require("discord.js");
const { getStorage, saveStorage } = require("../database/store");

const STOCK_PATH = path.join(process.cwd(), STOCK_FILE);
const DB_PATH = path.join(process.cwd(), MASTER_DB_FILE);

if (!fs.existsSync(STOCK_PATH)) fs.writeFileSync(STOCK_PATH, "", "utf-8");
if (!fs.existsSync(DB_PATH)) fs.writeFileSync(DB_PATH, "", "utf-8");

function readLines() {
  if (!fs.existsSync(STOCK_PATH)) return [];
  return fs.readFileSync(STOCK_PATH, "utf-8").split("\n").map(l => l.trimEnd()).filter(l => l.length > 0);
}

function popFirstLine() {
  const lines = readLines();
  if (!lines.length) return null;
  fs.writeFileSync(STOCK_PATH, lines.slice(1).join("\n") + (lines.length > 1 ? "\n" : ""), "utf-8");
  return lines[0];
}

function addLines(newLines) {
  const existing = readLines();
  fs.writeFileSync(STOCK_PATH, [...existing, ...newLines].join("\n") + "\n", "utf-8");
  return readLines().length;
}

function stockCount() { return readLines().length; }

function buildGenEmbed(count, guild) {
  return new EmbedBuilder()
    .setColor(COLORS.BOT)
    .setTitle(`🎁 ${guild?.name || "Generator"} — Account Generator`)
    .setDescription("Click the button below to generate an account.\n\nMake sure your DMs are open!")
    .addFields({ name: "\n📦 Current Stock", value: `\`${count}\` accounts available`, inline: false })
    .setTimestamp()
    .setFooter({ text: "Powered by Gen Bot" });
}

function buildRow(empty) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("get_line_btn").setLabel(empty ? "❌ Out of Stock" : "🎁 Generate Account").setStyle(empty ? ButtonStyle.Danger : ButtonStyle.Success).setDisabled(empty)
  );
}

async function checkLowStock(guild, remaining, panelMessageId) {
  const lowStockAlerted = getStorage("lowStockAlerted");
  if (remaining <= LOW_STOCK_THRESHOLD && lowStockAlerted !== "true") {
    saveStorage("lowStockAlerted", "true");
    const config = require("./logging").getGuildConfig(guild.id);
    if (config?.logChannel) {
      try {
        const ch = await guild.channels.fetch(config.logChannel);
        await ch.send({ embeds: [new EmbedBuilder().setColor(COLORS.WARN).setTitle("⚠️ Low Stock Alert").setDescription(`Only **${remaining}** accounts remaining in stock!`).setTimestamp()] });
      } catch (_) {}
    }
  }
  if (remaining > LOW_STOCK_THRESHOLD && lowStockAlerted === "true") {
    saveStorage("lowStockAlerted", "false");
  }
}

async function sendGenLog(guild, user) {
  const storage = getStorage();
  if (!storage.genLogChannel) return;
  try {
    const ch = await guild.channels.fetch(storage.genLogChannel);
    await ch.send({ embeds: [new EmbedBuilder().setColor(COLORS.INFO).setTitle("📋 Account Generated").addFields({ name: "User", value: `${user.tag} (\`${user.id}\`)`, inline: true }, { name: "Time", value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }).setTimestamp()] });
  } catch (_) {}
}

async function updateAllPanels(client) {
  const storage = getStorage();
  const count = stockCount();
  const active = [];
  for (const entry of storage.genMessages || []) {
    try {
      const ch = await client.channels.fetch(entry.channelId);
      const msg = await ch.messages.fetch(entry.messageId);
      await msg.edit({ embeds: [buildGenEmbed(count, msg.guild)], components: [buildRow(count === 0)] });
      active.push(entry);
    } catch (_) {}
  }
  storage.genMessages = active;
  saveStorage(storage);
}

module.exports = { readLines, popFirstLine, addLines, stockCount, buildGenEmbed, buildRow, checkLowStock, sendGenLog, updateAllPanels, STOCK_PATH, DB_PATH };
