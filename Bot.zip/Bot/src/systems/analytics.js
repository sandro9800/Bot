const { readJson, writeJson } = require("../database/store");

function trackCommand(guildId, userId, command) {
  const db = readJson("analytics");
  if (!db[guildId]) db[guildId] = { commands: {}, users: {}, daily: {} };
  const today = new Date().toISOString().slice(0, 10);
  if (!db[guildId].commands[command]) db[guildId].commands[command] = 0;
  db[guildId].commands[command]++;
  if (!db[guildId].users[userId]) db[guildId].users[userId] = 0;
  db[guildId].users[userId]++;
  if (!db[guildId].daily[today]) db[guildId].daily[today] = 0;
  db[guildId].daily[today]++;
  writeJson("analytics", db);
}

function getAnalytics(guildId) {
  const db = readJson("analytics");
  return db[guildId] || { commands: {}, users: {}, daily: {} };
}

function getTopCommands(guildId, limit = 10) {
  const data = getAnalytics(guildId);
  return Object.entries(data.commands).sort((a, b) => b[1] - a[1]).slice(0, limit);
}

function getTopUsers(guildId, limit = 10) {
  const data = getAnalytics(guildId);
  return Object.entries(data.users).sort((a, b) => b[1] - a[1]).slice(0, limit);
}

function getDailyActivity(guildId, days = 7) {
  const data = getAnalytics(guildId);
  const result = [];
  for (let i = days - 1; i >= 0; i--) {
    const date = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10);
    result.push({ date, count: data.daily[date] || 0 });
  }
  return result;
}

module.exports = { trackCommand, getAnalytics, getTopCommands, getTopUsers, getDailyActivity };
