const { readJson, writeJson } = require("../database/store");

function canClaimDaily(userId, guildId) {
  const db = readJson("daily");
  const last = db[guildId]?.[userId]?.lastClaim || 0;
  const now = Date.now();
  return now - last >= 86400000;
}

function claimDaily(userId, guildId) {
  const db = readJson("daily");
  if (!db[guildId]) db[guildId] = {};
  const now = Date.now();
  const streak = db[guildId][userId]?.streak || 0;
  const last = db[guildId][userId]?.lastClaim || 0;
  const isStreak = now - last < 172800000; // within 48h
  const newStreak = isStreak ? streak + 1 : 1;
  const bonus = Math.min(newStreak * 10, 100);
  const xp = 100 + bonus;
  db[guildId][userId] = { lastClaim: now, streak: newStreak };
  writeJson("daily", db);
  return { xp, streak: newStreak, bonus };
}

function getStreak(userId, guildId) {
  const db = readJson("daily");
  return db[guildId]?.[userId]?.streak || 0;
}

function getNextDaily(userId, guildId) {
  const db = readJson("daily");
  const last = db[guildId]?.[userId]?.lastClaim || 0;
  return last + 86400000;
}

module.exports = { canClaimDaily, claimDaily, getStreak, getNextDaily };
