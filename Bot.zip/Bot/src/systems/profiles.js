const { getDB } = require("../database/db");

function getProfile(guildId, userId) {
  const db = getDB();
  const row = db.prepare("SELECT * FROM profiles WHERE guild_id = ? AND user_id = ?").get(guildId, userId);
  if (!row) return { bio: null, badges: [], married_to: null, friends: [] };
  return {
    bio: row.bio,
    badges: row.badges ? JSON.parse(row.badges) : [],
    married_to: row.married_to,
    friends: row.friends ? JSON.parse(row.friends) : []
  };
}

function setBio(guildId, userId, bio) {
  const db = getDB();
  db.prepare(`
    INSERT INTO profiles (guild_id, user_id, bio, badges, married_to, friends)
    VALUES (?, ?, ?, '[]', NULL, '[]')
    ON CONFLICT(guild_id, user_id) DO UPDATE SET bio = excluded.bio, updated_at = strftime('%s', 'now') * 1000
  `).run(guildId, userId, bio);
}

function marry(guildId, userId, targetId) {
  const db = getDB();
  db.prepare(`
    INSERT INTO profiles (guild_id, user_id, bio, badges, married_to, friends)
    VALUES (?, ?, NULL, '[]', ?, '[]')
    ON CONFLICT(guild_id, user_id) DO UPDATE SET married_to = excluded.married_to
  `).run(guildId, userId, targetId);

  // Also update the target (mutual)
  db.prepare(`
    INSERT INTO profiles (guild_id, user_id, bio, badges, married_to, friends)
    VALUES (?, ?, NULL, '[]', ?, '[]')
    ON CONFLICT(guild_id, user_id) DO UPDATE SET married_to = excluded.married_to
  `).run(guildId, targetId, userId);
}

function addFriend(guildId, userId, friendId) {
  const profile = getProfile(guildId, userId);
  if (!profile.friends.includes(friendId)) {
    profile.friends.push(friendId);
    const db = getDB();
    db.prepare(`
      INSERT INTO profiles (guild_id, user_id, bio, badges, married_to, friends)
      VALUES (?, ?, NULL, '[]', NULL, ?)
      ON CONFLICT(guild_id, user_id) DO UPDATE SET friends = excluded.friends
    `).run(guildId, userId, JSON.stringify(profile.friends));
  }
}

function addBadge(guildId, userId, badge) {
  const profile = getProfile(guildId, userId);
  if (!profile.badges.includes(badge)) {
    profile.badges.push(badge);
    const db = getDB();
    db.prepare(`
      INSERT INTO profiles (guild_id, user_id, bio, badges, married_to, friends)
      VALUES (?, ?, NULL, ?, NULL, '[]')
      ON CONFLICT(guild_id, user_id) DO UPDATE SET badges = excluded.badges
    `).run(guildId, userId, JSON.stringify(profile.badges));
  }
}

module.exports = { getProfile, setBio, marry, addFriend, addBadge };
