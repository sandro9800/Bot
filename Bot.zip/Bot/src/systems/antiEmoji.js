const { getConfig, setConfig } = require("../database/store");

const emojiSpamMap = new Map();

function checkAntiEmoji(message) {
  const config = getConfig(message.guild.id);
  if (!config.antiEmojiEnabled) return false;
  const threshold = config.antiEmojiThreshold || 10;
  const emojiRegex = /(\p{Emoji_Presentation}|\p{Extended_Pictographic}|<a?:\w+:\d+>)/gu;
  const matches = message.content.match(emojiRegex);
  if (!matches) return false;
  return matches.length >= threshold;
}

module.exports = { checkAntiEmoji };
