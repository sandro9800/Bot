const { getDB } = require("../database/db");

function incrementMessage(guildId, userId) {
  const db = getDB();
  const now = Date.now();
  // Simple daily reset logic (can be improved with cron later)
  db.prepare(`
    INSERT INTO message_stats (guild_id, user_id, daily_count, alltime_count, last_reset)
    VALUES (?, ?, 1, 1, ?)
    ON CONFLICT(guild_id, user_id) DO UPDATE SET
      daily_count = daily_count + 1,
      alltime_count = alltime_count + 1
  `).run(guildId, userId, now);
}

function getMessageStats(guildId, userId) {
  const db = getDB();
  const row = db.prepare("SELECT * FROM message_stats WHERE guild_id = ? AND user_id = ?").get(guildId, userId);
  if (!row) return { daily: 0, alltime: 0 };
  return { daily: row.daily_count || 0, alltime: row.alltime_count || 0 };
}

function getMessageLeaderboard(guildId, type = "alltime", limit = 10) {
  const db = getDB();
  const col = type === "daily" ? "daily_count" : "alltime_count";
  return db.prepare(`
    SELECT user_id, ${col} as count FROM message_stats 
    WHERE guild_id = ? 
    ORDER BY ${col} DESC 
    LIMIT ?
  `).all(guildId, limit);
}

function resetDailyStats() {
  const db = getDB();
  db.prepare("UPDATE message_stats SET daily_count = 0").run();
}

module.exports = {
  incrementMessage,
  getMessageStats,
  getMessageLeaderboard,
  resetDailyStats
};
