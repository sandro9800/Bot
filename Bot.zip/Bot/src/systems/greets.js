const { getDB } = require("../database/db");

function getGreetConfig(guildId) {
  const db = getDB();
  const row = db.prepare("SELECT * FROM greets WHERE guild_id = ?").get(guildId);
  if (!row) return { channels: [], mode: "simple", message: null, delete_after: 0, container_data: null };
  return {
    channels: row.channels ? JSON.parse(row.channels) : [],
    mode: row.mode || "simple",
    message: row.message,
    delete_after: row.delete_after || 0,
    container_data: row.container_data ? JSON.parse(row.container_data) : null
  };
}

function setGreetConfig(guildId, config) {
  const db = getDB();
  const { channels = [], mode = "simple", message = null, delete_after = 0, container_data = null } = config;
  db.prepare(`
    INSERT INTO greets (guild_id, channels, mode, message, delete_after, container_data)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(guild_id) DO UPDATE SET
      channels = excluded.channels,
      mode = excluded.mode,
      message = excluded.message,
      delete_after = excluded.delete_after,
      container_data = excluded.container_data
  `).run(guildId, JSON.stringify(channels), mode, message, delete_after, container_data ? JSON.stringify(container_data) : null);
}

module.exports = { getGreetConfig, setGreetConfig };
