const { EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require("discord.js");
const { COLORS } = require("../config");
const { getStorage, saveStorage } = require("../database/store");
const { fmtTime } = require("../utils/format");

const giveaways = {};
const giveawaysByName = {};
const giveawayRerolData = {};

function buildGiveawayEmbed(item, endsAt, entryCount, guild, ended = false, winners = [], winnerCount = 1) {
  const embed = new EmbedBuilder()
    .setColor(ended ? COLORS.ERROR : COLORS.BOT)
    .setTitle(`🎉 ${item}`)
    .addFields(
      { name: "🏆 Winners", value: `**${winnerCount}**`, inline: true },
      { name: "👥 Entries", value: `**${entryCount}**`, inline: true },
      { name: ended ? "⏰ Ended" : "⏰ Ends", value: `<t:${Math.floor(endsAt / 1000)}:R>`, inline: true }
    )
    .setFooter({ text: ended ? "Giveaway ended" : "Click to enter!" })
    .setTimestamp();
  if (ended && winners.length) {
    embed.addFields({ name: "🎊 Winner(s)", value: winners.map(w => `<@${w}>`).join(", ") });
  }
  return embed;
}

function buildGiveawayRow(disabled = false) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("join_giveaway").setLabel("🎉 Enter Giveaway").setStyle(ButtonStyle.Primary).setDisabled(disabled)
  );
}

async function endGiveaway(client, messageId) {
  const gw = giveaways[messageId];
  if (!gw) return;
  clearTimeout(gw.timeoutId);
  clearInterval(gw.tickerId);
  const entriesArr = [...gw.entries];
  const winners = [];
  const pool = [...entriesArr];
  const count = Math.min(gw.winnerCount || 1, pool.length);
  for (let i = 0; i < count; i++) {
    const idx = Math.floor(Math.random() * pool.length);
    winners.push(pool.splice(idx, 1)[0]);
  }
  try {
    const ch = await client.channels.fetch(gw.channelId);
    const msg = await ch.messages.fetch(messageId);
    await msg.edit({ embeds: [buildGiveawayEmbed(gw.item, gw.endsAt, entriesArr.length, msg.guild, true, winners, gw.winnerCount)], components: [buildGiveawayRow(true)] });
    if (winners.length) {
      await ch.send({ content: `🎊 Congratulations ${winners.map(w => `<@${w}>`).join(", ")}! You won **${gw.item}**!`, allowedMentions: { users: winners } });
    } else {
      await ch.send({ content: `😔 No valid entries for **${gw.item}**.` });
    }
  } catch (_) {}
  giveawayRerolData[gw.item.toLowerCase()] = { entries: entriesArr, item: gw.item, channelId: gw.channelId };
  delete giveaways[messageId];
  delete giveawaysByName[gw.item.toLowerCase()];
  // persist
  const storage = getStorage();
  if (storage.giveaways) delete storage.giveaways[messageId];
  if (!storage.giveawayRerol) storage.giveawayRerol = {};
  storage.giveawayRerol[gw.item.toLowerCase()] = { entries: entriesArr, item: gw.item, channelId: gw.channelId };
  saveStorage(storage);
}

function saveGiveaway(messageId, data) {
  const storage = getStorage();
  if (!storage.giveaways) storage.giveaways = {};
  storage.giveaways[messageId] = { ...data, entries: [...data.entries] };
  saveStorage(storage);
}

function restoreGiveaways(client) {
  const storage = getStorage();
  if (storage.giveaways) {
    const now = Date.now();
    for (const [msgId, gw] of Object.entries(storage.giveaways)) {
      if (gw.endsAt <= now) { endGiveaway(client, msgId); continue; }
      const remaining = gw.endsAt - now;
      const tickerId = setInterval(async () => {
        const active = giveaways[msgId];
        if (!active) return clearInterval(tickerId);
        try {
          const ch = await client.channels.fetch(active.channelId);
          const msg = await ch.messages.fetch(msgId);
          await msg.edit({ embeds: [buildGiveawayEmbed(active.item, active.endsAt, active.entries.size, msg.guild, false, [], active.winnerCount || 1)], components: [buildGiveawayRow()] });
        } catch (_) { clearInterval(tickerId); }
      }, 30000);
      const timeoutId = setTimeout(() => endGiveaway(client, msgId), remaining);
      giveaways[msgId] = { item: gw.item, entries: new Set(gw.entries), endsAt: gw.endsAt, channelId: gw.channelId, winnerCount: gw.winnerCount || 1, timeoutId, tickerId };
      giveawaysByName[gw.item.toLowerCase()] = msgId;
    }
  }
  if (storage.giveawayRerol) {
    for (const [key, rd] of Object.entries(storage.giveawayRerol)) giveawayRerolData[key] = rd;
  }
}

module.exports = { giveaways, giveawaysByName, giveawayRerolData, buildGiveawayEmbed, buildGiveawayRow, endGiveaway, saveGiveaway, restoreGiveaways };
