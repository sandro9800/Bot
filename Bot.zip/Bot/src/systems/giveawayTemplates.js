const { readJson, writeJson } = require("../database/store");

function getTemplates(guildId) {
  const db = readJson("giveaway_templates");
  return db[guildId] || {};
}

function saveTemplate(guildId, name, data) {
  const db = readJson("giveaway_templates");
  if (!db[guildId]) db[guildId] = {};
  db[guildId][name.toLowerCase()] = { ...data, createdAt: Date.now() };
  writeJson("giveaway_templates", db);
}

function deleteTemplate(guildId, name) {
  const db = readJson("giveaway_templates");
  if (!db[guildId]?.[name.toLowerCase()]) return false;
  delete db[guildId][name.toLowerCase()];
  writeJson("giveaway_templates", db);
  return true;
}

function getTemplate(guildId, name) {
  const db = readJson("giveaway_templates");
  return db[guildId]?.[name.toLowerCase()] || null;
}

module.exports = { getTemplates, saveTemplate, deleteTemplate, getTemplate };
