const { readJson, writeJson } = require("../database/store");

const inviteCache = new Map();

function getInviteData(guildId) {
  const db = readJson("logs");
  return db.invites?.[guildId] || {};
}

function addInvite(guildId, inviterId, invitedId) {
  const db = readJson("logs");
  if (!db.invites) db.invites = {};
  if (!db.invites[guildId]) db.invites[guildId] = {};
  if (!db.invites[guildId][inviterId]) db.invites[guildId][inviterId] = { count: 0, invited: [] };
  db.invites[guildId][inviterId].count += 1;
  db.invites[guildId][inviterId].invited.push({ userId: invitedId, joinedAt: Date.now() });
  writeJson("logs", db);
}

function getInviteLeaderboard(guildId, limit = 10) {
  const data = getInviteData(guildId);
  return Object.entries(data).sort((a, b) => b[1].count - a[1].count).slice(0, limit);
}

module.exports = { inviteCache, getInviteData, addInvite, getInviteLeaderboard };
