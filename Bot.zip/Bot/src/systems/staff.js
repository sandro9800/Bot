const { readJson, writeJson } = require("../database/store");
const { STAFF_RANKS } = require("../config");

function getStaff(guildId) {
  const db = readJson("staff");
  return db[guildId] || {};
}

function addStaff(guildId, userId, userTag, rank) {
  if (!STAFF_RANKS.includes(rank)) return false;
  const db = readJson("staff");
  if (!db[guildId]) db[guildId] = {};
  db[guildId][userId] = { rank, tag: userTag, addedAt: Date.now(), activity: 0 };
  writeJson("staff", db);
  return true;
}

function removeStaff(guildId, userId) {
  const db = readJson("staff");
  if (!db[guildId]?.[userId]) return false;
  delete db[guildId][userId];
  writeJson("staff", db);
  return true;
}

function promoteStaff(guildId, userId) {
  const db = readJson("staff");
  const member = db[guildId]?.[userId];
  if (!member) return null;
  const idx = STAFF_RANKS.indexOf(member.rank);
  if (idx === -1 || idx >= STAFF_RANKS.length - 1) return null;
  member.rank = STAFF_RANKS[idx + 1];
  writeJson("staff", db);
  return member.rank;
}

function demoteStaff(guildId, userId) {
  const db = readJson("staff");
  const member = db[guildId]?.[userId];
  if (!member) return null;
  const idx = STAFF_RANKS.indexOf(member.rank);
  if (idx <= 0) return null;
  member.rank = STAFF_RANKS[idx - 1];
  writeJson("staff", db);
  return member.rank;
}

module.exports = { getStaff, addStaff, removeStaff, promoteStaff, demoteStaff };
