const { EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder, PermissionFlagsBits } = require("discord.js");
const { COLORS } = require("../config");
const { getConfig, setConfig } = require("../database/store");

function buildVerifyEmbed(guild) {
  return new EmbedBuilder()
    .setColor(COLORS.BOT)
    .setTitle(`✅ ${guild.name} — Verification`)
    .setDescription("Click the button below to verify yourself and gain access to the server.")
    .addFields({ name: "📋 Why verify?", value: "Verification helps us keep the server safe from bots and raiders." })
    .setTimestamp();
}

function buildVerifyRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("verify_btn").setLabel("✅ Verify Me").setStyle(ButtonStyle.Success)
  );
}

async function handleVerify(interaction) {
  const config = getConfig(interaction.guild.id);
  if (!config.verifiedRole) return interaction.reply({ content: "❌ Verification not configured.", ephemeral: true });
  try {
    const role = await interaction.guild.roles.fetch(config.verifiedRole);
    if (!role) return interaction.reply({ content: "❌ Verified role not found.", ephemeral: true });
    if (interaction.member.roles.cache.has(role.id)) return interaction.reply({ content: "✅ You are already verified!", ephemeral: true });
    await interaction.member.roles.add(role);
    return interaction.reply({ content: `✅ You have been verified and given the **${role.name}** role!`, ephemeral: true });
  } catch (err) {
    return interaction.reply({ content: `❌ Failed: ${err.message}`, ephemeral: true });
  }
}

module.exports = { buildVerifyEmbed, buildVerifyRow, handleVerify };
