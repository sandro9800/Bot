const { getDB } = require("../database/db");

function getVanityConfig(guildId) {
  const db = getDB();
  const row = db.prepare("SELECT * FROM vanity_config WHERE guild_id = ?").get(guildId);
  if (!row) return { enabled: false, vanity_text: null, channel_id: null, message: null, roles: [] };
  return {
    enabled: !!row.enabled,
    vanity_text: row.vanity_text,
    channel_id: row.channel_id,
    message: row.message,
    roles: row.roles ? JSON.parse(row.roles) : []
  };
}

function setVanityConfig(guildId, config) {
  const db = getDB();
  const { enabled = false, vanity_text = null, channel_id = null, message = null, roles = [] } = config;
  db.prepare(`
    INSERT INTO vanity_config (guild_id, enabled, vanity_text, channel_id, message, roles)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(guild_id) DO UPDATE SET 
      enabled = excluded.enabled,
      vanity_text = excluded.vanity_text,
      channel_id = excluded.channel_id,
      message = excluded.message,
      roles = excluded.roles
  `).run(guildId, enabled ? 1 : 0, vanity_text, channel_id, message, JSON.stringify(roles));
}

function addVanityUser(guildId, userId) {
  const db = getDB();
  db.prepare(`
    INSERT OR IGNORE INTO vanity_users (guild_id, user_id) VALUES (?, ?)
  `).run(guildId, userId);
}

function removeVanityUser(guildId, userId) {
  const db = getDB();
  db.prepare("DELETE FROM vanity_users WHERE guild_id = ? AND user_id = ?").run(guildId, userId);
}

function getVanityUsers(guildId) {
  const db = getDB();
  return db.prepare("SELECT user_id FROM vanity_users WHERE guild_id = ?").all(guildId).map(r => r.user_id);
}

function isVanityUser(guildId, userId) {
  const db = getDB();
  const row = db.prepare("SELECT 1 FROM vanity_users WHERE guild_id = ? AND user_id = ?").get(guildId, userId);
  return !!row;
}

module.exports = {
  getVanityConfig,
  setVanityConfig,
  addVanityUser,
  removeVanityUser,
  getVanityUsers,
  isVanityUser
};
