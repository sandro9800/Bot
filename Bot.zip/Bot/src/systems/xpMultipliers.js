const { readJson, writeJson } = require("../database/store");

function getMultipliers(guildId) {
  const db = readJson("xp_multipliers");
  return db[guildId] || { roles: {}, channels: {}, global: 1 };
}

function setGlobalMultiplier(guildId, multiplier) {
  const db = readJson("xp_multipliers");
  if (!db[guildId]) db[guildId] = { roles: {}, channels: {}, global: 1 };
  db[guildId].global = multiplier;
  writeJson("xp_multipliers", db);
}

function setRoleMultiplier(guildId, roleId, multiplier) {
  const db = readJson("xp_multipliers");
  if (!db[guildId]) db[guildId] = { roles: {}, channels: {}, global: 1 };
  if (multiplier <= 0) delete db[guildId].roles[roleId];
  else db[guildId].roles[roleId] = multiplier;
  writeJson("xp_multipliers", db);
}

function setChannelMultiplier(guildId, channelId, multiplier) {
  const db = readJson("xp_multipliers");
  if (!db[guildId]) db[guildId] = { roles: {}, channels: {}, global: 1 };
  if (multiplier <= 0) delete db[guildId].channels[channelId];
  else db[guildId].channels[channelId] = multiplier;
  writeJson("xp_multipliers", db);
}

function getEffectiveMultiplier(guildId, member, channelId) {
  const data = getMultipliers(guildId);
  let multiplier = data.global || 1;
  for (const [roleId, mult] of Object.entries(data.roles || {})) {
    if (member.roles.cache.has(roleId)) multiplier = Math.max(multiplier, mult);
  }
  if (data.channels?.[channelId]) multiplier *= data.channels[channelId];
  return multiplier;
}

module.exports = { getMultipliers, setGlobalMultiplier, setRoleMultiplier, setChannelMultiplier, getEffectiveMultiplier };
