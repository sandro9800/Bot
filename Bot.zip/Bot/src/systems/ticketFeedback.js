const { readJson, writeJson } = require("../database/store");

function addFeedback(guildId, ticketName, userId, rating, comment) {
  const db = readJson("ticket_feedback");
  if (!db[guildId]) db[guildId] = [];
  db[guildId].push({ ticketName, userId, rating, comment, timestamp: Date.now() });
  writeJson("ticket_feedback", db);
}

function getFeedback(guildId) {
  const db = readJson("ticket_feedback");
  return db[guildId] || [];
}

function getAverageRating(guildId) {
  const feedback = getFeedback(guildId);
  if (!feedback.length) return null;
  const avg = feedback.reduce((sum, f) => sum + f.rating, 0) / feedback.length;
  return avg.toFixed(2);
}

module.exports = { addFeedback, getFeedback, getAverageRating };
