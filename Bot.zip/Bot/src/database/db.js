const Database = require("better-sqlite3");
const fs = require("fs");
const path = require("path");

let db = null;

const DB_DIR = path.join(__dirname, "../../database");
const DB_FILE = path.join(DB_DIR, "bot.db");

function initDB() {
  if (!fs.existsSync(DB_DIR)) {
    fs.mkdirSync(DB_DIR, { recursive: true });
  }

  db = new Database(DB_FILE);
  db.pragma("journal_mode = WAL"); // Better performance

  // ====================== EXISTING DATA STRUCTURES ======================
  db.exec(`
    CREATE TABLE IF NOT EXISTS levels (
      guild_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      xp INTEGER DEFAULT 0,
      level INTEGER DEFAULT 0,
      last_xp INTEGER,
      PRIMARY KEY (guild_id, user_id)
    );

    CREATE TABLE IF NOT EXISTS premium (
      guild_id TEXT PRIMARY KEY,
      active INTEGER DEFAULT 0,
      expires_at INTEGER,
      tier TEXT
    );

    CREATE TABLE IF NOT EXISTS settings (
      guild_id TEXT NOT NULL,
      key TEXT NOT NULL,
      value TEXT,
      PRIMARY KEY (guild_id, key)
    );

    CREATE TABLE IF NOT EXISTS logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT,
      type TEXT,
      data TEXT,
      timestamp INTEGER DEFAULT (strftime('%s', 'now') * 1000)
    );

    CREATE TABLE IF NOT EXISTS warnings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT,
      user_id TEXT,
      moderator_id TEXT,
      reason TEXT,
      timestamp INTEGER DEFAULT (strftime('%s', 'now') * 1000)
    );

    -- Storage for gen panels, giveaways, afk, etc. (JSON blobs for flexibility)
    CREATE TABLE IF NOT EXISTS storage (
      key TEXT PRIMARY KEY,
      data TEXT
    );

    CREATE TABLE IF NOT EXISTS clients (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      client_data TEXT
    );
  `);

  // ====================== NEW FEATURES FROM SELECTED LIST ======================
  db.exec(`
    -- Enhanced Tickets
    CREATE TABLE IF NOT EXISTS tickets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT,
      channel_id TEXT,
      user_id TEXT,
      status TEXT DEFAULT 'open',
      claimed_by TEXT,
      created_at INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      closed_at INTEGER,
      data TEXT
    );

    -- Advanced Applications
    CREATE TABLE IF NOT EXISTS applications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT,
      user_id TEXT,
      form_name TEXT,
      status TEXT DEFAULT 'pending',
      answers TEXT,
      reviewed_by TEXT,
      review_notes TEXT,
      created_at INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      reviewed_at INTEGER
    );

    CREATE TABLE IF NOT EXISTS application_forms (
      guild_id TEXT NOT NULL,
      name TEXT NOT NULL,
      questions TEXT,
      log_channel_id TEXT,
      accept_category_id TEXT,
      PRIMARY KEY (guild_id, name)
    );

    -- Polls
    CREATE TABLE IF NOT EXISTS polls (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT,
      message_id TEXT,
      channel_id TEXT,
      question TEXT,
      options TEXT,
      votes TEXT,
      created_by TEXT,
      created_at INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      expires_at INTEGER
    );

    -- Join to Create (temp voice)
    CREATE TABLE IF NOT EXISTS join2create_settings (
      guild_id TEXT PRIMARY KEY,
      enabled INTEGER DEFAULT 0,
      create_channel_id TEXT,
      category_id TEXT,
      default_name TEXT DEFAULT '{user}''s Channel',
      default_limit INTEGER DEFAULT 0,
      default_bitrate INTEGER DEFAULT 64000
    );

    CREATE TABLE IF NOT EXISTS temp_voice_channels (
      channel_id TEXT PRIMARY KEY,
      guild_id TEXT,
      owner_id TEXT,
      created_at INTEGER DEFAULT (strftime('%s', 'now') * 1000)
    );

    -- Vanity Roles
    CREATE TABLE IF NOT EXISTS vanity_config (
      guild_id TEXT PRIMARY KEY,
      enabled INTEGER DEFAULT 0,
      vanity_text TEXT,
      channel_id TEXT,
      message TEXT,
      roles TEXT
    );

    CREATE TABLE IF NOT EXISTS vanity_users (
      guild_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      adopted_at INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      PRIMARY KEY (guild_id, user_id)
    );

    -- User Profiles
    CREATE TABLE IF NOT EXISTS profiles (
      guild_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      bio TEXT,
      badges TEXT,
      married_to TEXT,
      friends TEXT,
      updated_at INTEGER DEFAULT (strftime('%s', 'now') * 1000),
      PRIMARY KEY (guild_id, user_id)
    );

    -- Persistent Timers
    CREATE TABLE IF NOT EXISTS timers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT,
      name TEXT,
      end_time INTEGER,
      message TEXT,
      paused INTEGER DEFAULT 0,
      created_by TEXT,
      created_at INTEGER DEFAULT (strftime('%s', 'now') * 1000)
    );

    -- Advanced Greet / Welcome
    CREATE TABLE IF NOT EXISTS greets (
      guild_id TEXT PRIMARY KEY,
      channels TEXT,
      mode TEXT DEFAULT 'simple',
      message TEXT,
      delete_after INTEGER DEFAULT 0,
      container_data TEXT
    );

    -- Message Activity Tracking + Leaderboards
    CREATE TABLE IF NOT EXISTS message_stats (
      guild_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      daily_count INTEGER DEFAULT 0,
      alltime_count INTEGER DEFAULT 0,
      last_reset INTEGER,
      PRIMARY KEY (guild_id, user_id)
    );

    -- Enhanced Invites
    CREATE TABLE IF NOT EXISTS invites (
      guild_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      total INTEGER DEFAULT 0,
      leaves INTEGER DEFAULT 0,
      rejoins INTEGER DEFAULT 0,
      fakes INTEGER DEFAULT 0,
      PRIMARY KEY (guild_id, user_id)
    );

    -- Automod Config
    CREATE TABLE IF NOT EXISTS automod_config (
      guild_id TEXT PRIMARY KEY,
      enabled INTEGER DEFAULT 0,
      anti_link INTEGER DEFAULT 0,
      anti_spam INTEGER DEFAULT 0,
      anti_mention INTEGER DEFAULT 0,
      anti_caps INTEGER DEFAULT 0,
      anti_emoji INTEGER DEFAULT 0,
      heat_threshold INTEGER DEFAULT 5,
      punishment TEXT DEFAULT 'warn'
    );

    -- Giveaways (enhanced storage)
    CREATE TABLE IF NOT EXISTS giveaways (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT,
      message_id TEXT,
      channel_id TEXT,
      prize TEXT,
      winners INTEGER,
      end_time INTEGER,
      required_role TEXT,
      reward_role TEXT,
      max_entries INTEGER,
      entries TEXT,
      ended INTEGER DEFAULT 0
    );

    -- Moderation utilities (snipe, etc.)
    CREATE TABLE IF NOT EXISTS snipe (
      guild_id TEXT,
      channel_id TEXT,
      message_id TEXT,
      content TEXT,
      author_id TEXT,
      deleted_at INTEGER DEFAULT (strftime('%s', 'now') * 1000)
    );

    -- General guild config (for new systems)
    CREATE TABLE IF NOT EXISTS guild_config (
      guild_id TEXT PRIMARY KEY,
      data TEXT
    );
  `);

  // Initialize default storage keys if empty
  const initStorage = db.prepare("INSERT OR IGNORE INTO storage (key, data) VALUES (?, ?)");
  const defaults = [
    ["genMessages", "[]"],
    ["purges", "{}"],
    ["giveaways", "{}"],
    ["afk", "{}"],
    ["scheduledAnnouncements", "[]"],
    ["genLogChannel", "null"],
    ["reactRoles", "{}"],
    ["lowStockAlerted", "false"]
  ];
  defaults.forEach(([k, v]) => initStorage.run(k, v));

  console.log("✅ SQLite database initialized at database/bot.db (auto-created all tables)");
  return db;
}

function getDB() {
  if (!db) {
    throw new Error("Database not initialized. Call initDB() first.");
  }
  return db;
}

// Helper functions for common operations (can be expanded)
function getSetting(guildId, key) {
  const row = getDB().prepare("SELECT value FROM settings WHERE guild_id = ? AND key = ?").get(guildId, key);
  if (!row) return null;
  try { return JSON.parse(row.value); } catch { return row.value; }
}

function setSetting(guildId, key, value) {
  const val = typeof value === "object" ? JSON.stringify(value) : value;
  getDB().prepare(`
    INSERT INTO settings (guild_id, key, value) VALUES (?, ?, ?)
    ON CONFLICT(guild_id, key) DO UPDATE SET value = excluded.value
  `).run(guildId, key, val);
}

function getStorage(key) {
  const row = getDB().prepare("SELECT data FROM storage WHERE key = ?").get(key);
  if (!row) return null;
  try { return JSON.parse(row.data); } catch { return row.data; }
}

function saveStorage(key, data) {
  const val = typeof data === "object" ? JSON.stringify(data) : data;
  getDB().prepare(`
    INSERT INTO storage (key, data) VALUES (?, ?)
    ON CONFLICT(key) DO UPDATE SET data = excluded.data
  `).run(key, val);
}

module.exports = {
  initDB,
  getDB,
  getSetting,
  setSetting,
  getStorage,
  saveStorage
};
