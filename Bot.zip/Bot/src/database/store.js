const fs = require("fs");
const path = require("path");
const { getDB, getSetting, setSetting, getStorage: getSqlStorage, saveStorage: saveSqlStorage } = require("./db");

// Legacy JSON compat (kept for any remaining direct usage during transition)
const DB_DIR = path.join(__dirname, "../../database");

function dbPath(name) {
  return path.join(DB_DIR, `${name}.json`);
}

function readJson(name) {
  const p = dbPath(name);
  if (!fs.existsSync(p)) return {};
  try { return JSON.parse(fs.readFileSync(p, "utf-8")); } catch { return {}; }
}

function writeJson(name, data) {
  fs.writeFileSync(dbPath(name), JSON.stringify(data, null, 2), "utf-8");
}

function updateJson(name, fn) {
  const data = readJson(name);
  const result = fn(data);
  writeJson(name, data);
  return result;
}

// New SQL-backed storage (preferred - uses the auto-created SQLite DB)
function getStorage(key = null) {
  if (key) {
    return getSqlStorage(key);
  }
  // Legacy full storage object for old code compatibility
  const keys = ["genMessages", "purges", "giveaways", "afk", "scheduledAnnouncements", "genLogChannel", "reactRoles"];
  const result = {};
  keys.forEach(k => {
    result[k] = getSqlStorage(k);
  });
  return result;
}

function saveStorage(keyOrData, data) {
  if (typeof keyOrData === "string") {
    saveSqlStorage(keyOrData, data);
  } else if (keyOrData && typeof keyOrData === "object") {
    // Legacy: save multiple
    Object.keys(keyOrData).forEach(k => saveSqlStorage(k, keyOrData[k]));
  }
}

function getConfig(guildId) {
  const db = getDB();
  const rows = db.prepare("SELECT key, value FROM settings WHERE guild_id = ?").all(guildId);
  const config = {};
  rows.forEach(row => {
    try { config[row.key] = JSON.parse(row.value); } catch { config[row.key] = row.value; }
  });
  return config;
}

function setConfig(guildId, key, value) {
  setSetting(guildId, key, value);
}

function getClients() {
  const db = getDB();
  const row = db.prepare("SELECT client_data FROM clients LIMIT 1").get();
  if (!row) return [];
  try { return JSON.parse(row.client_data); } catch { return []; }
}

function saveClients(list) {
  const db = getDB();
  const data = JSON.stringify(list);
  db.prepare(`
    INSERT OR REPLACE INTO clients (id, client_data) VALUES (1, ?)
  `).run(data);
}

module.exports = { 
  readJson, writeJson, updateJson, 
  getStorage, saveStorage, 
  getConfig, setConfig, 
  getClients, saveClients,
  // Direct new SQL helpers for new features
  getSetting, setSetting 
};