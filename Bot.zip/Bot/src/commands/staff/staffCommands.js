const { EmbedBuilder } = require("discord.js");
const { COLORS, STAFF_RANKS } = require("../../config");
const { getStaff, addStaff, removeStaff, promoteStaff, demoteStaff } = require("../../systems/staff");
const { isOwner } = require("../../utils/permissions");

module.exports = {
  name: "staff",
  async execute(message, args, client) {
    const cmd = (args[0] || "").toLowerCase();
    const guildId = message.guild.id;

    // LIST
    if (!cmd || cmd === "list") {
      const staff = getStaff(guildId);
      const entries = Object.entries(staff);
      if (!entries.length) return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.BOT).setTitle("👥 Staff List").setDescription("No staff members found.").setTimestamp()] });
      const grouped = {};
      for (const rank of STAFF_RANKS) grouped[rank] = [];
      for (const [userId, data] of entries) grouped[data.rank]?.push(`<@${userId}> (${data.username})`);
      const embed = new EmbedBuilder().setColor(COLORS.BOT).setTitle(`👥 ${message.guild.name} Staff`).setTimestamp();
      for (const rank of [...STAFF_RANKS].reverse()) {
        if (grouped[rank]?.length) embed.addFields({ name: `${rank.charAt(0).toUpperCase() + rank.slice(1).replace("_", " ")}`, value: grouped[rank].join("\n") });
      }
      return message.channel.send({ embeds: [embed] });
    }

    // INFO
    if (cmd === "info") {
      const target = message.mentions.users.first();
      if (!target) return message.channel.send("❌ Usage: `?gen staff info @user`");
      const staff = getStaff(guildId);
      const data = staff[target.id];
      if (!data) return message.channel.send(`❌ **${target.username}** is not a staff member.`);
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.BOT).setTitle(`👤 Staff Info — ${target.username}`).setThumbnail(target.displayAvatarURL({ dynamic: true })).addFields({ name: "🏷️ Rank", value: data.rank, inline: true }, { name: "📅 Added", value: `<t:${Math.floor(data.addedAt / 1000)}:R>`, inline: true }).setTimestamp()] });
    }

    // PROMOTE
    if (cmd === "promote") {
      if (!isOwner(message.author.id)) return message.channel.send("❌ Owner only.");
      const target = message.mentions.users.first();
      if (!target) return message.channel.send("❌ Usage: `?gen staff promote @user`");
      const newRank = promoteStaff(guildId, target.id);
      if (!newRank) return message.channel.send(`❌ Could not promote **${target.username}**. Already at max rank or not staff.`);
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("⬆️ Staff Promoted").addFields({ name: "User", value: target.username, inline: true }, { name: "New Rank", value: newRank, inline: true }).setTimestamp()] });
    }

    // DEMOTE
    if (cmd === "demote") {
      if (!isOwner(message.author.id)) return message.channel.send("❌ Owner only.");
      const target = message.mentions.users.first();
      if (!target) return message.channel.send("❌ Usage: `?gen staff demote @user`");
      const newRank = demoteStaff(guildId, target.id);
      if (!newRank) return message.channel.send(`❌ Could not demote **${target.username}**. Already at lowest rank or not staff.`);
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.WARN).setTitle("⬇️ Staff Demoted").addFields({ name: "User", value: target.username, inline: true }, { name: "New Rank", value: newRank, inline: true }).setTimestamp()] });
    }

    return message.channel.send("❌ Usage: `?gen staff <list|info|promote|demote>`");
  },
};
