const { EmbedBuilder, ChannelType, PermissionFlagsBits } = require("discord.js");
const { COLORS } = require("../../config");

module.exports = {
  name: "embed",
  async execute(message, args, client) {
    const parts = args.slice(1).join(" ").split("|").map(p => p.trim());
    if (parts.length < 2) {
      return message.channel.send("❌ Usage: `?gen embed <title> | <description> | [color] | [footer] | [imageURL]`");
    }
    const emb = new EmbedBuilder()
      .setTitle(parts[0])
      .setDescription(parts[1])
      .setColor(parts[2] || COLORS.BOT)
      .setTimestamp();
    if (parts[3]) emb.setFooter({ text: parts[3] });
    if (parts[4]?.startsWith("http")) emb.setImage(parts[4]);
    await message.channel.send({ embeds: [emb] });
    await message.delete().catch(() => {});
  },
};
