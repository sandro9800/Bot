const { EmbedBuilder, PermissionFlagsBits } = require("discord.js");
const { COLORS } = require("../../config");

module.exports = {
  name: "role",
  async execute(message, args, client) {
    if (!message.member.permissions.has(PermissionFlagsBits.ManageRoles)) {
      return message.channel.send("❌ You need Manage Roles permission.");
    }
    const sub = (args[1] || "").toLowerCase();
    const target = message.mentions.members.first();
    const role = message.mentions.roles.first();

    if (sub === "add") {
      if (!target || !role) return message.channel.send("❌ Usage: `?gen role add @user @role`");
      try {
        await target.roles.add(role);
        await message.channel.send(`✅ Added **${role.name}** to ${target}.`);
      } catch (err) { await message.channel.send(`❌ Failed: ${err.message}`); }
    }
    else if (sub === "remove") {
      if (!target || !role) return message.channel.send("❌ Usage: `?gen role remove @user @role`");
      try {
        await target.roles.remove(role);
        await message.channel.send(`✅ Removed **${role.name}** from ${target}.`);
      } catch (err) { await message.channel.send(`❌ Failed: ${err.message}`); }
    }
    else if (sub === "create") {
      const name = args.slice(2).join(" ");
      if (!name) return message.channel.send("❌ Usage: `?gen role create <name>`");
      try {
        const newRole = await message.guild.roles.create({ name });
        await message.channel.send(`✅ Role **${newRole.name}** created.`);
      } catch (err) { await message.channel.send(`❌ Failed: ${err.message}`); }
    }
    else if (sub === "delete") {
      if (!role) return message.channel.send("❌ Usage: `?gen role delete @role`");
      try {
        const name = role.name;
        await role.delete();
        await message.channel.send(`✅ Role **${name}** deleted.`);
      } catch (err) { await message.channel.send(`❌ Failed: ${err.message}`); }
    }
    else if (sub === "info") {
      if (!role) return message.channel.send("❌ Usage: `?gen role info @role`");
      await message.channel.send({ embeds: [new EmbedBuilder().setColor(role.hexColor || COLORS.BOT).setTitle(`🎭 Role — ${role.name}`).addFields(
        { name: "🆔 ID", value: `\`${role.id}\``, inline: true },
        { name: "🎨 Color", value: role.hexColor, inline: true },
        { name: "👥 Members", value: `**${role.members.size}**`, inline: true },
        { name: "📌 Position", value: `**${role.position}**`, inline: true },
        { name: "🔔 Mentionable", value: role.mentionable ? "Yes" : "No", inline: true },
        { name: "📅 Created", value: `<t:${Math.floor(role.createdTimestamp / 1000)}:R>`, inline: true },
      ).setTimestamp()] });
    }
    else {
      await message.channel.send("❌ Usage: `?gen role <add|remove|create|delete|info>`");
    }
    await message.delete().catch(() => {});
  },
};
