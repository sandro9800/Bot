const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { sendModLog } = require("../../systems/moderation");

module.exports = {
  name: "unban",
  async execute(message, args, client) {
    const userId = args[1];
    const reason = args.slice(2).join(" ") || "No reason provided";
    if (!userId) return message.channel.send("❌ Usage: `?gen unban <userId> [reason]`");
    try {
      const banned = await message.guild.bans.fetch(userId).catch(() => null);
      if (!banned) return message.channel.send("❌ That user is not banned.");
      await message.guild.bans.remove(userId, reason);
      const embed = new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("✅ User Unbanned").addFields({ name: "User", value: `${banned.user.tag} (\`${userId}\`)`, inline: true }, { name: "Reason", value: reason }).setFooter({ text: `By ${message.author.tag}` }).setTimestamp();
      await message.channel.send({ embeds: [embed] });
      await sendModLog(message.guild, embed);
    } catch (err) {
      await message.channel.send(`❌ Failed: ${err.message}`);
    }
    await message.delete().catch(() => {});
  },
};
