const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");

module.exports = {
  name: "mutelist",
  async execute(message, args, client) {
    await message.guild.members.fetch();
    const muted = message.guild.members.cache.filter(m => m.communicationDisabledUntilTimestamp && m.communicationDisabledUntilTimestamp > Date.now());
    if (!muted.size) return message.channel.send("✅ No users currently timed out.");
    const desc = muted.map(m => `${m} (${m.user.tag}) — expires <t:${Math.floor(m.communicationDisabledUntilTimestamp / 1000)}:R>`).join("\n").slice(0, 4000);
    return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.BOT).setTitle(`⏰ Timed Out Users (${muted.size})`).setDescription(desc).setTimestamp()] });
  },
};
