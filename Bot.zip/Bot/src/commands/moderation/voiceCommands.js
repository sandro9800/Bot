const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { sendModLog } = require("../../systems/moderation");

module.exports = [
  {
    name: "voicemove",
    async execute(message, args, client) {
      const target = message.mentions.members.first();
      const channel = message.mentions.channels.first();
      if (!target || !channel) return message.channel.send("❌ Usage: `?gen voicemove @user #channel`");
      if (!target.voice.channel) return message.channel.send("❌ That user is not in a voice channel.");
      try {
        await target.voice.setChannel(channel);
        const embed = new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("🔀 User Moved").addFields({ name: "User", value: target.user.tag, inline: true }, { name: "Channel", value: `${channel}`, inline: true }).setFooter({ text: `By ${message.author.tag}` }).setTimestamp();
        await message.channel.send({ embeds: [embed] });
        await sendModLog(message.guild, embed);
      } catch (err) { await message.channel.send(`❌ Failed: ${err.message}`); }
      await message.delete().catch(() => {});
    },
  },
  {
    name: "voicekick",
    async execute(message, args, client) {
      const target = message.mentions.members.first();
      if (!target) return message.channel.send("❌ Usage: `?gen voicekick @user`");
      if (!target.voice.channel) return message.channel.send("❌ That user is not in a voice channel.");
      try {
        await target.voice.disconnect();
        const embed = new EmbedBuilder().setColor(COLORS.ERROR).setTitle("🎙️ Voice Kicked").addFields({ name: "User", value: target.user.tag, inline: true }).setFooter({ text: `By ${message.author.tag}` }).setTimestamp();
        await message.channel.send({ embeds: [embed] });
        await sendModLog(message.guild, embed);
      } catch (err) { await message.channel.send(`❌ Failed: ${err.message}`); }
      await message.delete().catch(() => {});
    },
  },
];
