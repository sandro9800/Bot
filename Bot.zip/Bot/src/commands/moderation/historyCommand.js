const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { getWarnings } = require("../../systems/moderation");
const { getReports } = require("../../systems/reports");

module.exports = {
  name: "history",
  async execute(message, args, client) {
    const target = message.mentions.users.first();
    if (!target) return message.channel.send("❌ Usage: `?gen history @user`");

    const guildId = message.guild.id;
    const warns = getWarnings(target.id, guildId);
    const reports = getReports(guildId).filter(r => r.targetId === target.id);

    const embed = new EmbedBuilder()
      .setColor(COLORS.BOT)
      .setTitle(`📋 Punishment History — ${target.tag}`)
      .setThumbnail(target.displayAvatarURL({ dynamic: true }))
      .setTimestamp();

    if (warns.length) {
      embed.addFields({
        name: `⚠️ Warnings (${warns.length})`,
        value: warns.slice(0, 5).map((w, i) => `**${i + 1}.** ${w.reason} — by <@${w.moderatorId}> (<t:${Math.floor(w.timestamp / 1000)}:R>)`).join("\n").slice(0, 1024),
      });
    } else {
      embed.addFields({ name: "⚠️ Warnings", value: "None", inline: true });
    }

    if (reports.length) {
      embed.addFields({
        name: `🚨 Reports (${reports.length})`,
        value: reports.slice(0, 5).map((r, i) => `**${i + 1}.** ${r.reason} — by ${r.reporterTag} [${r.status}]`).join("\n").slice(0, 1024),
      });
    } else {
      embed.addFields({ name: "🚨 Reports", value: "None", inline: true });
    }

    return message.channel.send({ embeds: [embed] });
  },
};
