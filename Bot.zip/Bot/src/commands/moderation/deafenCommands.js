const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { sendModLog } = require("../../systems/moderation");

module.exports = [
  {
    name: "deafen",
    async execute(message, args, client) {
      const target = message.mentions.members.first();
      if (!target) return message.channel.send("❌ Usage: `?gen deafen @user`");
      if (!target.voice.channel) return message.channel.send("❌ That user is not in a voice channel.");
      try {
        await target.voice.setDeaf(true);
        const embed = new EmbedBuilder().setColor(COLORS.WARN).setTitle("🔇 User Deafened").addFields({ name: "User", value: target.user.tag, inline: true }).setFooter({ text: `By ${message.author.tag}` }).setTimestamp();
        await message.channel.send({ embeds: [embed] });
        await sendModLog(message.guild, embed);
      } catch (err) { await message.channel.send(`❌ Failed: ${err.message}`); }
      await message.delete().catch(() => {});
    },
  },
  {
    name: "undeafen",
    async execute(message, args, client) {
      const target = message.mentions.members.first();
      if (!target) return message.channel.send("❌ Usage: `?gen undeafen @user`");
      if (!target.voice.channel) return message.channel.send("❌ That user is not in a voice channel.");
      try {
        await target.voice.setDeaf(false);
        const embed = new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("🔊 User Undeafened").addFields({ name: "User", value: target.user.tag, inline: true }).setFooter({ text: `By ${message.author.tag}` }).setTimestamp();
        await message.channel.send({ embeds: [embed] });
        await sendModLog(message.guild, embed);
      } catch (err) { await message.channel.send(`❌ Failed: ${err.message}`); }
      await message.delete().catch(() => {});
    },
  },
];
