const { EmbedBuilder, ChannelType, PermissionFlagsBits } = require("discord.js");
const { COLORS } = require("../../config");

module.exports = {
  name: "channel",
  async execute(message, args, client) {
    if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
      return message.channel.send("❌ You need Manage Channels permission.");
    }
    const sub = (args[1] || "").toLowerCase();

    if (sub === "create") {
      const name = args[2];
      const type = (args[3] || "text").toLowerCase();
      if (!name) return message.channel.send("❌ Usage: `?gen channel create <name> [text/voice]`");
      const ch = await message.guild.channels.create({ name, type: type === "voice" ? ChannelType.GuildVoice : ChannelType.GuildText });
      await message.channel.send(`✅ Channel ${ch} created.`);
    }
    else if (sub === "delete") {
      const target = message.mentions.channels.first();
      if (!target) return message.channel.send("❌ Usage: `?gen channel delete #channel`");
      const name = target.name;
      await target.delete();
      await message.channel.send(`✅ Channel \`#${name}\` deleted.`);
    }
    else if (sub === "rename") {
      const target = message.mentions.channels.first();
      const newName = args[3];
      if (!target || !newName) return message.channel.send("❌ Usage: `?gen channel rename #channel <name>`");
      await target.setName(newName);
      await message.channel.send(`✅ Channel renamed to **${newName}**.`);
    }
    else if (sub === "clone") {
      const target = message.mentions.channels.first();
      if (!target) return message.channel.send("❌ Usage: `?gen channel clone #channel`");
      const cloned = await target.clone();
      await message.channel.send(`✅ Channel cloned: ${cloned}`);
    }
    else if (sub === "topic") {
      const target = message.mentions.channels.first() || message.channel;
      const topic = args.slice(3).join(" ");
      if (!topic) return message.channel.send("❌ Usage: `?gen channel topic [#channel] <topic>`");
      await target.setTopic(topic);
      await message.channel.send(`✅ Topic set for ${target}.`);
    }
    else {
      await message.channel.send("❌ Usage: `?gen channel <create|delete|rename|clone|topic>`");
    }
    await message.delete().catch(() => {});
  },
};
