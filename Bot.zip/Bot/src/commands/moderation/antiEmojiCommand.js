const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { setConfig, getConfig } = require("../../database/store");

module.exports = {
  name: "antiemoji",
  async execute(message, args, client) {
    const sub = (args[1] || "").toLowerCase();
    const guildId = message.guild.id;

    if (sub === "on") {
      setConfig(guildId, "antiEmojiEnabled", true);
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("✅ Anti-Emoji Enabled").setDescription("Messages with too many emojis will be deleted.").setTimestamp()] });
    }

    if (sub === "off") {
      setConfig(guildId, "antiEmojiEnabled", false);
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.ERROR).setTitle("❌ Anti-Emoji Disabled").setTimestamp()] });
    }

    if (sub === "threshold") {
      const amount = parseInt(args[2]);
      if (!amount || amount < 1) return message.channel.send("❌ Usage: `?gen antiemoji threshold <number>`");
      setConfig(guildId, "antiEmojiThreshold", amount);
      return message.channel.send(`✅ Anti-emoji threshold set to **${amount}** emojis.`);
    }

    const config = getConfig(guildId);
    return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.BOT).setTitle("😀 Anti-Emoji Status").addFields({ name: "Status", value: config.antiEmojiEnabled ? "✅ Enabled" : "❌ Disabled", inline: true }, { name: "Threshold", value: `**${config.antiEmojiThreshold || 10}** emojis`, inline: true }).setFooter({ text: "Usage: ?gen antiemoji <on|off|threshold <number>>" }).setTimestamp()] });
  },
};
