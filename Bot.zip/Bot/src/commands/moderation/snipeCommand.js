const { EmbedBuilder } = require("discord.js");
const { getSnipe } = require("../../systems/snipe");
const { COLORS } = require("../../config");

module.exports = {
  name: "snipe",
  description: "View the last deleted message in this channel",
  type: "slash",

  async execute(interaction) {
    const snipe = getSnipe(interaction.guild.id, interaction.channel.id);
    if (!snipe) {
      return interaction.reply({ content: "No recently deleted message in this channel.", ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor(COLORS.INFO)
      .setTitle("🕵️ Last Deleted Message")
      .setDescription(snipe.content)
      .setFooter({ text: `Deleted by <@${snipe.author_id}>` })
      .setTimestamp(new Date(snipe.deleted_at));

    await interaction.reply({ embeds: [embed] });
  }
};
