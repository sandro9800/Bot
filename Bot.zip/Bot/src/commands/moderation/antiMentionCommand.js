const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { setConfig, getConfig } = require("../../database/store");

module.exports = {
  name: "antimention",
  async execute(message, args, client) {
    const sub = (args[1] || "").toLowerCase();
    const guildId = message.guild.id;

    if (sub === "on") {
      setConfig(guildId, "antiMentionEnabled", true);
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("✅ Anti-Mention Enabled").setDescription("Mass mentions will now be automatically blocked.").setTimestamp()] });
    }
    if (sub === "off") {
      setConfig(guildId, "antiMentionEnabled", false);
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.ERROR).setTitle("❌ Anti-Mention Disabled").setTimestamp()] });
    }
    if (sub === "threshold") {
      const amount = parseInt(args[2]);
      if (!amount || amount < 1) return message.channel.send("❌ Usage: `?gen antimention threshold <number>`");
      setConfig(guildId, "antiMentionThreshold", amount);
      return message.channel.send(`✅ Anti-mention threshold set to **${amount}** mentions.`);
    }

    const config = getConfig(guildId);
    return message.channel.send(`Anti-mention is **${config.antiMentionEnabled ? "enabled" : "disabled"}**. Threshold: **${config.antiMentionThreshold || 5}** mentions.\nUsage: \`?gen antimention <on|off|threshold <number>>\``);
  },
};
