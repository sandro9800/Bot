const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");

module.exports = {
  name: "purgeuser",
  async execute(message, args, client) {
    const target = message.mentions.users.first();
    const amount = parseInt(args[2]) || 100;
    if (!target) return message.channel.send("❌ Usage: `?gen purgeuser @user [amount]`");
    if (amount < 1 || amount > 100) return message.channel.send("❌ Amount must be 1-100.");

    try {
      const messages = await message.channel.messages.fetch({ limit: 100 });
      const toDelete = messages.filter(m => m.author.id === target.id && Date.now() - m.createdTimestamp < 14 * 86400000).first(amount);
      if (!toDelete.length) return message.channel.send("❌ No recent messages found from that user.");
      await message.channel.bulkDelete(toDelete, true);
      const notice = await message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("🗑️ Messages Purged").addFields({ name: "User", value: target.tag, inline: true }, { name: "Deleted", value: `**${toDelete.length}**`, inline: true }).setTimestamp()] });
      setTimeout(() => notice.delete().catch(() => {}), 5000);
    } catch (err) {
      await message.channel.send(`❌ Failed: ${err.message}`);
    }
    await message.delete().catch(() => {});
  },
};
