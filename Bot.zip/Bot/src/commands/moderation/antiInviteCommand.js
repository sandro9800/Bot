const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { setConfig, getConfig } = require("../../database/store");

module.exports = {
  name: "antiinvite",
  async execute(message, args, client) {
    const toggle = (args[1] || "").toLowerCase();
    const guildId = message.guild.id;

    if (toggle === "on") {
      setConfig(guildId, "antiInviteEnabled", true);
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("✅ Anti-Invite Enabled").setDescription("Discord invite links will now be automatically deleted.").setTimestamp()] });
    }
    if (toggle === "off") {
      setConfig(guildId, "antiInviteEnabled", false);
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.ERROR).setTitle("❌ Anti-Invite Disabled").setTimestamp()] });
    }

    const current = getConfig(guildId).antiInviteEnabled;
    return message.channel.send(`Anti-invite is currently **${current ? "enabled" : "disabled"}**.\nUsage: \`?gen antiinvite on/off\``);
  },
};
