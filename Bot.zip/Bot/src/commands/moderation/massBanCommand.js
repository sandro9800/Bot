const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { isOwner } = require("../../utils/permissions");
const { sendModLog } = require("../../systems/moderation");

module.exports = {
  name: "massban",
  async execute(message, args, client) {
    if (!isOwner(message.author.id)) return message.channel.send("❌ Owner only.");
    const ids = args.slice(1).filter(id => /^\d{17,19}$/.test(id));
    const reason = "Mass ban";
    if (!ids.length) return message.channel.send("❌ Usage: `?gen massban <userId1> <userId2> ...`");

    let success = 0, failed = 0;
    for (const id of ids) {
      try { await message.guild.bans.create(id, { reason }); success++; } catch (_) { failed++; }
    }

    const embed = new EmbedBuilder().setColor(COLORS.ERROR).setTitle("🔨 Mass Ban Complete").addFields({ name: "✅ Banned", value: `**${success}**`, inline: true }, { name: "❌ Failed", value: `**${failed}**`, inline: true }).setFooter({ text: `By ${message.author.tag}` }).setTimestamp();
    await message.channel.send({ embeds: [embed] });
    await sendModLog(message.guild, embed);
    await message.delete().catch(() => {});
  },
};
