const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { sendModLog } = require("../../systems/moderation");

module.exports = {
  name: "unmute",
  async execute(message, args, client) {
    const target = message.mentions.members.first();
    const reason = args.slice(2).join(" ") || "No reason provided";
    if (!target) return message.channel.send("❌ Usage: `?gen unmute @user [reason]`");
    if (!target.communicationDisabledUntilTimestamp) return message.channel.send("❌ That user is not muted.");
    try {
      await target.timeout(null, reason);
      const embed = new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("🔊 User Unmuted").addFields({ name: "User", value: target.user.tag, inline: true }, { name: "Reason", value: reason }).setFooter({ text: `By ${message.author.tag}` }).setTimestamp();
      await message.channel.send({ embeds: [embed] });
      await sendModLog(message.guild, embed);
      try { await target.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle(`🔊 Unmuted in ${message.guild.name}`).addFields({ name: "Reason", value: reason }).setTimestamp()] }); } catch (_) {}
    } catch (err) {
      await message.channel.send(`❌ Failed: ${err.message}`);
    }
    await message.delete().catch(() => {});
  },
};
