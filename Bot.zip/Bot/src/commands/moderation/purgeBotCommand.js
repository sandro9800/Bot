const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");

module.exports = {
  name: "purgebot",
  async execute(message, args, client) {
    const amount = parseInt(args[1]) || 100;
    if (amount < 1 || amount > 100) return message.channel.send("❌ Amount must be 1-100.");
    try {
      const messages = await message.channel.messages.fetch({ limit: 100 });
      const toDelete = messages.filter(m => m.author.bot && Date.now() - m.createdTimestamp < 14 * 86400000).first(amount);
      if (!toDelete.length) return message.channel.send("❌ No recent bot messages found.");
      await message.channel.bulkDelete(toDelete, true);
      const notice = await message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("🗑️ Bot Messages Purged").addFields({ name: "Deleted", value: `**${toDelete.length}**`, inline: true }).setTimestamp()] });
      setTimeout(() => notice.delete().catch(() => {}), 5000);
    } catch (err) {
      await message.channel.send(`❌ Failed: ${err.message}`);
    }
    await message.delete().catch(() => {});
  },
};
