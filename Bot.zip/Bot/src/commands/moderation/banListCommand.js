const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");

module.exports = {
  name: "banlist",
  async execute(message, args, client) {
    try {
      const bans = await message.guild.bans.fetch();
      if (!bans.size) return message.channel.send("✅ No banned users.");
      const page = parseInt(args[1]) || 1;
      const perPage = 10;
      const pages = Math.ceil(bans.size / perPage);
      const slice = [...bans.values()].slice((page - 1) * perPage, page * perPage);
      const desc = slice.map((b, i) => `**${(page - 1) * perPage + i + 1}.** ${b.user.tag} (\`${b.user.id}\`)${b.reason ? ` — ${b.reason}` : ""}`).join("\n");
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.BOT).setTitle(`🔨 Ban List (${bans.size} total)`).setDescription(desc).setFooter({ text: `Page ${page}/${pages} • Use ?gen banlist <page>` }).setTimestamp()] });
    } catch (err) {
      return message.channel.send(`❌ Failed: ${err.message}`);
    }
  },
};
