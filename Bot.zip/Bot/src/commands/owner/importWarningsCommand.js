const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { readJson, writeJson } = require("../../database/store");
const { isOwner } = require("../../utils/permissions");

module.exports = {
  name: "importwarnings",
  async execute(message, args, client) {
    if (!isOwner(message.author.id)) return message.channel.send("❌ Owner only.");
    const attachment = message.attachments.first();
    if (!attachment?.name.endsWith(".csv")) return message.channel.send("❌ Please attach a `.csv` file exported with `?gen exportwarnings`.");

    try {
      const { default: fetch } = require("node-fetch");
      const res = await fetch(attachment.url);
      const text = await res.text();
      const lines = text.split("\n").slice(1).filter(l => l.trim());

      const db = readJson("logs");
      if (!db.warnings) db.warnings = {};
      if (!db.warnings[message.guild.id]) db.warnings[message.guild.id] = {};

      let count = 0;
      for (const line of lines) {
        const [userId, moderatorId, reason, timestamp] = line.split(",");
        if (!userId || !moderatorId) continue;
        if (!db.warnings[message.guild.id][userId]) db.warnings[message.guild.id][userId] = [];
        db.warnings[message.guild.id][userId].push({ moderatorId, reason: reason || "Imported", timestamp: new Date(timestamp).getTime() || Date.now() });
        count++;
      }
      writeJson("logs", db);
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("✅ Warnings Imported").addFields({ name: "Imported", value: `**${count}** warnings` }).setTimestamp()] });
    } catch (err) {
      return message.channel.send(`❌ Failed: ${err.message}`);
    }
  },
};
