const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { isOwner } = require("../../utils/permissions");
const { setConfig, getConfig } = require("../../database/store");
const { addXP } = require("../../systems/levels");
const { addPremiumUser } = require("../../systems/premium");
const { parseInterval } = require("../../utils/format");

module.exports = {
  name: "boostconfig",
  async execute(message, args, client) {
    if (!isOwner(message.author.id)) return message.channel.send("❌ Owner only.");
    const sub = (args[1] || "").toLowerCase();
    const guildId = message.guild.id;

    if (sub === "channel") {
      const ch = message.mentions.channels.first();
      if (!ch) return message.channel.send("❌ Usage: `?gen boostconfig channel #channel`");
      setConfig(guildId, "boostChannel", ch.id);
      return message.channel.send(`✅ Boost announcements set to ${ch}.`);
    }

    if (sub === "role") {
      const role = message.mentions.roles.first();
      const durationStr = args[3];
      if (!role) return message.channel.send("❌ Usage: `?gen boostconfig role @role [duration]`");
      let expiresAfter = null;
      if (durationStr) { const ms = parseInterval(durationStr); if (ms) expiresAfter = ms; }
      setConfig(guildId, "boostRole", { roleId: role.id, expiresAfter });
      return message.channel.send(`✅ Boosters will receive ${role}${expiresAfter ? ` for **${durationStr}**` : " permanently"}.`);
    }

    if (sub === "xp") {
      const amount = parseInt(args[2]);
      if (!amount || amount < 1) return message.channel.send("❌ Usage: `?gen boostconfig xp <amount>`");
      setConfig(guildId, "boostXp", amount);
      return message.channel.send(`✅ Boosters will receive **+${amount} XP** on boost.`);
    }

    if (sub === "message") {
      const msg = args.slice(2).join(" ");
      if (!msg) return message.channel.send("❌ Usage: `?gen boostconfig message <text>` (use {user} and {guild})`");
      setConfig(guildId, "boostMessage", msg);
      return message.channel.send(`✅ Boost message set to: ${msg}`);
    }

    const config = getConfig(guildId);
    return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.BOT).setTitle("🚀 Boost Config").addFields(
      { name: "Channel", value: config.boostChannel ? `<#${config.boostChannel}>` : "Not set", inline: true },
      { name: "Role", value: config.boostRole ? `<@&${config.boostRole.roleId}>` : "Not set", inline: true },
      { name: "Bonus XP", value: config.boostXp ? `**${config.boostXp}**` : "Not set", inline: true },
      { name: "Message", value: config.boostMessage || "Default", inline: false },
    ).setTimestamp()] });
  },
};
