const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { getLevelRewards, addLevelReward, removeLevelReward } = require("../../systems/levelRewards");
const { isOwner } = require("../../utils/permissions");

module.exports = {
  name: "levelreward",
  async execute(message, args, client) {
    if (!isOwner(message.author.id)) return message.channel.send("❌ Owner only.");
    const sub = (args[1] || "").toLowerCase();
    const guildId = message.guild.id;

    if (sub === "add") {
      const level = parseInt(args[2]);
      const role = message.mentions.roles.first();
      if (!level || !role) return message.channel.send("❌ Usage: `?gen levelreward add <level> @role`");
      addLevelReward(guildId, level, role.id);
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("✅ Level Reward Added").addFields({ name: "Level", value: `**${level}**`, inline: true }, { name: "Role", value: `${role}`, inline: true }).setTimestamp()] });
    }

    if (sub === "remove") {
      const level = parseInt(args[2]);
      if (!level) return message.channel.send("❌ Usage: `?gen levelreward remove <level>`");
      const ok = removeLevelReward(guildId, level);
      if (!ok) return message.channel.send(`❌ No reward set for level **${level}**.`);
      return message.channel.send(`✅ Reward for level **${level}** removed.`);
    }

    if (sub === "list" || !sub) {
      const rewards = getLevelRewards(guildId);
      const entries = Object.entries(rewards);
      if (!entries.length) return message.channel.send("❌ No level rewards set.");
      const desc = entries.sort((a, b) => Number(a[0]) - Number(b[0])).map(([lvl, roleId]) => `**Level ${lvl}** → <@&${roleId}>`).join("\n");
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.BOT).setTitle("🎁 Level Rewards").setDescription(desc).setTimestamp()] });
    }

    return message.channel.send("❌ Usage: `?gen levelreward <add|remove|list>`");
  },
};
