const { EmbedBuilder } = require("discord.js");
const { getJoin2CreateSettings, setJoin2CreateSettings } = require("../../systems/join2create");
const { COLORS } = require("../../config");
const { isOwner } = require("../../utils/permissions");

module.exports = {
  name: "join2create",
  async execute(message, args, client) {
    if (!isOwner(message.author.id)) return message.reply("Owner only.");

    const sub = (args[0] || "").toLowerCase();
    const guildId = message.guild.id;

    if (sub === "setup") {
      const createCh = message.mentions.channels.first() || message.channel;
      const category = message.guild.channels.cache.find(c => c.name.toLowerCase().includes("voice") && c.type === 4);

      setJoin2CreateSettings(guildId, {
        enabled: true,
        create_channel_id: createCh.id,
        category_id: category ? category.id : null,
        default_name: "{user}'s Channel",
        default_limit: 0,
        default_bitrate: 64000
      });
      return message.reply(`✅ Join2Create setup. Create channel: ${createCh}. Use panel command to send controls.`);
    }

    if (sub === "panel") {
      // For simplicity, just confirm - full button panel can be added later
      return message.reply("✅ Control panel would be sent here (implement persistent buttons in full version).");
    }

    return message.reply("Usage: ?gen join2create <setup|panel>");
  }
};
