const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { isOwner } = require("../../utils/permissions");
const { readJson, writeJson } = require("../../database/store");
const { getXPForLevel } = require("../../systems/levels");

module.exports = {
  name: "setlevel",
  async execute(message, args, client) {
    if (!isOwner(message.author.id)) return message.channel.send("❌ Owner only.");
    const target = message.mentions.members.first();
    const level = parseInt(args[2]);
    if (!target || isNaN(level) || level < 0) return message.channel.send("❌ Usage: `?gen setlevel @user <level>`");

    const db = readJson("levels");
    if (!db.guilds) db.guilds = {};
    if (!db.guilds[message.guild.id]) db.guilds[message.guild.id] = {};
    db.guilds[message.guild.id][target.id] = {
      level,
      xp: 0,
      totalXp: Array.from({ length: level }, (_, i) => getXPForLevel(i)).reduce((a, b) => a + b, 0),
      messages: db.guilds[message.guild.id][target.id]?.messages || 0,
      voiceXp: db.guilds[message.guild.id][target.id]?.voiceXp || 0,
    };
    writeJson("levels", db);

    return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("✅ Level Set").addFields({ name: "User", value: `${target}`, inline: true }, { name: "Level", value: `**${level}**`, inline: true }).setTimestamp()] });
  },
};
