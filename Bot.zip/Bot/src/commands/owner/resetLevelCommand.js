const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { isOwner } = require("../../utils/permissions");
const { readJson, writeJson } = require("../../database/store");

module.exports = {
  name: "resetlevel",
  async execute(message, args, client) {
    if (!isOwner(message.author.id)) return message.channel.send("❌ Owner only.");
    const target = message.mentions.members.first();
    const all = (args[1] || "").toLowerCase() === "all";

    if (all) {
      const db = readJson("levels");
      if (db.guilds?.[message.guild.id]) db.guilds[message.guild.id] = {};
      writeJson("levels", db);
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("✅ Leaderboard Reset").setDescription("All XP data for this server has been wiped.").setTimestamp()] });
    }

    if (!target) return message.channel.send("❌ Usage: `?gen resetlevel @user` or `?gen resetlevel all`");

    const db = readJson("levels");
    if (db.guilds?.[message.guild.id]) delete db.guilds[message.guild.id][target.id];
    writeJson("levels", db);

    return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("✅ Level Reset").addFields({ name: "User", value: `${target}`, inline: true }).setTimestamp()] });
  },
};
