const { EmbedBuilder } = require("discord.js");
const { getVanityConfig, setVanityConfig, getVanityUsers } = require("../../systems/vanity");
const { COLORS } = require("../../config");
const { isOwner } = require("../../utils/permissions");

module.exports = {
  name: "vanity",
  async execute(message, args, client) {
    if (!isOwner(message.author.id)) return message.reply("Owner only.");

    const sub = (args[0] || "").toLowerCase();
    const guildId = message.guild.id;

    if (sub === "enable") {
      const config = getVanityConfig(guildId);
      setVanityConfig(guildId, { ...config, enabled: true });
      return message.reply("✅ Vanity roles system enabled.");
    }

    if (sub === "set") {
      const vanityText = args[1];
      if (!vanityText) return message.reply("Usage: ?gen vanity set <text>");

      const roles = message.mentions.roles.map(r => r.id);
      const channel = message.mentions.channels.first();

      const current = getVanityConfig(guildId);
      setVanityConfig(guildId, {
        ...current,
        vanity_text: vanityText,
        channel_id: channel ? channel.id : current.channel_id,
        roles: roles.length ? roles : current.roles
      });
      return message.reply(`✅ Vanity set to \`${vanityText}\`. Roles: ${roles.length || "none"}`);
    }

    if (sub === "list") {
      const users = getVanityUsers(guildId);
      if (!users.length) return message.reply("No users currently have the vanity.");
      return message.reply(`Users with vanity: ${users.map(id => `<@${id}>`).join(", ")}`);
    }

    if (sub === "message") {
      const msg = args.slice(1).join(" ");
      if (!msg) return message.reply("Provide a message with placeholders like {user.mention}");
      const current = getVanityConfig(guildId);
      setVanityConfig(guildId, { ...current, message: msg });
      return message.reply("✅ Adoption message set.");
    }

    return message.reply("Usage: ?gen vanity <enable|set|list|message>");
  }
};
