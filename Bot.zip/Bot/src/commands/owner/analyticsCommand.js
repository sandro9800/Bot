const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { getTopCommands, getTopUsers, getDailyActivity } = require("../../systems/analytics");
const { isOwner } = require("../../utils/permissions");

module.exports = {
  name: "analytics",
  async execute(message, args, client) {
    if (!isOwner(message.author.id)) return message.channel.send("❌ Owner only.");
    const sub = (args[1] || "commands").toLowerCase();
    const guildId = message.guild.id;

    if (sub === "commands") {
      const top = getTopCommands(guildId, 10);
      if (!top.length) return message.channel.send("❌ No analytics data yet.");
      const desc = top.map(([cmd, count], i) => `**${i + 1}.** \`?gen ${cmd}\` — **${count}** uses`).join("\n");
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.BOT).setTitle("📊 Top Commands").setDescription(desc).setTimestamp()] });
    }

    if (sub === "users") {
      const top = getTopUsers(guildId, 10);
      if (!top.length) return message.channel.send("❌ No analytics data yet.");
      const desc = top.map(([userId, count], i) => `**${i + 1}.** <@${userId}> — **${count}** commands`).join("\n");
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.BOT).setTitle("👥 Most Active Users").setDescription(desc).setTimestamp()] });
    }

    if (sub === "daily") {
      const days = getDailyActivity(guildId, 7);
      const desc = days.map(d => `**${d.date}** — **${d.count}** commands`).join("\n");
      const total = days.reduce((s, d) => s + d.count, 0);
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.BOT).setTitle("📈 Daily Activity (7 days)").setDescription(desc).addFields({ name: "Total", value: `**${total}** commands`, inline: true }, { name: "Avg/Day", value: `**${(total / 7).toFixed(1)}**`, inline: true }).setTimestamp()] });
    }

    return message.channel.send("❌ Usage: `?gen analytics <commands|users|daily>`");
  },
};
