const { EmbedBuilder } = require("discord.js");
const { getGreetConfig, setGreetConfig } = require("../../systems/greets");
const { COLORS } = require("../../config");
const { isOwner } = require("../../utils/permissions");

module.exports = {
  name: "greet",
  async execute(message, args, client) {
    if (!isOwner(message.author.id)) return message.reply("Owner only.");

    const sub = (args[0] || "").toLowerCase();
    const guildId = message.guild.id;

    if (sub === "setup") {
      const channels = message.mentions.channels.map(c => c.id);
      if (!channels.length) return message.reply("Mention at least one channel for greets.");

      setGreetConfig(guildId, {
        channels,
        mode: "simple",
        message: "Welcome {user.mention} to {server.name}!",
        delete_after: 3600
      });
      return message.reply("✅ Greet system configured.");
    }

    if (sub === "test") {
      const config = getGreetConfig(guildId);
      return message.reply(`Current greet: ${config.message || "Not set"} (mode: ${config.mode})`);
    }

    return message.reply("Usage: ?gen greet <setup|test>");
  }
};
