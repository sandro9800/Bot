const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { isOwner } = require("../../utils/permissions");
const { setConfig, getConfig } = require("../../database/store");

module.exports = {
  name: "leveling",
  async execute(message, args, client) {
    if (!isOwner(message.author.id)) return message.channel.send("❌ Owner only.");
    const sub = (args[1] || "").toLowerCase();
    const guildId = message.guild.id;

    if (sub === "on") {
      setConfig(guildId, "levelingEnabled", true);
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("✅ Leveling Enabled").setDescription("XP and level tracking is now active.").setTimestamp()] });
    }

    if (sub === "off") {
      setConfig(guildId, "levelingEnabled", false);
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.ERROR).setTitle("❌ Leveling Disabled").setDescription("XP and level tracking has been disabled.").setTimestamp()] });
    }

    if (sub === "status") {
      const config = getConfig(guildId);
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.BOT).setTitle("📊 Leveling Status").addFields(
        { name: "Enabled", value: config.levelingEnabled !== false ? "✅ Yes" : "❌ No", inline: true },
        { name: "Level Channel", value: config.levelChannel ? `<#${config.levelChannel}>` : "Not set", inline: true },
        { name: "Log Channel", value: config.logChannel ? `<#${config.logChannel}>` : "Not set", inline: true },
      ).setTimestamp()] });
    }

    return message.channel.send("❌ Usage: `?gen leveling <on|off|status>`");
  },
};
