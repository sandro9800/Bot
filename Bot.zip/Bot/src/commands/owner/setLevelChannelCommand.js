const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { isOwner } = require("../../utils/permissions");
const { setConfig } = require("../../database/store");

module.exports = {
  name: "setlevelchannel",
  async execute(message, args, client) {
    if (!isOwner(message.author.id)) return message.channel.send("❌ Owner only.");
    const ch = message.mentions.channels.first();
    if (!ch) return message.channel.send("❌ Usage: `?gen setlevelchannel #channel`");
    setConfig(message.guild.id, "levelChannel", ch.id);
    return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("✅ Level Channel Set").setDescription(`Level up messages will be sent to ${ch}.`).setTimestamp()] });
  },
};
