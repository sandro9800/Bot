const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { isOwner } = require("../../utils/permissions");
const path = require("path");
const fs = require("fs");

module.exports = {
  name: "reload",
  async execute(message, args, client) {
    if (!isOwner(message.author.id)) return message.channel.send("❌ Owner only.");
    const target = (args[1] || "").toLowerCase();

    if (target === "commands") {
      const cmdDir = path.join(__dirname, "..");
      const categories = fs.readdirSync(cmdDir);
      let count = 0;
      for (const cat of categories) {
        const catPath = path.join(cmdDir, cat);
        if (!fs.statSync(catPath).isDirectory()) continue;
        for (const file of fs.readdirSync(catPath).filter(f => f.endsWith(".js"))) {
          const filePath = path.join(catPath, file);
          delete require.cache[require.resolve(filePath)];
          const cmd = require(filePath);
          if (cmd.name) { client.commands.set(cmd.name, cmd); count++; }
        }
      }
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("🔄 Commands Reloaded").addFields({ name: "Count", value: `**${count}** commands reloaded` }).setTimestamp()] });
    }

    if (target === "events") {
      client.removeAllListeners();
      const evDir = path.join(__dirname, "../../events");
      const files = fs.readdirSync(evDir).filter(f => f.endsWith(".js"));
      let count = 0;
      for (const file of files) {
        const filePath = path.join(evDir, file);
        delete require.cache[require.resolve(filePath)];
        const exported = require(filePath);
        const events = Array.isArray(exported) ? exported : [exported];
        for (const event of events) {
          if (!event.name) continue;
          if (event.once) client.once(event.name, (...a) => event.execute(client, ...a));
          else client.on(event.name, (...a) => event.execute(client, ...a));
          count++;
        }
      }
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("🔄 Events Reloaded").addFields({ name: "Count", value: `**${count}** events reloaded` }).setTimestamp()] });
    }

    if (target === "systems") {
      const sysDir = path.join(__dirname, "../../systems");
      const files = fs.readdirSync(sysDir).filter(f => f.endsWith(".js"));
      for (const file of files) delete require.cache[require.resolve(path.join(sysDir, file))];
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("🔄 Systems Reloaded").addFields({ name: "Count", value: `**${files.length}** systems cleared from cache` }).setTimestamp()] });
    }

    return message.channel.send("❌ Usage: `?gen reload <commands|events|systems>`");
  },
};
