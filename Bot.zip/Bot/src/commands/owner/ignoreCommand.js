const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { isOwner } = require("../../utils/permissions");
const { setConfig, getConfig } = require("../../database/store");

module.exports = {
  name: "ignore",
  async execute(message, args, client) {
    if (!isOwner(message.author.id)) return message.channel.send("❌ Owner only.");
    const sub = (args[1] || "").toLowerCase();
    const guildId = message.guild.id;
    const config = getConfig(guildId);

    if (sub === "user") {
      const target = message.mentions.users.first();
      if (!target) return message.channel.send("❌ Usage: `?gen ignore user @user`");
      const ignored = config.ignoredUsers || [];
      if (ignored.includes(target.id)) {
        config.ignoredUsers = ignored.filter(id => id !== target.id);
        await require("../../database/store").setConfig(guildId, "ignoredUsers", config.ignoredUsers);
        return message.channel.send(`✅ **${target.tag}** removed from ignore list.`);
      }
      ignored.push(target.id);
      await require("../../database/store").setConfig(guildId, "ignoredUsers", ignored);
      return message.channel.send(`✅ **${target.tag}** added to ignore list.`);
    }

    if (sub === "channel") {
      const ch = message.mentions.channels.first();
      if (!ch) return message.channel.send("❌ Usage: `?gen ignore channel #channel`");
      const ignored = config.ignoredChannels || [];
      if (ignored.includes(ch.id)) {
        config.ignoredChannels = ignored.filter(id => id !== ch.id);
        await require("../../database/store").setConfig(guildId, "ignoredChannels", config.ignoredChannels);
        return message.channel.send(`✅ ${ch} removed from ignore list.`);
      }
      ignored.push(ch.id);
      await require("../../database/store").setConfig(guildId, "ignoredChannels", ignored);
      return message.channel.send(`✅ ${ch} added to ignore list.`);
    }

    if (sub === "list") {
      const users = (config.ignoredUsers || []).map(id => `<@${id}>`).join(", ") || "None";
      const channels = (config.ignoredChannels || []).map(id => `<#${id}>`).join(", ") || "None";
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.BOT).setTitle("🔕 Ignore List").addFields({ name: "Users", value: users }, { name: "Channels", value: channels }).setTimestamp()] });
    }

    return message.channel.send("❌ Usage: `?gen ignore <user|channel|list>`");
  },
};
