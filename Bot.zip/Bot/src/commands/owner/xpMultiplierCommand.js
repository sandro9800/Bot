const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { getMultipliers, setGlobalMultiplier, setRoleMultiplier, setChannelMultiplier } = require("../../systems/xpMultipliers");
const { isOwner } = require("../../utils/permissions");

module.exports = {
  name: "xpmultiplier",
  async execute(message, args, client) {
    if (!isOwner(message.author.id)) return message.channel.send("❌ Owner only.");
    const sub = (args[1] || "").toLowerCase();
    const guildId = message.guild.id;

    if (sub === "global") {
      const mult = parseFloat(args[2]);
      if (!mult || mult < 0.1 || mult > 10) return message.channel.send("❌ Usage: `?gen xpmultiplier global <0.1-10>`");
      setGlobalMultiplier(guildId, mult);
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("✅ Global XP Multiplier Set").addFields({ name: "Multiplier", value: `**${mult}x**` }).setTimestamp()] });
    }

    if (sub === "role") {
      const role = message.mentions.roles.first();
      const mult = parseFloat(args[3]);
      if (!role || !mult) return message.channel.send("❌ Usage: `?gen xpmultiplier role @role <multiplier>`");
      setRoleMultiplier(guildId, role.id, mult);
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("✅ Role XP Multiplier Set").addFields({ name: "Role", value: `${role}`, inline: true }, { name: "Multiplier", value: `**${mult}x**`, inline: true }).setTimestamp()] });
    }

    if (sub === "channel") {
      const ch = message.mentions.channels.first();
      const mult = parseFloat(args[3]);
      if (!ch || !mult) return message.channel.send("❌ Usage: `?gen xpmultiplier channel #channel <multiplier>`");
      setChannelMultiplier(guildId, ch.id, mult);
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("✅ Channel XP Multiplier Set").addFields({ name: "Channel", value: `${ch}`, inline: true }, { name: "Multiplier", value: `**${mult}x**`, inline: true }).setTimestamp()] });
    }

    if (sub === "list" || !sub) {
      const data = getMultipliers(guildId);
      const embed = new EmbedBuilder().setColor(COLORS.BOT).setTitle("⚡ XP Multipliers").addFields({ name: "🌐 Global", value: `**${data.global || 1}x**`, inline: true });
      if (Object.keys(data.roles || {}).length) embed.addFields({ name: "🎭 Roles", value: Object.entries(data.roles).map(([id, m]) => `<@&${id}> → **${m}x**`).join("\n") });
      if (Object.keys(data.channels || {}).length) embed.addFields({ name: "📝 Channels", value: Object.entries(data.channels).map(([id, m]) => `<#${id}> → **${m}x**`).join("\n") });
      return message.channel.send({ embeds: [embed.setTimestamp()] });
    }

    return message.channel.send("❌ Usage: `?gen xpmultiplier <global|role|channel|list>`");
  },
};
