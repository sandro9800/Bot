const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { addPremiumUser, removePremiumUser, getPremiumUsers, isPremium } = require("../../systems/premium");
const { isOwner } = require("../../utils/permissions");
const { parseInterval, fmtTime } = require("../../utils/format");

module.exports = {
  name: "premium",
  async execute(message, args, client) {
    if (!isOwner(message.author.id)) return message.channel.send("❌ Owner only.");
    const sub = (args[1] || "").toLowerCase();
    const guildId = message.guild.id;

    if (sub === "add") {
      const target = message.mentions.members.first();
      const role = message.mentions.roles.first();
      const durationStr = args[4];
      if (!target || !role) return message.channel.send("❌ Usage: `?gen premium add @user @role [duration]`");
      let expiresAt = null;
      if (durationStr) {
        const ms = parseInterval(durationStr);
        if (!ms) return message.channel.send("❌ Invalid duration.");
        expiresAt = Date.now() + ms;
      }
      await target.roles.add(role).catch(() => {});
      addPremiumUser(guildId, target.id, role.id, expiresAt);
      try { await target.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("⭐ Premium Granted!").setDescription(`You have been granted **${role.name}** in **${message.guild.name}**!${expiresAt ? `\n**Expires:** <t:${Math.floor(expiresAt / 1000)}:R>` : ""}`).setTimestamp()] }); } catch (_) {}
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("⭐ Premium Added").addFields({ name: "User", value: `${target}`, inline: true }, { name: "Role", value: `${role}`, inline: true }, { name: "Expires", value: expiresAt ? `<t:${Math.floor(expiresAt / 1000)}:R>` : "Never", inline: true }).setTimestamp()] });
    }

    if (sub === "remove") {
      const target = message.mentions.members.first();
      if (!target) return message.channel.send("❌ Usage: `?gen premium remove @user`");
      const users = getPremiumUsers(guildId);
      const info = users[target.id];
      if (!info) return message.channel.send(`❌ **${target.user.tag}** does not have premium.`);
      await target.roles.remove(info.roleId).catch(() => {});
      removePremiumUser(guildId, target.id);
      return message.channel.send(`✅ Premium removed from ${target}.`);
    }

    if (sub === "list") {
      const users = getPremiumUsers(guildId);
      const entries = Object.entries(users);
      if (!entries.length) return message.channel.send("❌ No premium users.");
      const desc = entries.map(([uid, info]) => `<@${uid}> — <@&${info.roleId}> — ${info.expiresAt ? `Expires <t:${Math.floor(info.expiresAt / 1000)}:R>` : "Permanent"}`).join("\n");
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.BOT).setTitle("⭐ Premium Users").setDescription(desc.slice(0, 4000)).setTimestamp()] });
    }

    if (sub === "check") {
      const target = message.mentions.users.first() || message.author;
      const has = isPremium(guildId, target.id);
      return message.channel.send(`${target.tag} **${has ? "has" : "does not have"}** premium.`);
    }

    return message.channel.send("❌ Usage: `?gen premium <add|remove|list|check>`");
  },
};
