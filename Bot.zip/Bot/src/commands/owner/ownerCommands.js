const { EmbedBuilder, AttachmentBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { createBackup, listBackups, restoreBackup } = require("../../systems/backup");
const { getSystemInfo } = require("../../systems/monitor");
const { getStorage, saveStorage, setConfig, getConfig } = require("../../database/store");
const { isOwner } = require("../../utils/permissions");
const { fmtTime } = require("../../utils/format");
const fs = require("fs");
const path = require("path");

module.exports = {
  name: "owner",
  async execute(message, args, client) {
    const cmd = (args[0] || "").toLowerCase();

    // BACKUP
    if (cmd === "backup") {
      const sub = (args[1] || "").toLowerCase();

      if (sub === "create" || !sub) {
        const backupPath = createBackup();
        const name = path.basename(backupPath);
        return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("💾 Backup Created").addFields({ name: "Name", value: `\`${name}\`` }, { name: "Location", value: `\`backups/${name}\`` }).setTimestamp()] });
      }

      if (sub === "list") {
        const backups = listBackups();
        if (!backups.length) return message.channel.send("❌ No backups found.");
        return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.BOT).setTitle("💾 Backups").setDescription(backups.slice(0, 20).map((b, i) => `**${i + 1}.** \`${b}\``).join("\n")).setTimestamp()] });
      }

      if (sub === "restore") {
        const name = args[2];
        if (!name) return message.channel.send("❌ Usage: `?gen backup restore <name>`");
        const ok = restoreBackup(name);
        if (!ok) return message.channel.send("❌ Backup not found.");
        return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("✅ Backup Restored").setDescription(`Restored from \`${name}\`.`).setTimestamp()] });
      }

      return message.channel.send("❌ Usage: `?gen backup <create|list|restore>`");
    }

    // UPTIME / STATUS
    if (cmd === "uptime" || cmd === "status") {
      const info = getSystemInfo();
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.BOT).setTitle("📊 Bot Status").addFields(
        { name: "⏱️ Uptime", value: info.uptime, inline: true },
        { name: "🏓 Ping", value: `${Math.round(client.ws.ping)}ms`, inline: true },
        { name: "🖥️ Platform", value: `${info.platform} (${info.arch})`, inline: true },
        { name: "🧠 Memory (Heap)", value: `${info.memory.heapUsed} / ${info.memory.heapTotal}`, inline: true },
        { name: "📦 RSS", value: info.memory.rss, inline: true },
        { name: "⚙️ Node", value: info.nodeVersion, inline: true },
        { name: "🔢 CPU Cores", value: `${info.cpuCores}`, inline: true },
        { name: "📈 CPU Load", value: `1m: ${info.cpu["1m"]} | 5m: ${info.cpu["5m"]}`, inline: true },
        { name: "🌐 Servers", value: `${client.guilds.cache.size}`, inline: true },
      ).setTimestamp()] });
    }

    // MAINTENANCE
    if (cmd === "maintenance") {
      const toggle = (args[1] || "").toLowerCase();
      if (toggle === "on") {
        setConfig(message.guild.id, "maintenance", true);
        return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.WARN).setTitle("🔧 Maintenance Mode ON").setDescription("Bot is now in maintenance mode. Only owners can use commands.").setTimestamp()] });
      }
      if (toggle === "off") {
        setConfig(message.guild.id, "maintenance", false);
        return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("✅ Maintenance Mode OFF").setDescription("Bot is back online for all users.").setTimestamp()] });
      }
      return message.channel.send("❌ Usage: `?gen maintenance <on|off>`");
    }

    // LOCKDOWN
    if (cmd === "lockdown") {
      const toggle = (args[1] || "").toLowerCase();
      const reason = args.slice(2).join(" ") || "Emergency lockdown";
      if (toggle === "on") {
        const channels = message.guild.channels.cache.filter(c => c.type === 0);
        let count = 0;
        for (const [, ch] of channels) {
          try { await ch.permissionOverwrites.edit(message.guild.roles.everyone, { SendMessages: false }); count++; } catch (_) {}
        }
        return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.ERROR).setTitle("🔒 Server Lockdown").setDescription(`**${count}** channels locked.\n**Reason:** ${reason}`).setFooter({ text: `By ${message.author.username}` }).setTimestamp()] });
      }
      if (toggle === "off") {
        const channels = message.guild.channels.cache.filter(c => c.type === 0);
        let count = 0;
        for (const [, ch] of channels) {
          try { await ch.permissionOverwrites.edit(message.guild.roles.everyone, { SendMessages: null }); count++; } catch (_) {}
        }
        return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("🔓 Lockdown Lifted").setDescription(`**${count}** channels unlocked.`).setFooter({ text: `By ${message.author.username}` }).setTimestamp()] });
      }
      return message.channel.send("❌ Usage: `?gen lockdown <on|off> [reason]`");
    }

    // BOOSTCONFIG
    if (cmd === "boostconfig") {
      const ch = message.mentions.channels.first();
      if (!ch) return message.channel.send("❌ Usage: `?gen boostconfig #channel`");
      setConfig(message.guild.id, "boostChannel", ch.id);
      return message.channel.send(`✅ Boost messages will be sent to ${ch}.`);
    }

    // SERVERSTATS
    if (cmd === "serverstats") {
      const g = message.guild;
      await g.members.fetch();
      const humans = g.members.cache.filter(m => !m.user.bot).size;
      const bots = g.members.cache.filter(m => m.user.bot).size;
      const { ChannelType, PermissionFlagsBits } = require("discord.js");
      try {
        const category = await g.channels.create({ name: "📊 Server Stats", type: ChannelType.GuildCategory });
        const make = (name) => g.channels.create({ name, type: ChannelType.GuildVoice, parent: category.id, permissionOverwrites: [{ id: g.roles.everyone.id, deny: [PermissionFlagsBits.Connect] }] });
        const memberCh = await make(`👥 Members: ${g.memberCount}`);
        const humanCh = await make(`👤 Humans: ${humans}`);
        const botCh = await make(`🤖 Bots: ${bots}`);
        const boostCh = await make(`🚀 Boosts: ${g.premiumSubscriptionCount}`);
        setConfig(g.id, "statChannels", { category: category.id, members: memberCh.id, humans: humanCh.id, bots: botCh.id, boosts: boostCh.id });
        setInterval(async () => {
          try {
            await g.members.fetch();
            const h = g.members.cache.filter(m => !m.user.bot).size;
            const b = g.members.cache.filter(m => m.user.bot).size;
            await memberCh.setName(`👥 Members: ${g.memberCount}`).catch(() => {});
            await humanCh.setName(`👤 Humans: ${h}`).catch(() => {});
            await botCh.setName(`🤖 Bots: ${b}`).catch(() => {});
            await boostCh.setName(`🚀 Boosts: ${g.premiumSubscriptionCount}`).catch(() => {});
          } catch (_) {}
        }, 600000);
        return message.channel.send(`✅ Server stat channels created!`);
      } catch (err) { return message.channel.send(`❌ Failed: ${err.message}`); }
    }
  },
};
