const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { isOwner } = require("../../utils/permissions");
const { addXP } = require("../../systems/levels");
const { checkLevelRewards } = require("../../systems/levelRewards");

module.exports = {
  name: "givexp",
  async execute(message, args, client) {
    if (!isOwner(message.author.id)) return message.channel.send("❌ Owner only.");
    const target = message.mentions.members.first();
    const amount = parseInt(args[2]);
    if (!target || !amount || amount < 1) return message.channel.send("❌ Usage: `?gen givexp @user <amount>`");

    const result = addXP(message.guild.id, target.id, amount);

    if (result.leveledUp) {
      try { await checkLevelRewards(message.guild, target, result.level); } catch (_) {}
    }

    return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("⭐ XP Given").addFields(
      { name: "User", value: `${target}`, inline: true },
      { name: "XP Added", value: `**+${amount}**`, inline: true },
      { name: "Level Up?", value: result.leveledUp ? `✅ Now Level **${result.level}**` : "❌ Not yet", inline: true },
    ).setTimestamp()] });
  },
};
