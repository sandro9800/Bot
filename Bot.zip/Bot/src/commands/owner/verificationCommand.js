const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { isOwner } = require("../../utils/permissions");
const { setConfig, getConfig } = require("../../database/store");
const { buildVerifyEmbed, buildVerifyRow } = require("../../systems/verification");

module.exports = {
  name: "verification",
  async execute(message, args, client) {
    if (!isOwner(message.author.id)) return message.channel.send("❌ Owner only.");
    const sub = (args[1] || "").toLowerCase();
    const guildId = message.guild.id;

    if (sub === "setup") {
      const role = message.mentions.roles.first();
      if (!role) return message.channel.send("❌ Usage: `?gen verification setup @role`");
      setConfig(guildId, "verifiedRole", role.id);
      return message.channel.send(`✅ Verified role set to ${role}.`);
    }

    if (sub === "panel") {
      const ch = message.mentions.channels.first() || message.channel;
      await ch.send({ embeds: [buildVerifyEmbed(message.guild)], components: [buildVerifyRow()] });
      return message.channel.send(`✅ Verification panel sent to ${ch}.`);
    }

    if (sub === "unverified") {
      const role = message.mentions.roles.first();
      if (!role) return message.channel.send("❌ Usage: `?gen verification unverified @role`");
      setConfig(guildId, "unverifiedRole", role.id);
      return message.channel.send(`✅ Unverified role set to ${role}. New members will receive this role until verified.`);
    }

    if (sub === "status") {
      const config = getConfig(guildId);
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.BOT).setTitle("✅ Verification Status").addFields(
        { name: "Verified Role", value: config.verifiedRole ? `<@&${config.verifiedRole}>` : "Not set", inline: true },
        { name: "Unverified Role", value: config.unverifiedRole ? `<@&${config.unverifiedRole}>` : "Not set", inline: true },
      ).setTimestamp()] });
    }

    return message.channel.send("❌ Usage: `?gen verification <setup|panel|unverified|status>`");
  },
};
