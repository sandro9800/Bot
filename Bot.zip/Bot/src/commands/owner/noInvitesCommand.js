const { EmbedBuilder, PermissionFlagsBits } = require("discord.js");
const { COLORS } = require("../../config");
const { isOwner } = require("../../utils/permissions");

module.exports = {
  name: "noinvites",
  async execute(message, args, client) {
    if (!isOwner(message.author.id)) return message.channel.send("❌ Owner only.");
    const toggle = (args[1] || "").toLowerCase();

    if (toggle === "on") {
      try {
        await message.guild.disableInvites(true);
        return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.ERROR).setTitle("🔗 Invites Disabled").setDescription("All invite links have been paused for this server.").setFooter({ text: `By ${message.author.tag}` }).setTimestamp()] });
      } catch (err) { return message.channel.send(`❌ Failed: ${err.message}`); }
    }

    if (toggle === "off") {
      try {
        await message.guild.disableInvites(false);
        return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("🔗 Invites Enabled").setDescription("Invite links have been re-enabled.").setFooter({ text: `By ${message.author.tag}` }).setTimestamp()] });
      } catch (err) { return message.channel.send(`❌ Failed: ${err.message}`); }
    }

    return message.channel.send("❌ Usage: `?gen noinvites <on|off>`");
  },
};
