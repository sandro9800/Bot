const { EmbedBuilder, AttachmentBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { readJson } = require("../../database/store");
const { isOwner } = require("../../utils/permissions");

module.exports = {
  name: "exportwarnings",
  async execute(message, args, client) {
    if (!isOwner(message.author.id)) return message.channel.send("❌ Owner only.");
    const db = readJson("logs");
    const guildWarns = db.warnings?.[message.guild.id] || {};
    if (!Object.keys(guildWarns).length) return message.channel.send("❌ No warnings to export.");

    const lines = [];
    for (const [userId, warns] of Object.entries(guildWarns)) {
      for (const w of warns) {
        lines.push(`${userId},${w.moderatorId},${w.reason},${new Date(w.timestamp).toISOString()}`);
      }
    }
    const csv = `userId,moderatorId,reason,timestamp\n${lines.join("\n")}`;
    const file = new AttachmentBuilder(Buffer.from(csv, "utf-8"), { name: `warnings-${message.guild.id}.csv` });
    await message.channel.send({ content: `✅ Exported **${lines.length}** warnings.`, files: [file] });
    await message.delete().catch(() => {});
  },
};
