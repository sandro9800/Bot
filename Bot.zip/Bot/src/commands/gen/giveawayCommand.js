const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} = require("discord.js");
const { COLORS } = require("../../config");
const { isOwner, hasRank } = require("../../utils/permissions");
const {
  giveaways,
  giveawaysByName,
  giveawayRerolData,
  endGiveaway,
  saveGiveaway,
  buildGiveawayEmbed,
  buildGiveawayRow,
} = require("../../systems/giveaways");
const { parseInterval, fmtTime } = require("../../utils/format");

// ── Permission guard ──────────────────────────────────────────────────────────
function canManageGiveaways(userId, guildId) {
  return (
    isOwner(userId) ||
    hasRank(userId, guildId, "admin", "giveaway_manager")
  );
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("giveaway")
    .setDescription("Manage giveaways")
    // create
    .addSubcommand((sub) =>
      sub
        .setName("create")
        .setDescription("Start a new giveaway")
        .addStringOption((o) =>
          o.setName("prize").setDescription("What is being given away?").setRequired(true)
        )
        .addStringOption((o) =>
          o.setName("duration").setDescription("Duration e.g. 1h, 30m, 2d").setRequired(true)
        )
        .addIntegerOption((o) =>
          o.setName("winners").setDescription("Number of winners (default 1)").setRequired(false).setMinValue(1).setMaxValue(20)
        )
    )
    // end
    .addSubcommand((sub) =>
      sub
        .setName("end")
        .setDescription("End a giveaway early")
        .addStringOption((o) =>
          o.setName("prize").setDescription("Prize name of the giveaway to end").setRequired(true)
        )
    )
    // reroll
    .addSubcommand((sub) =>
      sub
        .setName("reroll")
        .setDescription("Reroll winners for an ended giveaway")
        .addStringOption((o) =>
          o.setName("prize").setDescription("Prize name to reroll").setRequired(true)
        )
        .addIntegerOption((o) =>
          o.setName("winners").setDescription("How many winners to pick (default 1)").setRequired(false).setMinValue(1).setMaxValue(20)
        )
    )
    // pause (toggle)
    .addSubcommand((sub) =>
      sub
        .setName("pause")
        .setDescription("Pause or unpause an active giveaway")
        .addStringOption((o) =>
          o.setName("prize").setDescription("Prize name of the giveaway").setRequired(true)
        )
    )
    // list
    .addSubcommand((sub) =>
      sub.setName("list").setDescription("List all active giveaways")
    ),

  category: "gen",

  async execute(interaction) {
    const userId = interaction.user.id;
    const guildId = interaction.guild.id;

    if (!canManageGiveaways(userId, guildId)) {
      return interaction.reply({
        content: "❌ You need to be an **Admin** or **Giveaway Manager** to use this command.",
        ephemeral: true,
      });
    }

    const sub = interaction.options.getSubcommand();

    // ── CREATE ────────────────────────────────────────────────────────────────
    if (sub === "create") {
      const prize = interaction.options.getString("prize");
      const durationStr = interaction.options.getString("duration");
      const winnerCount = interaction.options.getInteger("winners") || 1;

      const ms = parseInterval(durationStr);
      if (!ms || ms < 10000) {
        return interaction.reply({ content: "❌ Invalid duration. Use formats like `30m`, `1h`, `2d`.", ephemeral: true });
      }

      const endsAt = Date.now() + ms;

      await interaction.deferReply({ ephemeral: true });

      const sentMsg = await interaction.channel.send({
        embeds: [buildGiveawayEmbed(prize, endsAt, 0, interaction.guild, false, [], winnerCount)],
        components: [buildGiveawayRow()],
      });

      const tickerId = setInterval(async () => {
        const gw = giveaways[sentMsg.id];
        if (!gw) return clearInterval(tickerId);
        try {
          const msg = await interaction.channel.messages.fetch(sentMsg.id);
          await msg.edit({
            embeds: [buildGiveawayEmbed(gw.item, gw.endsAt, gw.entries.size, interaction.guild, false, [], gw.winnerCount)],
            components: [buildGiveawayRow()],
          });
        } catch (_) {
          clearInterval(tickerId);
        }
      }, 30000);

      const timeoutId = setTimeout(() => endGiveaway(interaction.client, sentMsg.id), ms);

      giveaways[sentMsg.id] = {
        item: prize,
        entries: new Set(),
        winnerCount,
        endsAt,
        channelId: sentMsg.channelId,
        paused: false,
        timeoutId,
        tickerId,
      };
      giveawaysByName[prize.toLowerCase()] = sentMsg.id;
      saveGiveaway(sentMsg.id, giveaways[sentMsg.id]);

      return interaction.editReply({
        content: `✅ Giveaway for **${prize}** started! Ends <t:${Math.floor(endsAt / 1000)}:R>.`,
      });
    }

    // ── END ───────────────────────────────────────────────────────────────────
    if (sub === "end") {
      const prize = interaction.options.getString("prize");
      const msgId = giveawaysByName[prize.toLowerCase()];
      if (!msgId || !giveaways[msgId]) {
        return interaction.reply({ content: `❌ No active giveaway found for **${prize}**.`, ephemeral: true });
      }
      await interaction.reply({ content: `⏹️ Ending giveaway for **${prize}**...`, ephemeral: true });
      await endGiveaway(interaction.client, msgId);
    }

    // ── REROLL ────────────────────────────────────────────────────────────────
    if (sub === "reroll") {
      const prize = interaction.options.getString("prize");
      const count = interaction.options.getInteger("winners") || 1;
      const rerolData = giveawayRerolData[prize.toLowerCase()];

      if (!rerolData || !rerolData.entries.length) {
        return interaction.reply({ content: `❌ No reroll data found for **${prize}**.`, ephemeral: true });
      }

      const pool = [...rerolData.entries];
      const winners = [];
      const pickCount = Math.min(count, pool.length);
      for (let i = 0; i < pickCount; i++) {
        const idx = Math.floor(Math.random() * pool.length);
        winners.push(pool.splice(idx, 1)[0]);
      }

      await interaction.reply({
        content: `🎊 Reroll winners for **${rerolData.item}**: ${winners.map((w) => `<@${w}>`).join(", ")}`,
        allowedMentions: { users: winners },
      });

      try {
        const ch = await interaction.client.channels.fetch(rerolData.channelId);
        await ch.send({
          content: `🔁 Reroll! Congratulations ${winners.map((w) => `<@${w}>`).join(", ")}! You won **${rerolData.item}**!`,
          allowedMentions: { users: winners },
        });
      } catch (_) {}
    }

    // ── PAUSE ─────────────────────────────────────────────────────────────────
    if (sub === "pause") {
      const prize = interaction.options.getString("prize");
      const msgId = giveawaysByName[prize.toLowerCase()];
      const gw = giveaways[msgId];

      if (!msgId || !gw) {
        return interaction.reply({ content: `❌ No active giveaway found for **${prize}**.`, ephemeral: true });
      }

      gw.paused = !gw.paused;

      try {
        const ch = await interaction.client.channels.fetch(gw.channelId);
        const msg = await ch.messages.fetch(msgId);
        await msg.edit({
          embeds: [buildGiveawayEmbed(gw.item, gw.endsAt, gw.entries.size, interaction.guild, false, [], gw.winnerCount)],
          components: [buildGiveawayRow(gw.paused)],
        });
      } catch (_) {}

      saveGiveaway(msgId, gw);

      return interaction.reply({
        content: gw.paused
          ? `⏸️ Giveaway for **${prize}** has been **paused**. Entries are locked.`
          : `▶️ Giveaway for **${prize}** has been **resumed**.`,
        ephemeral: true,
      });
    }

    // ── LIST ──────────────────────────────────────────────────────────────────
    if (sub === "list") {
      const active = Object.entries(giveaways);
      if (!active.length) {
        return interaction.reply({ content: "📭 No active giveaways right now.", ephemeral: true });
      }

      const fields = active.map(([msgId, gw]) => ({
        name: gw.item,
        value: `Entries: **${gw.entries.size}** | Winners: **${gw.winnerCount}** | Ends: <t:${Math.floor(gw.endsAt / 1000)}:R>${gw.paused ? " | ⏸️ Paused" : ""}`,
        inline: false,
      }));

      const embed = new EmbedBuilder()
        .setColor(COLORS.BOT)
        .setTitle("🎉 Active Giveaways")
        .addFields(fields)
        .setTimestamp();

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
  },
};
