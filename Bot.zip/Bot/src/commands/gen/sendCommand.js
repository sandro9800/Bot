const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { popFirstLine, stockCount, updateAllPanels } = require("../../systems/stock");
const { isOwner } = require("../../utils/permissions");

module.exports = {
  name: "send",
  async execute(message, args, client) {
    if (!isOwner(message.author.id)) return message.channel.send("❌ Owner only.");
    const target = message.mentions.members.first();
    const amount = parseInt(args[2]) || 1;
    if (!target) return message.channel.send("❌ Usage: `?gen send @user [amount]`");
    if (amount < 1 || amount > 10) return message.channel.send("❌ Amount must be between 1 and 10.");

    const lines = [];
    for (let i = 0; i < amount; i++) {
      const line = popFirstLine();
      if (!line) { lines.push(null); break; }
      lines.push(line);
    }

    const valid = lines.filter(Boolean);
    if (!valid.length) return message.channel.send("❌ Out of stock!");

    try {
      await target.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("🎁 Account(s) Sent").setDescription(valid.map(l => `\`\`\`${l}\`\`\``).join("\n")).addFields({ name: "Sent by", value: message.author.username, inline: true }, { name: "Amount", value: `**${valid.length}**`, inline: true }).setTimestamp()] });
      await updateAllPanels(client);
      await message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("✅ Sent").addFields({ name: "To", value: `${target}`, inline: true }, { name: "Amount", value: `**${valid.length}**`, inline: true }, { name: "Remaining Stock", value: `**${stockCount()}**`, inline: true }).setTimestamp()] });
    } catch (_) {
      return message.channel.send(`❌ Could not DM ${target}. Their DMs may be closed.`);
    }
    await message.delete().catch(() => {});
  },
};
