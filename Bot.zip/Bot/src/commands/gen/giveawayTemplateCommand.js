const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { getTemplates, saveTemplate, deleteTemplate, getTemplate } = require("../../systems/giveawayTemplates");
const { giveaways, giveawaysByName, saveGiveaway, buildGiveawayEmbed, buildGiveawayRow, endGiveaway } = require("../../systems/giveaways");
const { parseInterval, fmtTime } = require("../../utils/format");

module.exports = {
  name: "giveawaytemplate",
  async execute(message, args, client) {
    const sub = (args[1] || "").toLowerCase();
    const guildId = message.guild.id;

    // SAVE
    if (sub === "save") {
      const name = args[2];
      const prize = args.slice(3, args.length - 2).join(" ");
      const duration = args[args.length - 2];
      const winners = parseInt(args[args.length - 1]) || 1;
      if (!name || !prize || !duration) return message.channel.send("❌ Usage: `?gen giveawaytemplate save <name> <prize> <duration> [winners]`");
      const ms = parseInterval(duration);
      if (!ms) return message.channel.send("❌ Invalid duration.");
      saveTemplate(guildId, name, { prize, duration, durationMs: ms, winners });
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("💾 Template Saved").addFields({ name: "Name", value: `\`${name}\``, inline: true }, { name: "Prize", value: prize, inline: true }, { name: "Duration", value: duration, inline: true }, { name: "Winners", value: `${winners}`, inline: true }).setTimestamp()] });
    }

    // LOAD (start a giveaway from template)
    if (sub === "load") {
      const name = args[2];
      if (!name) return message.channel.send("❌ Usage: `?gen giveawaytemplate load <name>`");
      const template = getTemplate(guildId, name);
      if (!template) return message.channel.send(`❌ Template \`${name}\` not found.`);
      const endsAt = Date.now() + template.durationMs;
      const sentMsg = await message.channel.send({ embeds: [buildGiveawayEmbed(template.prize, endsAt, 0, message.guild, false, [], template.winners)], components: [buildGiveawayRow()] });
      const timeoutId = setTimeout(() => endGiveaway(client, sentMsg.id), template.durationMs);
      const tickerId = setInterval(async () => {
        const gw = giveaways[sentMsg.id]; if (!gw) return clearInterval(tickerId);
        try { const msg = await message.channel.messages.fetch(sentMsg.id); await msg.edit({ embeds: [buildGiveawayEmbed(gw.item, gw.endsAt, gw.entries.size, message.guild, false, [], gw.winnerCount)], components: [buildGiveawayRow()] }); } catch (_) { clearInterval(tickerId); }
      }, 30000);
      giveaways[sentMsg.id] = { item: template.prize, entries: new Set(), winnerCount: template.winners, endsAt, channelId: sentMsg.channelId, timeoutId, tickerId };
      giveawaysByName[template.prize.toLowerCase()] = sentMsg.id;
      saveGiveaway(sentMsg.id, giveaways[sentMsg.id]);
      return message.channel.send(`✅ Giveaway started from template \`${name}\`!`);
    }

    // LIST
    if (sub === "list" || !sub) {
      const templates = getTemplates(guildId);
      const entries = Object.entries(templates);
      if (!entries.length) return message.channel.send("❌ No templates saved.");
      const desc = entries.map(([n, t]) => `**${n}** — ${t.prize} | ${t.duration} | ${t.winners} winner(s)`).join("\n");
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.BOT).setTitle("📋 Giveaway Templates").setDescription(desc).setTimestamp()] });
    }

    // DELETE
    if (sub === "delete") {
      const name = args[2];
      if (!name) return message.channel.send("❌ Usage: `?gen giveawaytemplate delete <name>`");
      const ok = deleteTemplate(guildId, name);
      if (!ok) return message.channel.send(`❌ Template \`${name}\` not found.`);
      return message.channel.send(`✅ Template \`${name}\` deleted.`);
    }

    return message.channel.send("❌ Usage: `?gen giveawaytemplate <save|load|list|delete>`");
  },
};
