const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { isOwner } = require("../../utils/permissions");
const { updateAllPanels, STOCK_PATH } = require("../../systems/stock");
const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const fs = require("fs");

module.exports = {
  name: "clearstock",
  async execute(message, args, client) {
    if (!isOwner(message.author.id)) return message.channel.send("❌ Owner only.");

    const confirmRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("clearstock_confirm").setLabel("✅ Yes, clear all").setStyle(ButtonStyle.Danger),
      new ButtonBuilder().setCustomId("clearstock_cancel").setLabel("❌ Cancel").setStyle(ButtonStyle.Secondary),
    );

    const prompt = await message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.WARN).setTitle("⚠️ Clear Stock?").setDescription("Are you sure you want to **delete all stock**? This cannot be undone.").setTimestamp()], components: [confirmRow] });

    const collector = prompt.createMessageComponentCollector({ filter: i => i.user.id === message.author.id, time: 15000, max: 1 });

    collector.on("collect", async i => {
      if (i.customId === "clearstock_confirm") {
        fs.writeFileSync(STOCK_PATH, "", "utf-8");
        await updateAllPanels(client);
        await i.update({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("✅ Stock Cleared").setDescription("All stock has been deleted.").setTimestamp()], components: [] });
      } else {
        await i.update({ embeds: [new EmbedBuilder().setColor(COLORS.BOT).setTitle("❌ Cancelled").setTimestamp()], components: [] });
      }
    });

    collector.on("end", collected => {
      if (!collected.size) prompt.edit({ components: [] }).catch(() => {});
    });

    await message.delete().catch(() => {});
  },
};
