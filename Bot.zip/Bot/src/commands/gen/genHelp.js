const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { isOwner, hasRank, getStaffRank, isStaff } = require("../../utils/permissions");

const CATEGORIES = {
  moderation: {
    label: "⚔️ Moderation",
    ranks: ["helper", "admin"],
    cmds: [
      { name: "/ban", desc: "Ban a member", ranks: ["admin"] },
      { name: "/kick", desc: "Kick a member", ranks: ["admin"] },
      { name: "/timeout", desc: "Timeout a member", ranks: ["admin"] },
      { name: "/warn", desc: "Warn a member", ranks: ["admin"] },
      { name: "/softban", desc: "Softban a member", ranks: ["admin"] },
      { name: "/nick", desc: "Change a nickname", ranks: ["admin"] },
      { name: "/massrole", desc: "Mass add/remove role", ranks: ["admin"] },
      { name: "/gen warnings", desc: "View warnings for a user", ranks: ["helper", "admin"] },
    ],
  },
  tickets: {
    label: "🎫 Tickets",
    ranks: ["helper", "admin"],
    cmds: [
      { name: "/gen ticket claim", desc: "Claim an open ticket", ranks: ["helper", "admin"] },
      { name: "/gen ticket close", desc: "Close a ticket", ranks: ["helper", "admin"] },
      { name: "/gen tickets", desc: "Manage ticket settings", ranks: ["admin"] },
      { name: "/gen ticketpanel", desc: "Deploy a ticket panel", ranks: ["admin"] },
    ],
  },
  reports: {
    label: "📋 Reports",
    ranks: ["helper", "admin"],
    cmds: [
      { name: "/gen reports", desc: "View and manage reports", ranks: ["helper", "admin"] },
    ],
  },
  applications: {
    label: "📝 Applications",
    ranks: ["admin"],
    cmds: [
      { name: "/gen applications", desc: "Manage staff applications", ranks: ["admin"] },
    ],
  },
  giveaways: {
    label: "🎉 Giveaways",
    ranks: ["admin", "giveaway_manager"],
    cmds: [
      { name: "/gen giveaway create", desc: "Create a giveaway", ranks: ["admin", "giveaway_manager"] },
      { name: "/gen giveaway reroll", desc: "Reroll giveaway winners", ranks: ["admin", "giveaway_manager"] },
      { name: "/gen giveaway end", desc: "End a giveaway early", ranks: ["admin", "giveaway_manager"] },
      { name: "/gen giveaway pause", desc: "Pause a giveaway", ranks: ["admin", "giveaway_manager"] },
      { name: "?gen giveawaytemplate", desc: "Manage giveaway templates", ranks: ["admin", "giveaway_manager"] },
    ],
  },
  stock: {
    label: "📦 Stock",
    ranks: [], // owner only
    cmds: [
      { name: "/gen stock", desc: "View stock count", ranks: [] },
      { name: "/gen addstock", desc: "Add stock lines", ranks: [] },
      { name: "/gen removestock", desc: "Remove stock lines", ranks: [] },
      { name: "/gen send", desc: "Send a stock line to a user", ranks: [] },
      { name: "/gen panel", desc: "Deploy generator panel", ranks: [] },
    ],
  },
  owner: {
    label: "👑 Owner",
    ranks: [], // owner only
    cmds: [
      { name: "?gen adduser @user rank", desc: "Add a staff member", ranks: [] },
      { name: "?gen removeuser @user", desc: "Remove a staff member", ranks: [] },
      { name: "/gen staff list", desc: "List all staff", ranks: [] },
      { name: "/gen staff promote", desc: "Promote a staff member", ranks: [] },
      { name: "/gen staff demote", desc: "Demote a staff member", ranks: [] },
      { name: "/gen reload", desc: "Reload commands/plugins", ranks: [] },
      { name: "/gen backup", desc: "Create a server backup", ranks: [] },
      { name: "/gen restore", desc: "Restore from backup", ranks: [] },
      { name: "/gen maintenance", desc: "Toggle maintenance mode", ranks: [] },
      { name: "/gen lockdown", desc: "Emergency lockdown", ranks: [] },
      { name: "/gen settings", desc: "Configure bot settings", ranks: [] },
      { name: "/gen analytics", desc: "View bot analytics", ranks: [] },
    ],
  },
  developer: {
    label: "🔧 Developer",
    ranks: ["developer"],
    cmds: [
      { name: "/gen reload commands", desc: "Hot reload all commands", ranks: ["developer"] },
      { name: "/gen reload plugins", desc: "Hot reload all plugins", ranks: ["developer"] },
      { name: "/gen errors", desc: "View recent bot errors", ranks: ["developer"] },
      { name: "/gen status", desc: "View bot status and uptime", ranks: ["developer"] },
    ],
  },
};

module.exports = {
  name: "genhelp",
  prefixAlias: "help",
  category: "gen",
  description: "Staff-only dynamic help system",
  type: "both",

  async execute(interaction, args, client) {
    // Support both slash and prefix
    const isSlash = !!interaction.reply;
    const userId = isSlash ? interaction.user.id : interaction.author.id;
    const guildId = isSlash ? interaction.guild.id : interaction.guild.id;

    if (!isOwner(userId) && !getStaffRank(userId, guildId)) {
      const err = "❌ This command is for staff only.";
      return isSlash ? interaction.reply({ content: err, ephemeral: true }) : interaction.channel.send(err);
    }

    const owner = isOwner(userId);
    const rank = getStaffRank(userId, guildId);

    const canSee = (cat) => {
      if (owner) return true;
      if (cat.ranks.length === 0) return false; // owner-only
      if (!rank) return false;
      return cat.ranks.includes(rank);
    };

    const canSeeCmd = (cmd) => {
      if (owner) return true;
      if (cmd.ranks.length === 0) return false;
      if (!rank) return false;
      return cmd.ranks.includes(rank);
    };

    let fields = [];
    for (const [key, cat] of Object.entries(CATEGORIES)) {
      if (!canSee(cat)) continue;
      const accessible = cat.cmds.filter(canSeeCmd);
      if (!accessible.length) continue;
      fields.push({
        name: cat.label,
        value: accessible.map((c) => `\`${c.name}\` — ${c.desc}`).join("\n"),
        inline: false,
      });
    }

    if (!fields.length) {
      const err = "❌ No commands available for your rank.";
      return isSlash ? interaction.reply({ content: err, ephemeral: true }) : interaction.channel.send(err);
    }

    const embed = new EmbedBuilder()
      .setColor(COLORS.BOT)
      .setTitle("🛡️ Staff Help — Gen Bot")
      .setDescription(`Commands available for rank: **${owner ? "Owner" : rank}**\nShowing only commands you can use.`)
      .addFields(fields)
      .setFooter({ text: "Gen Bot Staff Help" })
      .setTimestamp();

    return isSlash
      ? interaction.reply({ embeds: [embed], ephemeral: true })
      : interaction.channel.send({ embeds: [embed] });
  },
};
