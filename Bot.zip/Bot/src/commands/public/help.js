const {
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MessageFlags
} = require("discord.js");
const { COLORS } = require("../../config");
const { isOwner, hasRank, getStaffRank } = require("../../utils/permissions");

const CATEGORIES = {
  public: {
    emoji: "📢",
    label: "Public Commands",
    description: "Commands available to all server members.",
    commands: [
      { name: "/help", desc: "Show this interactive help menu" },
      { name: "/ticket", desc: "Open a support ticket" },
      { name: "/report", desc: "Report a user anonymously" },
      { name: "/profile", desc: "View your profile, bio, and stats" },
      { name: "/level", desc: "Check your XP level and progress" },
      { name: "/invites", desc: "Check your invite count and stats" },
      { name: "/poll", desc: "Create an interactive poll" },
      { name: "/afk", desc: "Set your AFK status" },
      { name: "/greet", desc: "View or set greet preferences (if available)" },
    ]
  },
  generator: {
    emoji: "📦",
    label: "Generator / Stock",
    description: "Stock management and generator panel commands.",
    commands: [
      { name: "/gen stock", desc: "View current stock count" },
      { name: "/gen addstock", desc: "Add stock lines (staff)" },
      { name: "/gen send", desc: "Send stock to a user (staff)" },
      { name: "/gen panel", desc: "Deploy generator panel" },
      { name: "/gen clearstock", desc: "Clear stock (owner)" },
    ]
  },
  moderation: {
    emoji: "🛡️",
    label: "Moderation",
    description: "Moderation tools, antis, warnings, and channel controls.",
    commands: [
      { name: "/ban", desc: "Ban a member" },
      { name: "/kick", desc: "Kick a member" },
      { name: "/timeout", desc: "Timeout a member" },
      { name: "/warn", desc: "Warn a member" },
      { name: "/snipe", desc: "View recently deleted messages" },
      { name: "/gen antiemoji", desc: "Configure anti-emoji" },
      { name: "/gen antiinvite", desc: "Configure anti-invite" },
      { name: "/gen antimention", desc: "Configure anti-mention" },
      { name: "/gen purge", desc: "Purge messages (various options)" },
      { name: "/gen warnings", desc: "View user warnings" },
    ]
  },
  tickets: {
    emoji: "🎫",
    label: "Tickets",
    description: "Support ticket system with enhanced controls.",
    commands: [
      { name: "/ticket", desc: "Open a support ticket" },
      { name: "/gen ticket claim", desc: "Claim an open ticket (staff)" },
      { name: "/gen ticket close", desc: "Close a ticket (staff)" },
      { name: "/gen ticket add", desc: "Add a user to the ticket (staff)" },
      { name: "/gen ticket remove", desc: "Remove a user from the ticket (staff)" },
      { name: "/gen tickets", desc: "Manage ticket settings (admin)" },
      { name: "/gen ticketpanel", desc: "Deploy ticket panel (admin)" },
    ]
  },
  applications: {
    emoji: "📝",
    label: "Applications",
    description: "Advanced staff application forms and review system.",
    commands: [
      { name: "/apply", desc: "Submit an application for the server" },
      { name: "/application", desc: "Manage/view applications (staff)" },
      { name: "/gen applications", desc: "Manage application forms (admin)" },
      { name: "/gen appanel", desc: "Interactive application panel config (admin)" },
      { name: "/export_applications", desc: "Export applications to CSV (admin)" },
    ]
  },
  giveaways: {
    emoji: "🎉",
    label: "Giveaways & Polls",
    description: "Giveaways and interactive polls.",
    commands: [
      { name: "/gen giveaway create", desc: "Create a giveaway (with role reqs, rewards, etc.)" },
      { name: "/gen giveaway reroll", desc: "Reroll giveaway winners" },
      { name: "/gen giveaway end", desc: "End a giveaway early" },
      { name: "/poll create", desc: "Create a button-based poll" },
      { name: "/gen giveawaytemplate", desc: "Manage giveaway templates" },
    ]
  },
  leveling: {
    emoji: "📈",
    label: "Leveling & XP",
    description: "Leveling system, rewards, and multipliers.",
    commands: [
      { name: "/level", desc: "Check your XP level" },
      { name: "/gen level", desc: "Leveling configuration (owner)" },
      { name: "/gen levelreward", desc: "Manage level rewards (owner)" },
      { name: "/gen xpmultiplier", desc: "Set XP multipliers (owner)" },
      { name: "/gen givexp", desc: "Give XP to a user (owner)" },
    ]
  },
  invites: {
    emoji: "📨",
    label: "Invites & Tracking",
    description: "Detailed invite tracking and leaderboards.",
    commands: [
      { name: "/invites", desc: "Check your invite count" },
      { name: "/gen invites leaderboard", desc: "View invite leaderboard" },
      { name: "/gen invites adjust", desc: "Manually adjust invites (staff)" },
    ]
  },
  profiles: {
    emoji: "👤",
    label: "Profiles & Social",
    description: "User profiles, bio, badges, marry, and friends.",
    commands: [
      { name: "/profile", desc: "View profile and stats" },
      { name: "/profile bio", desc: "Set your bio" },
      { name: "/profile marry", desc: "Marry another user" },
      { name: "/profile friends", desc: "Manage friends list" },
    ]
  },
  vanity: {
    emoji: "✨",
    label: "Vanity Roles",
    description: "Auto-assign roles when users put your vanity in status.",
    commands: [
      { name: "/gen vanity enable", desc: "Enable vanity roles system (owner)" },
      { name: "/gen vanity set", desc: "Set vanity text and rewards (owner)" },
      { name: "/gen vanity list", desc: "List users currently with vanity" },
      { name: "/gen vanity message", desc: "Set adoption message with variables" },
    ]
  },
  join2create: {
    emoji: "🔊",
    label: "Join to Create (Temp Voice)",
    description: "Temporary voice channels with owner control panel.",
    commands: [
      { name: "/gen join2create setup", desc: "Setup the join-to-create channel (admin)" },
      { name: "/gen join2create panel", desc: "Send persistent control panel" },
      { name: "/gen join2create lock", desc: "Lock your temp voice (in VC)" },
      { name: "/gen join2create limit", desc: "Set user limit (in VC)" },
      { name: "/gen join2create claim", desc: "Claim an inactive temp VC" },
    ]
  },
  greet: {
    emoji: "👋",
    label: "Greet / Welcome",
    description: "Advanced customizable greet messages (simple or rich Container).",
    commands: [
      { name: "/gen greet setup", desc: "Configure greet channels and messages (admin)" },
      { name: "/gen greet test", desc: "Test the current greet message" },
    ]
  },
  timers: {
    emoji: "⏱️",
    label: "Timers",
    description: "Persistent server timers for events.",
    commands: [
      { name: "/gen timer start", desc: "Start a named timer" },
      { name: "/gen timer pause", desc: "Pause a running timer" },
      { name: "/gen timer resume", desc: "Resume a paused timer" },
      { name: "/gen timer end", desc: "End a timer early" },
      { name: "/gen timer list", desc: "List active timers" },
    ]
  },
  leaderboards: {
    emoji: "🏆",
    label: "Leaderboards",
    description: "Invite, message, and activity leaderboards.",
    commands: [
      { name: "/gen leaderboard invites", desc: "Top inviters" },
      { name: "/gen leaderboard messages", desc: "Top message senders (daily/all-time)" },
      { name: "/gen leaderboard level", desc: "Top levels (if enabled)" },
    ]
  },
  owner: {
    emoji: "👑",
    label: "Owner & Admin",
    description: "Owner-only configuration and tools.",
    commands: [
      { name: "/gen owner", desc: "Full owner command list" },
      { name: "/gen reload", desc: "Reload commands/plugins" },
      { name: "/gen backup", desc: "Create or restore backup" },
      { name: "/gen maintenance", desc: "Toggle maintenance mode" },
      { name: "/gen analytics", desc: "View bot analytics" },
    ]
  }
};

module.exports = {
  name: "help",
  description: "Show interactive categorized help",
  type: "slash",

  async execute(interaction) {
    const userId = interaction.user.id;
    const guildId = interaction.guild.id;
    const rank = getStaffRank(userId, guildId);
    const owner = isOwner(userId);

    // Build select menu options (filter by rank where appropriate)
    const options = [];
    for (const [key, cat] of Object.entries(CATEGORIES)) {
      let show = true;
      if (key === "owner" && !owner) show = false;
      if ((key === "moderation" || key === "tickets" || key === "applications" || key === "giveaways" || key === "vanity" || key === "join2create" || key === "greet") && 
          !owner && !hasRank(userId, guildId, "helper", "admin", "developer", "giveaway_manager")) {
        show = false;
      }
      if (show) {
        options.push(
          new StringSelectMenuOptionBuilder()
            .setLabel(cat.label)
            .setValue(key)
            .setDescription(cat.description.slice(0, 100))
            .setEmoji(cat.emoji)
        );
      }
    }

    const select = new StringSelectMenuBuilder()
      .setCustomId("help_category_select")
      .setPlaceholder("Select a category to view commands...")
      .addOptions(options.slice(0, 25)); // Discord limit

    const container = new ContainerBuilder()
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`# 📖 ${interaction.guild.name} — Interactive Help`)
      )
      .addSeparatorComponents(
        new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent("Use the menu below to browse commands by category. Your available commands are shown based on your rank.")
      )
      .addActionRowComponents(
        new ActionRowBuilder().addComponents(select)
      );

    const reply = await interaction.reply({
      components: [container],
      flags: MessageFlags.IsComponentsV2,
      ephemeral: true
    });

    // Collector for select menu
    const collector = reply.createMessageComponentCollector({
      filter: i => i.user.id === userId && i.customId === "help_category_select",
      time: 180000 // 3 minutes
    });

    collector.on("collect", async i => {
      const catKey = i.values[0];
      const cat = CATEGORIES[catKey];
      if (!cat) return i.reply({ content: "Category not found.", ephemeral: true });

      const cmdList = cat.commands.map(c => `**${c.name}** — ${c.desc}`).join("\n");

      const catContainer = new ContainerBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`# ${cat.emoji} ${cat.label}`)
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(cat.description)
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(cmdList || "No commands in this category yet.")
        )
        .addActionRowComponents(
          new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
              .setCustomId("help_category_select")
              .setPlaceholder("Select another category...")
              .addOptions(options.slice(0, 25))
          )
        );

      await i.update({
        components: [catContainer],
        flags: MessageFlags.IsComponentsV2
      });
    });

    collector.on("end", () => {
      // Optionally disable the menu after timeout
    });
  },
};