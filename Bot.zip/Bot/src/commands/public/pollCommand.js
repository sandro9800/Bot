const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { getDB } = require("../../database/db");
const { COLORS } = require("../../config");

module.exports = {
  name: "poll",
  description: "Create an interactive button poll",
  type: "slash",
  options: [
    { name: "question", description: "The poll question", type: 3, required: true },
    { name: "option1", description: "Option 1", type: 3, required: true },
    { name: "option2", description: "Option 2", type: 3, required: true },
    { name: "option3", description: "Option 3 (optional)", type: 3, required: false },
    { name: "option4", description: "Option 4 (optional)", type: 3, required: false },
    { name: "option5", description: "Option 5 (optional)", type: 3, required: false }
  ],

  async execute(interactionOrMessage, args, client) {
    let isSlash = interactionOrMessage.isChatInputCommand ? true : false;

    if (isSlash) {
      const interaction = interactionOrMessage;
      const question = interaction.options.getString("question");
      const options = [];
      for (let i = 1; i <= 5; i++) {
        const opt = interaction.options.getString(`option${i}`);
        if (opt) options.push(opt);
      }

      if (options.length < 2) return interaction.reply({ content: "Need at least 2 options.", ephemeral: true });

      const db = getDB();
      const pollData = {
        question,
        options: JSON.stringify(options),
        votes: JSON.stringify({}),
        created_by: interaction.user.id
      };

      const result = db.prepare(`
        INSERT INTO polls (guild_id, channel_id, question, options, votes, created_by)
        VALUES (?, ?, ?, ?, ?, ?)
      `).run(interaction.guild.id, interaction.channel.id, question, pollData.options, pollData.votes, interaction.user.id);

      const pollId = result.lastInsertRowid;

      const buttons = options.map((opt, index) => 
        new ButtonBuilder()
          .setCustomId(`poll_vote_${pollId}_${index}`)
          .setLabel(opt)
          .setStyle(ButtonStyle.Primary)
      );

      const row = new ActionRowBuilder().addComponents(buttons);

      const embed = new EmbedBuilder()
        .setColor(COLORS.BOT)
        .setTitle("📊 Poll")
        .setDescription(question)
        .setFooter({ text: `Poll ID: ${pollId} • Click buttons to vote` });

      const msg = await interaction.reply({ embeds: [embed], components: [row] });

      db.prepare("UPDATE polls SET message_id = ? WHERE id = ?").run(msg.id, pollId);
    } else {
      // Prefix ?gen poll <question> | opt1 | opt2 | ...
      const message = interactionOrMessage;
      const full = args.join(" ");
      const parts = full.split("|").map(p => p.trim());
      if (parts.length < 3) return message.reply("Usage: ?gen poll <question> | option1 | option2 | ...");

      const question = parts[0];
      const options = parts.slice(1);

      const db = getDB();
      const pollData = {
        question,
        options: JSON.stringify(options),
        votes: JSON.stringify({}),
        created_by: message.author.id
      };

      const result = db.prepare(`
        INSERT INTO polls (guild_id, channel_id, question, options, votes, created_by)
        VALUES (?, ?, ?, ?, ?, ?)
      `).run(message.guild.id, message.channel.id, question, pollData.options, pollData.votes, message.author.id);

      const pollId = result.lastInsertRowid;

      const buttons = options.map((opt, index) => 
        new ButtonBuilder()
          .setCustomId(`poll_vote_${pollId}_${index}`)
          .setLabel(opt)
          .setStyle(ButtonStyle.Primary)
      );

      const row = new ActionRowBuilder().addComponents(buttons);

      const embed = new EmbedBuilder()
        .setColor(COLORS.BOT)
        .setTitle("📊 Poll")
        .setDescription(question)
        .setFooter({ text: `Poll ID: ${pollId} • Click buttons to vote` });

      const msg = await message.reply({ embeds: [embed], components: [row] });

      db.prepare("UPDATE polls SET message_id = ? WHERE id = ?").run(msg.id, pollId);
    }
  }
};
