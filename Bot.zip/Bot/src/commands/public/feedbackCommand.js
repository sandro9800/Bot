const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { getFeedback, getAverageRating } = require("../../systems/ticketFeedback");

module.exports = {
  name: "feedback",
  async execute(message, args, client) {
    const guildId = message.guild.id;
    const feedback = getFeedback(guildId);
    const avg = getAverageRating(guildId);

    if (!feedback.length) return message.channel.send("❌ No ticket feedback yet.");

    const dist = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
    for (const f of feedback) dist[f.rating] = (dist[f.rating] || 0) + 1;

    const embed = new EmbedBuilder()
      .setColor(COLORS.BOT)
      .setTitle("⭐ Ticket Feedback Stats")
      .addFields(
        { name: "Average Rating", value: `**${avg}/5** ⭐`, inline: true },
        { name: "Total Ratings", value: `**${feedback.length}**`, inline: true },
        { name: "Distribution", value: Object.entries(dist).map(([r, c]) => `${"⭐".repeat(Number(r))} — **${c}**`).join("\n") },
      )
      .setTimestamp();

    return message.channel.send({ embeds: [embed] });
  },
};
