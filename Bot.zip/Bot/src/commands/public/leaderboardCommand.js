const { EmbedBuilder } = require("discord.js");
const { getMessageLeaderboard } = require("../../systems/messageTracker");
const { COLORS } = require("../../config");

module.exports = {
  name: "leaderboard",
  description: "View leaderboards",
  type: "slash",
  options: [
    { name: "type", description: "messages or invites", type: 3, required: true, choices: [
      { name: "messages", value: "messages" },
      { name: "invites", value: "invites" }
    ]}
  ],

  async execute(interactionOrMessage, args, client) {
    let isSlash = interactionOrMessage.isChatInputCommand ? true : false;
    let guildId;

    if (isSlash) {
      const interaction = interactionOrMessage;
      guildId = interaction.guild.id;
      const type = interaction.options.getString("type");

      if (type === "messages") {
        const top = getMessageLeaderboard(guildId, "alltime", 10);
        const desc = top.map((entry, i) => `${i+1}. <@${entry.user_id}> — ${entry.count} messages`).join("\n") || "No data yet.";
        const embed = new EmbedBuilder().setColor(COLORS.BOT).setTitle("🏆 Message Leaderboard (All-time)").setDescription(desc);
        return interaction.reply({ embeds: [embed] });
      }
      return interaction.reply("Invite leaderboard coming from enhanced invites system.");
    } else {
      const message = interactionOrMessage;
      guildId = message.guild.id;
      const type = (args[0] || "messages").toLowerCase();

      if (type === "messages") {
        const top = getMessageLeaderboard(guildId, "alltime", 10);
        const desc = top.map((entry, i) => `${i+1}. <@${entry.user_id}> — ${entry.count} messages`).join("\n") || "No data yet.";
        const embed = new EmbedBuilder().setColor(COLORS.BOT).setTitle("🏆 Message Leaderboard (All-time)").setDescription(desc);
        return message.reply({ embeds: [embed] });
      }
      return message.reply("Usage: ?gen leaderboard messages");
    }
  }
};
