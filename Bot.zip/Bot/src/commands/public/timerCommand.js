const { EmbedBuilder } = require("discord.js");
const { createTimer, getActiveTimers } = require("../../systems/timers");
const { COLORS } = require("../../config");

module.exports = {
  name: "timer",
  description: "Manage persistent timers",
  type: "slash",
  options: [
    { name: "action", description: "start | list | pause | resume | end", type: 3, required: true },
    { name: "name", description: "Timer name", type: 3, required: false },
    { name: "duration", description: "Duration in minutes (for start)", type: 4, required: false },
    { name: "message", description: "Message when timer ends (for start)", type: 3, required: false }
  ],

  async execute(interactionOrMessage, args, client) {
    let isSlash = interactionOrMessage.isChatInputCommand ? true : false;
    let guildId, userId, options;

    if (isSlash) {
      const interaction = interactionOrMessage;
      guildId = interaction.guild.id;
      userId = interaction.user.id;
      const action = interaction.options.getString("action").toLowerCase();
      const name = interaction.options.getString("name");
      const duration = (interaction.options.getInteger("duration") || 10) * 60000;
      const msg = interaction.options.getString("message") || "Timer ended!";

      if (action === "start") {
        const id = createTimer(guildId, name || `timer-${Date.now()}`, duration, msg, userId);
        return interaction.reply(`⏱️ Timer started. ID: ${id}`);
      }
      if (action === "list") {
        const timers = getActiveTimers(guildId);
        if (!timers.length) return interaction.reply("No active timers.");
        const list = timers.map(t => `**${t.name}** — ends <t:${Math.floor(t.end_time/1000)}:R>`).join("\n");
        return interaction.reply({ embeds: [new EmbedBuilder().setColor(COLORS.BOT).setDescription(list)] });
      }
      return interaction.reply("Timer management (pause/resume/end) coming soon in full implementation.");
    } else {
      // Prefix support: ?gen timer start <name> <minutes> [message]
      const message = interactionOrMessage;
      guildId = message.guild.id;
      userId = message.author.id;
      const action = (args[0] || "").toLowerCase();
      const name = args[1];
      const durationMin = parseInt(args[2]) || 10;
      const msg = args.slice(3).join(" ") || "Timer ended!";

      if (action === "start") {
        const id = createTimer(guildId, name || `timer-${Date.now()}`, durationMin * 60000, msg, userId);
        return message.reply(`⏱️ Timer started. ID: ${id}`);
      }
      if (action === "list") {
        const timers = getActiveTimers(guildId);
        if (!timers.length) return message.reply("No active timers.");
        const list = timers.map(t => `**${t.name}** — ends <t:${Math.floor(t.end_time/1000)}:R>`).join("\n");
        return message.reply({ embeds: [new EmbedBuilder().setColor(COLORS.BOT).setDescription(list)] });
      }
      return message.reply("Usage: ?gen timer start <name> <minutes> [message] or ?gen timer list");
    }
  }
};
