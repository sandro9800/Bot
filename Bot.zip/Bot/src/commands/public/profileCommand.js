const { EmbedBuilder } = require("discord.js");
const { getProfile } = require("../../systems/profiles");
const { COLORS } = require("../../config");

module.exports = {
  name: "profile",
  description: "View your or another user's profile",
  type: "slash",
  options: [
    {
      name: "user",
      description: "The user to view profile for",
      type: 6, // USER
      required: false
    }
  ],

  async execute(interactionOrMessage, args, client) {
    let isSlash = interactionOrMessage.isChatInputCommand ? true : false;

    if (isSlash) {
      const interaction = interactionOrMessage;
      const target = interaction.options.getUser("user") || interaction.user;
      const guildId = interaction.guild.id;
      const profile = getProfile(guildId, target.id);

      const embed = new EmbedBuilder()
        .setColor(COLORS.BOT)
        .setTitle(`${target.tag}'s Profile`)
        .setThumbnail(target.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: "Bio", value: profile.bio || "No bio set yet. Use /gen profile bio to set one.", inline: false },
          { name: "Badges", value: profile.badges.length ? profile.badges.join(", ") : "None", inline: true },
          { name: "Married To", value: profile.married_to ? `<@${profile.married_to}>` : "Single", inline: true },
          { name: "Friends", value: profile.friends.length ? profile.friends.map(id => `<@${id}>`).join(", ") : "None", inline: false }
        )
        .setTimestamp();

      await interaction.reply({ embeds: [embed], ephemeral: false });
    } else {
      // Prefix ?gen profile [@user]
      const message = interactionOrMessage;
      const target = message.mentions.users.first() || message.author;
      const guildId = message.guild.id;
      const profile = getProfile(guildId, target.id);

      const embed = new EmbedBuilder()
        .setColor(COLORS.BOT)
        .setTitle(`${target.tag}'s Profile`)
        .setThumbnail(target.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: "Bio", value: profile.bio || "No bio set yet. Use ?gen profile bio to set one.", inline: false },
          { name: "Badges", value: profile.badges.length ? profile.badges.join(", ") : "None", inline: true },
          { name: "Married To", value: profile.married_to ? `<@${profile.married_to}>` : "Single", inline: true },
          { name: "Friends", value: profile.friends.length ? profile.friends.map(id => `<@${id}>`).join(", ") : "None", inline: false }
        )
        .setTimestamp();

      await message.reply({ embeds: [embed] });
    }
  }
};
