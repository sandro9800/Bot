const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  PermissionFlagsBits,
} = require("discord.js");
const { COLORS } = require("../../config");
const { isOwner, hasRank, isMod } = require("../../utils/permissions");
const {
  getTicketConfig,
  saveTicketConfig,
  getTicketData,
  saveTicketData,
  deleteTicketData,
  buildTicketPanelEmbed,
  buildTicketPanelRow,
  createTicket,
  closeTicket,
} = require("../../systems/tickets");
const { readJson } = require("../../database/store");

function canStaffTickets(userId, guildId) {
  return isOwner(userId) || hasRank(userId, guildId, "helper", "admin");
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("ticket")
    .setDescription("Ticket system")
    // open (public)
    .addSubcommand((sub) =>
      sub
        .setName("open")
        .setDescription("Open a support ticket")
        .addStringOption((o) =>
          o
            .setName("type")
            .setDescription("Type of ticket")
            .setRequired(true)
            .addChoices(
              { name: "🛠️ Support", value: "support" },
              { name: "💸 Purchase", value: "purchase" },
              { name: "🚨 Report", value: "report" }
            )
        )
    )
    // claim (staff)
    .addSubcommand((sub) =>
      sub.setName("claim").setDescription("Claim the current ticket (staff only)")
    )
    // close (staff)
    .addSubcommand((sub) =>
      sub.setName("close").setDescription("Close the current ticket (staff only)")
    )
    // add user (staff)
    .addSubcommand((sub) =>
      sub
        .setName("add")
        .setDescription("Add a user to the current ticket")
        .addUserOption((o) =>
          o.setName("user").setDescription("User to add").setRequired(true)
        )
    )
    // remove user (staff)
    .addSubcommand((sub) =>
      sub
        .setName("remove")
        .setDescription("Remove a user from the current ticket")
        .addUserOption((o) =>
          o.setName("user").setDescription("User to remove").setRequired(true)
        )
    )
    // setup (admin)
    .addSubcommand((sub) =>
      sub
        .setName("setup")
        .setDescription("Configure the ticket system (admin only)")
        .addChannelOption((o) =>
          o.setName("category").setDescription("Category to create tickets in").setRequired(false)
        )
        .addRoleOption((o) =>
          o.setName("support_role").setDescription("Role pinged on ticket open").setRequired(false)
        )
        .addChannelOption((o) =>
          o.setName("log_channel").setDescription("Channel to send ticket logs").setRequired(false)
        )
    )
    // panel (admin)
    .addSubcommand((sub) =>
      sub.setName("panel").setDescription("Deploy a ticket panel in this channel (admin only)")
    )
    // list (staff)
    .addSubcommand((sub) =>
      sub.setName("list").setDescription("List all open tickets (staff only)")
    ),

  category: "public",

  async execute(interaction) {
    const userId = interaction.user.id;
    const guildId = interaction.guild.id;
    const sub = interaction.options.getSubcommand();

    // ── OPEN (public) ─────────────────────────────────────────────────────────
    if (sub === "open") {
      const type = interaction.options.getString("type");

      // Check if user already has an open ticket
      const db = readJson("tickets");
      const openTickets = db.open?.[guildId] || {};
      const existing = Object.values(openTickets).find(
        (t) => t.userId === userId && t.type === type
      );
      if (existing) {
        return interaction.reply({
          content: `❌ You already have an open **${type}** ticket. Please use that one first.`,
          ephemeral: true,
        });
      }

      await interaction.deferReply({ ephemeral: true });
      const ch = await createTicket(interaction, type);
      return interaction.editReply({
        content: `✅ Your ticket has been created: ${ch}`,
      });
    }

    // ── CLAIM (staff) ─────────────────────────────────────────────────────────
    if (sub === "claim") {
      if (!canStaffTickets(userId, guildId)) {
        return interaction.reply({ content: "❌ Only staff can claim tickets.", ephemeral: true });
      }

      const ticket = getTicketData(guildId, interaction.channel.id);
      if (!ticket) {
        return interaction.reply({ content: "❌ This is not a ticket channel.", ephemeral: true });
      }
      if (ticket.claimed) {
        return interaction.reply({
          content: `❌ This ticket is already claimed by <@${ticket.claimedBy}>.`,
          ephemeral: true,
        });
      }

      ticket.claimed = true;
      ticket.claimedBy = userId;
      saveTicketData(guildId, interaction.channel.id, ticket);

      const embed = new EmbedBuilder()
        .setColor(COLORS.SUCCESS)
        .setDescription(`✋ Ticket claimed by ${interaction.user}.`)
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    // ── CLOSE (staff) ─────────────────────────────────────────────────────────
    if (sub === "close") {
      if (!canStaffTickets(userId, guildId)) {
        return interaction.reply({ content: "❌ Only staff can close tickets.", ephemeral: true });
      }

      const ticket = getTicketData(guildId, interaction.channel.id);
      if (!ticket) {
        return interaction.reply({ content: "❌ This is not a ticket channel.", ephemeral: true });
      }

      await interaction.reply({
        content: "🔒 Closing ticket and saving transcript...",
      });

      await closeTicket(interaction, ticket);
    }

    // ── ADD ───────────────────────────────────────────────────────────────────
    if (sub === "add") {
      if (!canStaffTickets(userId, guildId)) {
        return interaction.reply({ content: "❌ Only staff can add users to tickets.", ephemeral: true });
      }

      const ticket = getTicketData(guildId, interaction.channel.id);
      if (!ticket) {
        return interaction.reply({ content: "❌ This is not a ticket channel.", ephemeral: true });
      }

      const target = interaction.options.getUser("user");
      try {
        await interaction.channel.permissionOverwrites.create(target.id, {
          ViewChannel: true,
          SendMessages: true,
          ReadMessageHistory: true,
        });
        return interaction.reply({ content: `✅ Added ${target} to the ticket.` });
      } catch (_) {
        return interaction.reply({ content: "❌ Failed to add user.", ephemeral: true });
      }
    }

    // ── REMOVE ────────────────────────────────────────────────────────────────
    if (sub === "remove") {
      if (!canStaffTickets(userId, guildId)) {
        return interaction.reply({ content: "❌ Only staff can remove users from tickets.", ephemeral: true });
      }

      const ticket = getTicketData(guildId, interaction.channel.id);
      if (!ticket) {
        return interaction.reply({ content: "❌ This is not a ticket channel.", ephemeral: true });
      }

      const target = interaction.options.getUser("user");
      if (target.id === ticket.userId) {
        return interaction.reply({ content: "❌ Cannot remove the ticket opener.", ephemeral: true });
      }

      try {
        await interaction.channel.permissionOverwrites.delete(target.id);
        return interaction.reply({ content: `✅ Removed ${target} from the ticket.` });
      } catch (_) {
        return interaction.reply({ content: "❌ Failed to remove user.", ephemeral: true });
      }
    }

    // ── SETUP (admin) ─────────────────────────────────────────────────────────
    if (sub === "setup") {
      if (!isOwner(userId) && !hasRank(userId, guildId, "admin")) {
        return interaction.reply({ content: "❌ Only admins can configure the ticket system.", ephemeral: true });
      }

      const cfg = getTicketConfig(guildId);
      const category = interaction.options.getChannel("category");
      const supportRole = interaction.options.getRole("support_role");
      const logChannel = interaction.options.getChannel("log_channel");

      if (category) cfg.categoryId = category.id;
      if (supportRole) cfg.supportRole = supportRole.id;
      if (logChannel) cfg.logChannel = logChannel.id;

      saveTicketConfig(guildId, cfg);

      const embed = new EmbedBuilder()
        .setColor(COLORS.SUCCESS)
        .setTitle("✅ Ticket System Configured")
        .addFields(
          { name: "Category", value: category ? `${category}` : cfg.categoryId ? `<#${cfg.categoryId}>` : "Not set", inline: true },
          { name: "Support Role", value: supportRole ? `${supportRole}` : cfg.supportRole ? `<@&${cfg.supportRole}>` : "Not set", inline: true },
          { name: "Log Channel", value: logChannel ? `${logChannel}` : cfg.logChannel ? `<#${cfg.logChannel}>` : "Not set", inline: true }
        )
        .setTimestamp();

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    // ── PANEL (admin) ─────────────────────────────────────────────────────────
    if (sub === "panel") {
      if (!isOwner(userId) && !hasRank(userId, guildId, "admin")) {
        return interaction.reply({ content: "❌ Only admins can deploy ticket panels.", ephemeral: true });
      }

      await interaction.channel.send({
        embeds: [buildTicketPanelEmbed(interaction.guild)],
        components: [buildTicketPanelRow()],
      });

      return interaction.reply({ content: "✅ Ticket panel deployed.", ephemeral: true });
    }

    // ── LIST (staff) ──────────────────────────────────────────────────────────
    if (sub === "list") {
      if (!canStaffTickets(userId, guildId)) {
        return interaction.reply({ content: "❌ Only staff can list tickets.", ephemeral: true });
      }

      const db = readJson("tickets");
      const openTickets = Object.entries(db.open?.[guildId] || {});

      if (!openTickets.length) {
        return interaction.reply({ content: "📭 No open tickets.", ephemeral: true });
      }

      const fields = openTickets.map(([chId, t]) => ({
        name: t.ticketName || chId,
        value: `User: <@${t.userId}> | Type: **${t.type}** | Claimed: **${t.claimed ? `<@${t.claimedBy}>` : "No"}** | <#${chId}>`,
        inline: false,
      }));

      const embed = new EmbedBuilder()
        .setColor(COLORS.BOT)
        .setTitle(`🎫 Open Tickets — ${openTickets.length}`)
        .addFields(fields)
        .setTimestamp();

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
  },
};
