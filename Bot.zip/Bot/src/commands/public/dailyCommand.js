const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../config");
const { canClaimDaily, claimDaily, getStreak, getNextDaily } = require("../../systems/daily");
const { addXP } = require("../../systems/levels");
const { checkLevelRewards } = require("../../systems/levelRewards");

module.exports = {
  name: "daily",
  async execute(message, args, client) {
    const userId = message.author.id;
    const guildId = message.guild.id;

    if (!canClaimDaily(userId, guildId)) {
      const next = getNextDaily(userId, guildId);
      const streak = getStreak(userId, guildId);
      return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.WARN).setTitle("⏳ Daily Already Claimed").addFields({ name: "Next Claim", value: `<t:${Math.floor(next / 1000)}:R>`, inline: true }, { name: "🔥 Streak", value: `**${streak}** days`, inline: true }).setTimestamp()] });
    }

    const { xp, streak, bonus } = claimDaily(userId, guildId);
    const result = addXP(guildId, userId, xp);

    if (result.leveledUp) {
      try {
        const member = await message.guild.members.fetch(userId);
        await checkLevelRewards(message.guild, member, result.level);
      } catch (_) {}
    }

    return message.channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("🎁 Daily XP Claimed!").setThumbnail(message.author.displayAvatarURL({ dynamic: true })).addFields(
      { name: "⭐ XP Earned", value: `**+${xp}** XP`, inline: true },
      { name: "🔥 Streak", value: `**${streak}** day${streak !== 1 ? "s" : ""}`, inline: true },
      { name: "🎯 Streak Bonus", value: `**+${bonus}** XP`, inline: true },
      { name: "🎉 Level Up?", value: result.leveledUp ? `Yes! Now Level **${result.level}**` : "Not yet", inline: true },
    ).setFooter({ text: "Come back tomorrow for your next daily!" }).setTimestamp()] });
  },
};
