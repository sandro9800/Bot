module.exports = {
  ALLOWED_USERS: ["1188143467948417024", "1496199601861034035"],
  PREFIX: "?gen",
  DEFAULT_COOLDOWN: 300,
  LOW_STOCK_THRESHOLD: 5,
  MASTER_DB_FILE: "DB.txt",
  STOCK_FILE: "stock.txt",
  COLORS: {
    BOT: "#5865F2",
    SUCCESS: "#2ef76e",
    ERROR: "#ed4245",
    WARN: "#faa61a",
    INFO: "#1b2838",
  },
  STAFF_RANKS: ["helper", "admin", "developer", "giveaway_manager"],
};
