const { saveSnipe } = require("../systems/snipe");

module.exports = {
  name: "messageDelete",
  async execute(message) {
    if (!message.guild || message.author?.bot) return;
    try {
      saveSnipe(message.guild.id, message.channel.id, message.content || "[No content]", message.author?.id);
    } catch (e) {}
  }
};
