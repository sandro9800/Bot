const { inviteCache } = require("../systems/invites");

module.exports = [
  {
    name: "inviteCreate",
    async execute(client, invite) {
      const invites = inviteCache.get(invite.guild.id) || new Map();
      invites.set(invite.code, invite.uses);
      inviteCache.set(invite.guild.id, invites);
    },
  },
  {
    name: "inviteDelete",
    async execute(client, invite) {
      const invites = inviteCache.get(invite.guild.id);
      if (invites) invites.delete(invite.code);
    },
  },
];
