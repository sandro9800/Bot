const { getConfig, getStorage } = require("../database/store");

const antiSpamMap = new Map();

function checkAntiSpam(message) {
  const config = getConfig(message.guild.id);
  if (config.antiSpamEnabled === false) return false;
  const userId = message.author.id;
  const now = Date.now();
  if (!antiSpamMap.has(userId)) antiSpamMap.set(userId, []);
  const timestamps = antiSpamMap.get(userId).filter(t => now - t < 5000);
  timestamps.push(now);
  antiSpamMap.set(userId, timestamps);
  return timestamps.length > 5;
}

function checkBadWords(message) {
  const config = getConfig(message.guild.id);
  if (config.antiBadwordsEnabled === false) return false;
  const storage = getStorage();
  const words = storage.badwords || [];
  const content = message.content.toLowerCase();
  return words.some(w => content.includes(w));
}

function checkAntiLink(message) {
  const config = getConfig(message.guild.id);
  if (!config.antiLinkEnabled) return false;
  const storage = getStorage();
  const whitelist = storage.linkWhitelist || [];
  const urlRegex = /(https?:\/\/[^\s]+)/gi;
  const matches = message.content.match(urlRegex);
  if (!matches) return false;
  return matches.some(url => !whitelist.some(domain => url.includes(domain)));
}

function checkAntiInvite(message) {
  const config = getConfig(message.guild.id);
  if (!config.antiInviteEnabled) return false;
  return /discord\.gg\/[a-zA-Z0-9]+/.test(message.content);
}

function checkAntiMention(message) {
  const config = getConfig(message.guild.id);
  if (!config.antiMentionEnabled) return false;
  const threshold = config.antiMentionThreshold || 5;
  const mentionCount = message.mentions.users.size + message.mentions.roles.size;
  return mentionCount >= threshold;
}

module.exports = { checkAntiSpam, checkBadWords, checkAntiLink, checkAntiInvite, checkAntiMention };
