const { EmbedBuilder } = require("discord.js");
const { sendLog } = require("../systems/moderation");
const { COLORS } = require("../config");

module.exports = {
  name: "messageUpdate",
  async execute(client, oldMessage, newMessage) {
    if (!oldMessage.guild || oldMessage.author?.bot) return;
    if (oldMessage.content === newMessage.content) return;
    await sendLog(oldMessage.guild, "messageEdit", new EmbedBuilder()
      .setColor(COLORS.WARN).setTitle("✏️ Message Edited")
      .addFields(
        { name: "Author", value: `${oldMessage.author?.tag}`, inline: true },
        { name: "Channel", value: `<#${oldMessage.channel.id}>`, inline: true },
        { name: "Before", value: (oldMessage.content || "N/A").slice(0, 1024) },
        { name: "After", value: (newMessage.content || "N/A").slice(0, 1024) }
      ).setTimestamp());
  },
};
