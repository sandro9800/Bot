const { EmbedBuilder } = require("discord.js");
const { sendLog } = require("../systems/moderation");
const { COLORS } = require("../config");

module.exports = [
  {
    name: "guildBanAdd",
    async execute(client, ban) {
      await sendLog(ban.guild, "ban", new EmbedBuilder()
        .setColor(COLORS.ERROR)
        .setTitle("🔨 Member Banned")
        .setThumbnail(ban.user.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: "User", value: `${ban.user.tag} (\`${ban.user.id}\`)`, inline: true },
          { name: "Reason", value: ban.reason || "No reason provided", inline: true }
        ).setTimestamp());
    },
  },
  {
    name: "guildBanRemove",
    async execute(client, ban) {
      await sendLog(ban.guild, "unban", new EmbedBuilder()
        .setColor(COLORS.SUCCESS)
        .setTitle("✅ Member Unbanned")
        .setThumbnail(ban.user.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: "User", value: `${ban.user.tag} (\`${ban.user.id}\`)`, inline: true }
        ).setTimestamp());
    },
  },
];
