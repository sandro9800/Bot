const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, AttachmentBuilder } = require("discord.js");
const { COLORS } = require("../config");
const { isMod, isAdmin } = require("../utils/permissions");
const { getStorage, saveStorage, getConfig, getClients } = require("../database/store");
const { popFirstLine, readLines, buildGenEmbed, buildRow, sendGenLog, checkLowStock, updateAllPanels } = require("../systems/stock");
const { giveaways, saveGiveaway } = require("../systems/giveaways");
const { createTicket, closeTicket, getTicketData, saveTicketData } = require("../systems/tickets");
const { addReport, updateReportStatus } = require("../systems/reports");
const { updateApplicationStatus } = require("../systems/applications");
const { getUserLevel, getXPForLevel, getLeaderboard } = require("../systems/levels");
const { setAfk } = require("../systems/afk");
const { addFeedback } = require("../systems/ticketFeedback");
const { handleVerify } = require("../systems/verification");
const { fmtTime, parseInterval } = require("../utils/format");
const path = require("path");
const fs = require("fs");

const userCooldowns = {};
const lastClick = {};

function getCooldown(userId) { return userCooldowns[userId] !== undefined ? userCooldowns[userId] : 300; }
function secondsUntilReady(userId) { return Math.max(0, getCooldown(userId) - (Date.now() - (lastClick[userId] || 0)) / 1000); }

module.exports = {
  name: "interactionCreate",
  async execute(client, interaction) {
    try {
      if (interaction.isChatInputCommand()) {
        if (interaction.commandName === "gen" && interaction.options.getSubcommand() === "rank") {
          const target = interaction.options.getUser("user") || interaction.user;
          const data = getUserLevel(interaction.guild.id, target.id);
          const needed = getXPForLevel(data.level);
          const progress = Math.floor((data.xp / needed) * 20);
          const bar = "🟦".repeat(progress) + "⬜".repeat(20 - progress);
          const lb = getLeaderboard(interaction.guild.id, 1000);
          const rank = lb.findIndex(u => u.userId === target.id) + 1;
          return interaction.reply({ embeds: [new EmbedBuilder().setColor(COLORS.BOT).setTitle(`📊 Rank — ${target.username}`).setThumbnail(target.displayAvatarURL({ dynamic: true })).addFields({ name: "🏆 Rank", value: `#**${rank || "N/A"}**`, inline: true }, { name: "🎯 Level", value: `**${data.level}**`, inline: true }, { name: "⭐ XP", value: `**${data.xp}** / **${needed}**`, inline: true }, { name: "📈 Progress", value: `\`[${bar}]\` ${Math.floor((data.xp / needed) * 100)}%` }).setTimestamp()] });
        }
        if (interaction.commandName === "gen" && interaction.options.getSubcommand() === "afk") {
          const reason = interaction.options.getString("reason") || "AFK";
          const durationStr = interaction.options.getString("duration");
          let expiresAt = null;
          if (durationStr) { const ms = parseInterval(durationStr); if (ms) expiresAt = Date.now() + ms; }
          setAfk(interaction.guild.id, interaction.user.id, reason, expiresAt);
          return interaction.reply({ embeds: [new EmbedBuilder().setColor(COLORS.BOT).setTitle("💤 AFK Set").setDescription(`${interaction.user}, you are now AFK.\n**Reason:** ${reason}${expiresAt ? `\n**Expires:** <t:${Math.floor(expiresAt / 1000)}:R>` : ""}`).setTimestamp()] });
        }
        if (interaction.commandName === "gen" && interaction.options.getSubcommand() === "report") {
          const target = interaction.options.getUser("user");
          const reason = interaction.options.getString("reason");
          const report = addReport(interaction.guild.id, { reporterId: interaction.user.id, reporterTag: interaction.user.username, targetId: target.id, targetTag: target.username, reason });
          const config = getConfig(interaction.guild.id);
          if (config.reportChannel) {
            try {
              const ch = await interaction.guild.channels.fetch(config.reportChannel);
              const embed = new EmbedBuilder().setColor(COLORS.ERROR).setTitle(`🚨 Report #${report.id}`).addFields({ name: "Reporter", value: interaction.user.username, inline: true }, { name: "Reported", value: target.username, inline: true }, { name: "Reason", value: reason }, { name: "Status", value: "⏳ Pending" }).setTimestamp();
              const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`report_accept_${report.id}`).setLabel("✅ Accept").setStyle(ButtonStyle.Success), new ButtonBuilder().setCustomId(`report_deny_${report.id}`).setLabel("❌ Deny").setStyle(ButtonStyle.Danger));
              await ch.send({ embeds: [embed], components: [row] });
            } catch (_) {}
          }
          return interaction.reply({ content: `✅ Report #${report.id} submitted!`, ephemeral: true });
        }

        // New /gen subcommands for transferred features
        if (interaction.commandName === "gen") {
          const sub = interaction.options.getSubcommand();

          if (sub === "profile") {
            const profileCmd = require("../commands/public/profileCommand");
            return profileCmd.execute(interaction);
          }
          if (sub === "poll") {
            const pollCmd = require("../commands/public/pollCommand");
            return pollCmd.execute(interaction);
          }
          if (sub === "timer") {
            const timerCmd = require("../commands/public/timerCommand");
            return timerCmd.execute(interaction);
          }
          if (sub === "leaderboard") {
            const lbCmd = require("../commands/public/leaderboardCommand");
            return lbCmd.execute(interaction);
          }
          if (sub === "vanity") {
            // For slash, simulate prefix args from options
            const action = interaction.options.getString("action") || "";
            const text = interaction.options.getString("text") || "";
            const msg = { guild: interaction.guild, author: interaction.user, reply: (c) => interaction.reply(c), mentions: { roles: new Map(), channels: new Map() } };
            const args = ["vanity", action, text].filter(Boolean);
            const vanityCmd = require("../commands/owner/vanityCommand");
            return vanityCmd.execute(msg, args, client);
          }
          if (sub === "join2create") {
            const action = interaction.options.getString("action") || "";
            const msg = { guild: interaction.guild, author: interaction.user, reply: (c) => interaction.reply(c) };
            const args = ["join2create", action].filter(Boolean);
            const j2cCmd = require("../commands/owner/join2createCommand");
            return j2cCmd.execute(msg, args, client);
          }
          if (sub === "greet") {
            const action = interaction.options.getString("action") || "";
            const msg = { guild: interaction.guild, author: interaction.user, reply: (c) => interaction.reply(c) };
            const args = ["greet", action].filter(Boolean);
            const greetCmd = require("../commands/owner/greetCommand");
            return greetCmd.execute(msg, args, client);
          }
          if (sub === "snipe") {
            const snipeCmd = require("../commands/moderation/snipeCommand");
            return snipeCmd.execute(interaction);
          }
        }
        if (interaction.commandName === "leaderboard") {
          const lb = getLeaderboard(interaction.guild.id, 10);
          if (!lb.length) return interaction.reply({ content: "No leveling data yet!", ephemeral: true });
          const medals = ["🥇","🥈","🥉"];
          const desc = lb.map((u, i) => `${i < 3 ? medals[i] : `**${i + 1}.**`} <@${u.userId}> — Level **${u.level}** (${u.totalXp} XP)`).join("\n");
          return interaction.reply({ embeds: [new EmbedBuilder().setColor(COLORS.BOT).setTitle("🏆 XP Leaderboard").setDescription(desc).setTimestamp()] });
        }
        if (interaction.commandName === "help") {
          return interaction.reply({ embeds: [new EmbedBuilder().setColor(COLORS.BOT).setTitle("📖 Gen Bot Help").setDescription("Use `?gen help` for the full command list.\n\n**Slash Commands**\n`/gen rank` `/gen afk` `/gen report`\n`/leaderboard`").setTimestamp()], ephemeral: true });
        }
      }

      if (interaction.isStringSelectMenu() && interaction.customId === "client_select") {
        const fileName = interaction.values[0];
        const clients = getClients();
        const entry = clients.find(c => c.fileName === fileName);
        if (!entry) return interaction.reply({ ephemeral: true, content: "❌ Client not found." });
        const CLIENTS_DIR = path.join(process.cwd(), "clients");
        const EXTS = [".jar", ".zip", ".dll", ".exe"];
        const foundExt = EXTS.find(ext => fs.existsSync(path.join(CLIENTS_DIR, `${fileName}${ext}`)));
        const txtPath = path.join(CLIENTS_DIR, `${fileName}.txt`);
        if (!foundExt) return interaction.reply({ ephemeral: true, content: `❌ No file found for \`${fileName}\`.` });
        await interaction.deferReply({ ephemeral: true });
        let instructions = "No instructions provided.";
        if (fs.existsSync(txtPath)) instructions = fs.readFileSync(txtPath, "utf-8").trim().slice(0, 1024);
        const embed = new EmbedBuilder().setColor(COLORS.BOT).setTitle(`📦 ${entry.name}`).setDescription(entry.description || "No description.").addFields({ name: "📋 Instructions", value: instructions }).setTimestamp();
        try {
          const attachment = new AttachmentBuilder(path.join(CLIENTS_DIR, `${fileName}${foundExt}`), { name: `${fileName}${foundExt}` });
          await interaction.editReply({ embeds: [embed], files: [attachment] });
        } catch (err) { await interaction.editReply({ content: `❌ Error: ${err.message}` }); }
        return;
      }

      if (interaction.isButton() && interaction.customId === "verify_btn") return handleVerify(interaction);

      if (interaction.isButton() && interaction.customId === "get_line_btn") {
        const userId = interaction.user.id;
        const wait = secondsUntilReady(userId);
        if (wait > 0) return interaction.reply({ ephemeral: true, content: `⏳ Wait **${fmtTime(wait)}** before generating again.` });
        const line = popFirstLine();
        if (!line) return interaction.reply({ ephemeral: true, content: "❌ Out of stock! Check back later." });
        lastClick[userId] = Date.now();
        const remaining = readLines().length;
        await updateAllPanels(client);
        try {
          await interaction.user.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("🎁 Account Generated").setDescription(`\`\`\`${line}\`\`\``).addFields({ name: "📦 Remaining", value: `\`${remaining}\` accounts`, inline: true }).setTimestamp()] });
          await interaction.reply({ ephemeral: true, content: "✅ Account sent to your DMs!" });
        } catch (_) {
          const { STOCK_PATH } = require("../systems/stock");
          const currentLines = readLines();
          fs.writeFileSync(STOCK_PATH, [line, ...currentLines].join("\n") + "\n", "utf-8");
          lastClick[userId] = 0;
          return interaction.reply({ ephemeral: true, content: "❌ Couldn't DM you. Enable DMs from server members and try again." });
        }
        await sendGenLog(interaction.guild, interaction.user);
        await checkLowStock(interaction.guild, remaining, interaction.message.id);
        return;
      }

      if (interaction.isButton() && interaction.customId === "join_giveaway") {
        const gw = giveaways[interaction.message.id];
        if (!gw) return interaction.reply({ ephemeral: true, content: "❌ This giveaway has ended." });
        if (gw.entries.has(interaction.user.id)) { gw.entries.delete(interaction.user.id); saveGiveaway(interaction.message.id, gw); return interaction.reply({ ephemeral: true, content: "👋 You left the giveaway." }); }
        gw.entries.add(interaction.user.id); saveGiveaway(interaction.message.id, gw);
        return interaction.reply({ ephemeral: true, content: `🎉 You entered **${gw.item}**! (${gw.entries.size} entries)` });
      }

      if (interaction.isButton() && ["ticket_support","ticket_purchase","ticket_report"].includes(interaction.customId)) {
        const type = interaction.customId.replace("ticket_", "");
        try { const ch = await createTicket(interaction, type); return interaction.reply({ content: `✅ Ticket created: ${ch}`, ephemeral: true }); }
        catch (err) { return interaction.reply({ content: `❌ Failed: ${err.message}`, ephemeral: true }); }
      }

      if (interaction.isButton() && interaction.customId === "ticket_close_btn") {
        if (!isMod(interaction.member)) return interaction.reply({ content: "❌ No permission.", ephemeral: true });
        const ticket = getTicketData(interaction.guild.id, interaction.channel.id);
        if (!ticket) return interaction.reply({ content: "❌ Not a ticket channel.", ephemeral: true });
        await interaction.reply({ content: "🔒 Closing ticket in 5 seconds..." });
        await closeTicket(interaction, ticket); return;
      }

      if (interaction.isButton() && interaction.customId === "ticket_claim_btn") {
        const ticket = getTicketData(interaction.guild.id, interaction.channel.id);
        if (!ticket) return interaction.reply({ content: "❌ Not a ticket.", ephemeral: true });
        if (ticket.claimed) return interaction.reply({ content: `✋ Already claimed by <@${ticket.claimedBy}>.`, ephemeral: true });
        ticket.claimed = true; ticket.claimedBy = interaction.user.id;
        saveTicketData(interaction.guild.id, interaction.channel.id, ticket);
        return interaction.reply({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("✋ Ticket Claimed").setDescription(`${interaction.user} claimed this ticket.`).setTimestamp()] });
      }

      if (interaction.isButton() && interaction.customId.startsWith("feedback_")) {
        const parts = interaction.customId.split("_");
        const rating = parseInt(parts[1]); const channelId = parts[2];
        addFeedback(interaction.guild?.id || "dm", channelId, interaction.user.id, rating, "");
        return interaction.reply({ content: `${"⭐".repeat(rating)} Thanks! You rated **${rating}/5**.`, ephemeral: true });
      }

      if (interaction.isButton() && interaction.customId.startsWith("report_accept_")) {
        if (!isMod(interaction.member)) return interaction.reply({ content: "❌ No permission.", ephemeral: true });
        const reportId = interaction.customId.replace("report_accept_", "");
        const report = updateReportStatus(interaction.guild.id, reportId, "accepted", interaction.user.id);
        if (!report) return interaction.reply({ content: "❌ Not found.", ephemeral: true });
        const embed = EmbedBuilder.from(interaction.message.embeds[0]).setColor(COLORS.SUCCESS).setFields(interaction.message.embeds[0].fields.map(f => f.name === "Status" ? { name: "Status", value: `✅ Accepted by ${interaction.user.username}` } : f));
        return interaction.update({ embeds: [embed], components: [] });
      }
      if (interaction.isButton() && interaction.customId.startsWith("report_deny_")) {
        if (!isMod(interaction.member)) return interaction.reply({ content: "❌ No permission.", ephemeral: true });
        const reportId = interaction.customId.replace("report_deny_", "");
        const report = updateReportStatus(interaction.guild.id, reportId, "denied", interaction.user.id);
        if (!report) return interaction.reply({ content: "❌ Not found.", ephemeral: true });
        const embed = EmbedBuilder.from(interaction.message.embeds[0]).setColor(COLORS.ERROR).setFields(interaction.message.embeds[0].fields.map(f => f.name === "Status" ? { name: "Status", value: `❌ Denied by ${interaction.user.username}` } : f));
        return interaction.update({ embeds: [embed], components: [] });
      }

      if (interaction.isButton() && interaction.customId.startsWith("app_accept_")) {
        if (!isAdmin(interaction.member)) return interaction.reply({ content: "❌ No permission.", ephemeral: true });
        const appId = interaction.customId.replace("app_accept_", "");
        const app = updateApplicationStatus(interaction.guild.id, appId, "accepted", interaction.user.id);
        if (!app) return interaction.reply({ content: "❌ Not found.", ephemeral: true });
        const embed = EmbedBuilder.from(interaction.message.embeds[0]).setColor(COLORS.SUCCESS).setFields(interaction.message.embeds[0].fields.map(f => f.name === "📌 Status" ? { name: "📌 Status", value: `✅ Accepted by ${interaction.user.username}` } : f));
        await interaction.update({ embeds: [embed], components: [] });
        try { const user = await client.users.fetch(app.userId); await user.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("✅ Application Accepted").setDescription(`Your application in **${interaction.guild.name}** has been accepted!`).setTimestamp()] }); } catch (_) {}
        return;
      }
      if (interaction.isButton() && interaction.customId.startsWith("app_deny_")) {
        if (!isAdmin(interaction.member)) return interaction.reply({ content: "❌ No permission.", ephemeral: true });
        const appId = interaction.customId.replace("app_deny_", "");
        const app = updateApplicationStatus(interaction.guild.id, appId, "denied", interaction.user.id);
        if (!app) return interaction.reply({ content: "❌ Not found.", ephemeral: true });
        const embed = EmbedBuilder.from(interaction.message.embeds[0]).setColor(COLORS.ERROR).setFields(interaction.message.embeds[0].fields.map(f => f.name === "📌 Status" ? { name: "📌 Status", value: `❌ Denied by ${interaction.user.username}` } : f));
        await interaction.update({ embeds: [embed], components: [] });
        try { const user = await client.users.fetch(app.userId); await user.send({ embeds: [new EmbedBuilder().setColor(COLORS.ERROR).setTitle("❌ Application Denied").setDescription(`Your application in **${interaction.guild.name}** has been denied.`).setTimestamp()] }); } catch (_) {}
        return;
      }

      if (interaction.isModalSubmit() && interaction.customId === "embed_builder_modal") {
        try {
          const title = interaction.fields.getTextInputValue("embed_title");
          const description = interaction.fields.getTextInputValue("embed_description");
          const color = interaction.fields.getTextInputValue("embed_color") || COLORS.BOT;
          const footer = interaction.fields.getTextInputValue("embed_footer") || "";
          const image = interaction.fields.getTextInputValue("embed_image") || "";
          const embed = new EmbedBuilder().setTitle(title).setDescription(description).setColor(color).setTimestamp();
          if (footer) embed.setFooter({ text: footer });
          if (image?.startsWith("http")) embed.setImage(image);
          return interaction.reply({ embeds: [embed] });
        } catch (err) { return interaction.reply({ content: `❌ Error: ${err.message}`, ephemeral: true }); }
      }

      if (interaction.isModalSubmit() && interaction.customId === "application_modal") {
        const { getAppConfig, addApplication: addApp } = require("../systems/applications");
        const appCfg = getAppConfig(interaction.guild.id);
        const answers = [];
        for (let i = 0; i < Math.min(appCfg.questions.length, 5); i++) {
          try { answers.push({ question: appCfg.questions[i], answer: interaction.fields.getTextInputValue(`app_q${i}`) }); } catch (_) {}
        }
        const app = addApp(interaction.guild.id, { userId: interaction.user.id, userTag: interaction.user.username, answers });
        if (appCfg.logChannel) {
          try {
            const ch = await interaction.guild.channels.fetch(appCfg.logChannel);
            const embed = new EmbedBuilder().setColor(COLORS.BOT).setTitle(`📋 Application #${app.id} — ${interaction.user.username}`).setThumbnail(interaction.user.displayAvatarURL()).setTimestamp();
            for (const a of answers) embed.addFields({ name: a.question, value: a.answer || "N/A" });
            embed.addFields({ name: "📌 Status", value: "⏳ Pending" });
            const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`app_accept_${app.id}`).setLabel("✅ Accept").setStyle(ButtonStyle.Success), new ButtonBuilder().setCustomId(`app_deny_${app.id}`).setLabel("❌ Deny").setStyle(ButtonStyle.Danger));
            await ch.send({ embeds: [embed], components: [row] });
          } catch (_) {}
        }
        return interaction.reply({ content: `✅ Application #${app.id} submitted!`, ephemeral: true });
      }

    } catch (err) {
      console.error("Interaction error:", err);
      try {
        if (interaction.replied || interaction.deferred) await interaction.followUp({ content: "❌ An error occurred.", ephemeral: true });
        else await interaction.reply({ content: "❌ An error occurred.", ephemeral: true });
      } catch (_) {}
    }
  },
};
