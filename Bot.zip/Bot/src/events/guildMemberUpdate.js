const { EmbedBuilder } = require("discord.js");
const { getConfig } = require("../database/store");
const { sendLog } = require("../systems/moderation");
const { addXP } = require("../systems/levels");
const { addPremiumUser } = require("../systems/premium");
const { COLORS } = require("../config");

module.exports = {
  name: "guildMemberUpdate",
  async execute(client, oldMember, newMember) {
    if (!oldMember.premiumSince && newMember.premiumSince) {
      const config = getConfig(newMember.guild.id);
      if (config.boostChannel) {
        try {
          const ch = await newMember.guild.channels.fetch(config.boostChannel);
          const msg = config.boostMessage
            ? config.boostMessage.replace("{user}", `${newMember}`).replace("{guild}", newMember.guild.name)
            : null;
          await ch.send({ content: msg || undefined, embeds: [new EmbedBuilder().setColor("#f47fff").setTitle("🚀 Server Boosted!").setDescription(`Thank you ${newMember} for boosting **${newMember.guild.name}**!\n\nWe now have **${newMember.guild.premiumSubscriptionCount}** boosts!`).setThumbnail(newMember.user.displayAvatarURL({ dynamic: true })).setTimestamp().setFooter({ text: `Boost Level: ${newMember.guild.premiumTier}` })] });
        } catch (_) {}
      }
      if (config.boostXp) addXP(newMember.guild.id, newMember.id, config.boostXp);
      if (config.boostRole) {
        const expiresAt = config.boostRole.expiresAfter ? Date.now() + config.boostRole.expiresAfter : null;
        try { await newMember.roles.add(config.boostRole.roleId); } catch (_) {}
        addPremiumUser(newMember.guild.id, newMember.id, config.boostRole.roleId, expiresAt);
      }
      await sendLog(newMember.guild, "boost", new EmbedBuilder().setColor("#f47fff").setTitle("🚀 Server Boosted").addFields({ name: "Booster", value: `${newMember} (${newMember.user.tag})`, inline: true }).setTimestamp());
    }
    const addedRoles = newMember.roles.cache.filter(r => !oldMember.roles.cache.has(r.id));
    const removedRoles = oldMember.roles.cache.filter(r => !newMember.roles.cache.has(r.id));
    if (addedRoles.size || removedRoles.size) {
      const embed = new EmbedBuilder().setColor(COLORS.BOT).setTitle("🎭 Roles Updated").addFields({ name: "User", value: `${newMember} (${newMember.user.tag})`, inline: true });
      if (addedRoles.size) embed.addFields({ name: "➕ Added", value: addedRoles.map(r => `${r}`).join(", "), inline: true });
      if (removedRoles.size) embed.addFields({ name: "➖ Removed", value: removedRoles.map(r => `${r}`).join(", "), inline: true });
      embed.setTimestamp();
      await sendLog(newMember.guild, "roleUpdate", embed);
    }
  },
};
