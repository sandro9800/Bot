const { getJoin2CreateSettings, addTempChannel, removeTempChannel, getTempChannelOwner, getUserTempChannel } = require("../systems/join2create");
const { PermissionsBitField } = require("discord.js");

module.exports = {
  name: "voiceStateUpdate",
  async execute(oldState, newState) {
    const guild = newState.guild || oldState.guild;
    if (!guild) return;

    const settings = getJoin2CreateSettings(guild.id);
    if (!settings || !settings.enabled || !settings.create_channel_id) return;

    // User joined the create channel
    if (newState.channelId === settings.create_channel_id && oldState.channelId !== newState.channelId) {
      try {
        const member = newState.member;
        if (!member) return;

        const channelName = settings.default_name.replace("{user}", member.displayName || member.user.username);
        const tempChannel = await guild.channels.create({
          name: channelName,
          type: 2, // GUILD_VOICE
          parent: settings.category_id || null,
          userLimit: settings.default_limit,
          bitrate: settings.default_bitrate,
          permissionOverwrites: [
            {
              id: member.id,
              allow: [PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak, PermissionsBitField.Flags.ManageChannels]
            }
          ]
        });

        addTempChannel(tempChannel.id, guild.id, member.id);

        // Move the user
        await member.voice.setChannel(tempChannel).catch(() => {});
      } catch (e) {
        console.error("Join2Create create error:", e);
      }
    }

    // Cleanup empty temp channels
    if (oldState.channel && oldState.channel.members.size === 0) {
      const owner = getTempChannelOwner(oldState.channel.id);
      if (owner) {
        try {
          await oldState.channel.delete().catch(() => {});
          removeTempChannel(oldState.channel.id);
        } catch (e) {}
      }
    }
  }
};
