const { registerSlashCommands } = require("../handlers/registerSlashCommands");
const { restoreGiveaways } = require("../systems/giveaways");
const { restoreAfk } = require("../systems/afk");
const { restorePurges } = require("../systems/purge");
const { inviteCache } = require("../systems/invites");
const { getStorage, saveStorage } = require("../database/store");
const { buildGenEmbed, buildRow, readLines } = require("../systems/stock");
const { checkExpiredPremium } = require("../systems/premium");

module.exports = {
  name: "ready",
  once: true,
  async execute(client) {
    console.log(`✅ Bot online as ${client.user.tag}`);
    await registerSlashCommands();

    // Restore gen panels
    const storage = getStorage();
    const count = readLines().length;
    const active = [];
    for (const entry of storage.genMessages || []) {
      try {
        const ch = await client.channels.fetch(entry.channelId);
        const msg = await ch.messages.fetch(entry.messageId);
        await msg.edit({ embeds: [buildGenEmbed(count, msg.guild)], components: [buildRow(count === 0)] });
        active.push(entry);
      } catch (_) {}
    }
    storage.genMessages = active;
    saveStorage(storage);

    restoreGiveaways(client);
    restoreAfk();
    await restorePurges(client);

    // Cache invites
    for (const guild of client.guilds.cache.values()) {
      try {
        const invites = await guild.invites.fetch();
        inviteCache.set(guild.id, new Map(invites.map(i => [i.code, i.uses])));
      } catch (_) {}
    }

    // Restore scheduled announcements
    const now = Date.now();
    for (const ann of storage.scheduledAnnouncements || []) {
      if (ann.time > now) {
        setTimeout(async () => {
          try {
            const ch = await client.channels.fetch(ann.channelId);
            const { EmbedBuilder } = require("discord.js");
            const { COLORS } = require("../config");
            const embed = new EmbedBuilder().setColor(COLORS.BOT).setTitle("📢 Scheduled Announcement").setDescription(ann.message).setTimestamp();
            await ch.send({ content: ann.pingRole ? `<@&${ann.pingRole}>` : undefined, embeds: [embed], allowedMentions: { roles: ann.pingRole ? [ann.pingRole] : [] } });
          } catch (_) {}
        }, ann.time - now);
      }
    }

    // Check expired premium every hour
    await checkExpiredPremium(client);
    setInterval(() => checkExpiredPremium(client), 3600000);

    console.log("🚀 All systems restored and ready.");
  },
};
