const { EmbedBuilder } = require("discord.js");
const { getConfig } = require("../database/store");
const { inviteCache, addInvite } = require("../systems/invites");
const { sendLog } = require("../systems/moderation");
const { COLORS } = require("../config");

module.exports = {
  name: "guildMemberAdd",
  async execute(client, member) {
    const guildId = member.guild.id;
    const config = getConfig(guildId);

    // Welcome message
    if (config.welcomeChannel) {
      try {
        const ch = await member.guild.channels.fetch(config.welcomeChannel);
        await ch.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("👋 Welcome!").setDescription(`Welcome to **${member.guild.name}**, ${member}!\n\nYou are member #**${member.guild.memberCount}**`).setThumbnail(member.user.displayAvatarURL({ dynamic: true })).addFields({ name: "🆔 User", value: member.user.tag, inline: true }, { name: "📅 Account Created", value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`, inline: true }).setTimestamp()] });
      } catch (_) {}
    }

    // Autorole
    if (config.autorole) {
      try { await member.roles.add(config.autorole); } catch (_) {}
    }

    // Unverified role (for verification system)
    if (config.unverifiedRole) {
      try { await member.roles.add(config.unverifiedRole); } catch (_) {}
    }

    // Invite tracking
    try {
      const cached = inviteCache.get(guildId) || new Map();
      const newInvites = await member.guild.invites.fetch();
      const used = newInvites.find(inv => (cached.get(inv.code) || 0) < inv.uses);
      inviteCache.set(guildId, new Map(newInvites.map(i => [i.code, i.uses])));
      if (used?.inviter) addInvite(guildId, used.inviter.id, member.id);
    } catch (_) {}

    // Join log
    await sendLog(member.guild, "memberJoin", new EmbedBuilder().setColor(COLORS.SUCCESS).setTitle("✅ Member Joined").addFields({ name: "User", value: `${member} (${member.user.tag})`, inline: true }, { name: "Account Age", value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`, inline: true }).setThumbnail(member.user.displayAvatarURL()).setTimestamp());
  },
};
