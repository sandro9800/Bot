const { EmbedBuilder } = require("discord.js");
const { getConfig } = require("../database/store");
const { sendLog } = require("../systems/moderation");
const { COLORS } = require("../config");

module.exports = {
  name: "guildMemberRemove",
  async execute(client, member) {
    const config = getConfig(member.guild.id);
    if (config.leaveChannel) {
      try {
        const ch = await member.guild.channels.fetch(config.leaveChannel);
        await ch.send({ embeds: [new EmbedBuilder().setColor(COLORS.ERROR).setTitle("👋 Goodbye!").setDescription(`**${member.user.tag}** has left **${member.guild.name}**.\n\nWe now have **${member.guild.memberCount}** members.`).setThumbnail(member.user.displayAvatarURL({ dynamic: true })).setTimestamp()] });
      } catch (_) {}
    }
    await sendLog(member.guild, "memberLeave", new EmbedBuilder().setColor(COLORS.ERROR).setTitle("❌ Member Left").addFields({ name: "User", value: `${member.user.tag} (\`${member.id}\`)`, inline: true }).setThumbnail(member.user.displayAvatarURL()).setTimestamp());
  },
};
