const { EmbedBuilder, ChannelType } = require("discord.js");
const { sendLog } = require("../systems/moderation");
const { COLORS } = require("../config");

module.exports = [
  {
    name: "channelCreate",
    async execute(client, channel) {
      if (!channel.guild) return;
      await sendLog(channel.guild, "channelCreate", new EmbedBuilder()
        .setColor(COLORS.SUCCESS).setTitle("📢 Channel Created")
        .addFields({ name: "Channel", value: `${channel} (\`${channel.name}\`)`, inline: true }, { name: "Type", value: `${ChannelType[channel.type]}`, inline: true })
        .setTimestamp());
    },
  },
  {
    name: "channelDelete",
    async execute(client, channel) {
      if (!channel.guild) return;
      await sendLog(channel.guild, "channelDelete", new EmbedBuilder()
        .setColor(COLORS.ERROR).setTitle("🗑️ Channel Deleted")
        .addFields({ name: "Channel", value: `\`${channel.name}\``, inline: true }, { name: "Type", value: `${ChannelType[channel.type]}`, inline: true })
        .setTimestamp());
    },
  },
];
