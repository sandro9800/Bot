const { getVanityConfig, addVanityUser, removeVanityUser, isVanityUser } = require("../systems/vanity");
const { EmbedBuilder } = require("discord.js");
const { COLORS } = require("../config");

module.exports = {
  name: "presenceUpdate",
  async execute(oldPresence, newPresence) {
    if (!newPresence || !newPresence.guild) return;
    const guildId = newPresence.guild.id;
    const userId = newPresence.userId;
    const member = newPresence.member;
    if (!member) return;

    const config = getVanityConfig(guildId);
    if (!config.enabled || !config.vanity_text) return;

    const status = newPresence.activities.find(a => a.type === 4 && a.state); // Custom status
    const hasVanity = status && status.state && status.state.toLowerCase().includes(config.vanity_text.toLowerCase());

    const currentlyHas = isVanityUser(guildId, userId);

    if (hasVanity && !currentlyHas) {
      // Add roles and record
      try {
        for (const roleId of config.roles) {
          const role = newPresence.guild.roles.cache.get(roleId);
          if (role) await member.roles.add(role).catch(() => {});
        }
        addVanityUser(guildId, userId);

        if (config.channel_id && config.message) {
          const channel = newPresence.guild.channels.cache.get(config.channel_id);
          if (channel) {
            let msg = config.message
              .replace("{user.mention}", `<@${userId}>`)
              .replace("{user.name}", member.user.username)
              .replace("{server.name}", newPresence.guild.name);
            await channel.send({ embeds: [new EmbedBuilder().setColor(COLORS.SUCCESS).setDescription(msg)] }).catch(() => {});
          }
        }
      } catch (e) { console.error("Vanity role error:", e); }
    } else if (!hasVanity && currentlyHas) {
      // Remove roles
      try {
        for (const roleId of config.roles) {
          const role = newPresence.guild.roles.cache.get(roleId);
          if (role) await member.roles.remove(role).catch(() => {});
        }
        removeVanityUser(guildId, userId);
      } catch (e) { console.error("Vanity remove error:", e); }
    }
  }
};
