const { PREFIX } = require("../config");
const { incrementMessage } = require("../systems/messageTracker");
const { tryAwardXP } = require("../systems/levels");
const { checkAfk } = require("../systems/afk");

module.exports = {
  name: "messageCreate",
  async execute(client, message) {
    if (message.author.bot || !message.guild) return;
    try { incrementMessage(message.guild.id, message.author.id); } catch (_) {}
    try { tryAwardXP(message.guild.id, message.author.id); } catch (_) {}
    try { await checkAfk(client, message); } catch (_) {}
    if (!message.content.startsWith(PREFIX)) return;
    const args = message.content.slice(PREFIX.length).trim().split(/\s+/);
    const cmdName = args.shift().toLowerCase();
    const command = client.commands.get(cmdName) ||
      [...client.commands.values()].find(c => c.prefixAlias === cmdName);
    if (!command) return;
    try { await command.execute(message, args, client); }
    catch (err) {
      console.error(`Prefix command error [${cmdName}]:`, err);
      message.channel.send("❌ An error occurred.").catch(() => {});
    }
  }
};
