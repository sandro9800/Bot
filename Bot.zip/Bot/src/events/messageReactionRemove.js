const { getStorage } = require("../database/store");

module.exports = {
  name: "messageReactionRemove",
  async execute(client, reaction, user) {
    if (user.bot) return;
    if (reaction.partial) { try { await reaction.fetch(); } catch { return; } }
    const rr = (getStorage().reactRoles || {})[reaction.message.id];
    if (!rr) return;
    const emojiKey = reaction.emoji.id || reaction.emoji.name;
    const pair = rr.pairs.find(p => p.emoji === emojiKey);
    if (!pair) return;
    try { const member = await reaction.message.guild.members.fetch(user.id); await member.roles.remove(pair.roleId); } catch (_) {}
  },
};
