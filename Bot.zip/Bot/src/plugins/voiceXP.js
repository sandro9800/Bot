module.exports = { name: "voiceXP", enabled: true };
