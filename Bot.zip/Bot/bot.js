require("dotenv").config({ path: __dirname + "/.env" });
const { Client, GatewayIntentBits, Partials, Collection } = require("discord.js");
const { loadCommands } = require("./src/handlers/commandLoader");
const { loadEvents } = require("./src/handlers/eventLoader");
const { loadPlugins } = require("./src/handlers/pluginLoader");
const { initDB } = require("./src/database/db");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildInvites,
  ],
  partials: [Partials.Message, Partials.Reaction, Partials.Channel, Partials.User, Partials.GuildMember],
});

client.commands = new Collection();
client.cooldowns = new Collection();
client.plugins = new Collection();

(async () => {
  initDB(); // Auto-create SQLite database and all tables (no manual work required)
  await loadCommands(client);
  await loadEvents(client);
  await loadPlugins(client);
  client.login(process.env.TOKEN);
})();

process.on("unhandledRejection", err => console.error("Unhandled rejection:", err));
process.on("uncaughtException", err => console.error("Uncaught exception:", err));